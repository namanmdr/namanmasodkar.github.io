import fetch from 'node-fetch';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const fixSubscriptionUrl = 'https://jfbmongwmakpobzfxsnz.functions.supabase.co/fix-subscription';

const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
  console.log('Fetching users with subscription_id but missing stripe_customer_id...');
  const { data, error } = await supabase
    .from('user_settings')
    .select('user_id, subscription_id, stripe_customer_id')
    .not('subscription_id', 'is', null)
    .or('stripe_customer_id.is.null,stripe_customer_id.eq.');

  if (error) {
    console.error('Error fetching users:', error);
    process.exit(1);
  }
  if (!data || data.length === 0) {
    console.log('No users need backfilling.');
    return;
  }
  console.log(`Found ${data.length} users to backfill.`);
  for (const user of data) {
    console.log(`Backfilling user: ${user.user_id} (subscription: ${user.subscription_id})`);
    try {
      const res = await fetch(fixSubscriptionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({ userId: user.user_id })
      });
      const result = await res.json();
      if (res.ok && result.success) {
        console.log(`  Success: ${user.user_id}`);
      } else {
        console.error(`  Failed: ${user.user_id}`, result);
      }
    } catch (e) {
      console.error(`  Error for user ${user.user_id}:`, e);
    }
  }
  console.log('Backfill complete.');
}

main(); 