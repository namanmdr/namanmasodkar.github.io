# MindfulSphere

## Overview

MindfulSphere is a modern web application for mindfulness, blending AI-powered yoga sequence generation with personal journaling. Users can generate, save, and revisit yoga routines tailored to their intent, duration, and level, and maintain a rich, searchable journal with mood and tag tracking.

---

## Key Features

- **AI-Powered Yoga Sequences**: Generate, save, and revisit yoga flows based on your intent, mood, and experience level. Includes timer, pose navigation, and export/share options. Premium users unlock AI-powered generation.
- **Mindful Journaling**: Full CRUD for journal entries with title, content, mood, tags, and Markdown support. Search and filter entries. Reflection prompts before/after practice.
- **Personal Dashboard**: Track yoga/journal stats, streaks, and usage. Visualize your practice with graphs and dashboard cards.
- **Profile & Preferences**: Edit profile (name, gender, experience, goals, social links, etc.), set preferences (theme, reminders, language), and manage password.
- **Authentication & Subscription**: Email/password auth, free and premium tiers, Stripe integration, usage tracking, and subscription gating for AI features.

---

## Tech Stack
- React (with hooks/context)
- Vite, TypeScript, Tailwind CSS
- Supabase (auth, DB, API)
- Stripe (payments)
- Lucide React (icons)
- React Router, React Markdown

---

## Project Structure

- `src/components/` – UI elements (Card, Button, Modal, etc.)
- `src/pages/` – Main pages (Home, Yoga, Journal, Profile, etc.)
- `src/contexts/` – Auth and Theme context providers
- `src/hooks/` – Custom hooks (e.g., subscription logic)
- `src/lib/` – Yoga sequence logic, Stripe, Supabase, exporting, types

---

## Database (Supabase)
- `profiles`: extended with social links, preferences, goals, etc.
- `journal_entries`: mood, tags, content, title, user_id
- `yoga_sessions`: generated sequences, intent, completion status, user_id
- `user_settings`: API key, provider, usage, subscription info

---

## Deployment
- Netlify (frontend)
- Supabase (backend)

---

## Limitations
- Email confirmation disabled by default
- No social auth
- Premium users limited to 100 AI sequences/month

