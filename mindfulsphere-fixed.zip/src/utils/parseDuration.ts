// Utility to parse natural language duration strings to minutes
// Examples: '2 hours', '90 min', '1h 30m', '1 hour 15 minutes', '5 hour meditation', '45m', '3h', etc.
export default function parseDuration(input: string): number {
  if (!input) return 0;
  const lower = input.toLowerCase();
  let totalMinutes = 0;
  // Match hours and minutes
  const hourMatch = lower.match(/(\d+(?:\.\d+)?)\s*(h|hr|hour|hours)/);
  const minMatch = lower.match(/(\d+(?:\.\d+)?)\s*(m|min|minute|minutes)/);
  // e.g. '1h 30m', '2 hours 15 minutes'
  if (hourMatch) {
    totalMinutes += parseFloat(hourMatch[1]) * 60;
  }
  if (minMatch) {
    totalMinutes += parseFloat(minMatch[1]);
  }
  // If only a number is given, assume minutes
  if (!hourMatch && !minMatch) {
    const num = parseFloat(lower);
    if (!isNaN(num)) totalMinutes = num;
  }
  // If nothing matched, fallback to 0
  return Math.round(totalMinutes);
} 