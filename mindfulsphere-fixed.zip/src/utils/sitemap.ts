// Sitemap utility for SEO optimization

export interface SitemapEntry {
  url: string;
  lastmod?: string;
  changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority?: number;
}

export const generateSitemap = (baseUrl: string): string => {
  const entries: SitemapEntry[] = [
    // Main pages
    { url: `${baseUrl}/`, changefreq: 'daily', priority: 1.0 },
    { url: `${baseUrl}/yoga`, changefreq: 'weekly', priority: 0.9 },
    { url: `${baseUrl}/journal`, changefreq: 'weekly', priority: 0.9 },
    { url: `${baseUrl}/blog`, changefreq: 'daily', priority: 0.8 },
    { url: `${baseUrl}/pricing`, changefreq: 'monthly', priority: 0.7 },
    { url: `${baseUrl}/about`, changefreq: 'monthly', priority: 0.6 },
    { url: `${baseUrl}/contact`, changefreq: 'monthly', priority: 0.6 },
    { url: `${baseUrl}/privacy-policy`, changefreq: 'yearly', priority: 0.3 },
    { url: `${baseUrl}/terms-of-service`, changefreq: 'yearly', priority: 0.3 },
    
    // Blog posts
    { url: `${baseUrl}/blog/ai-revolutionizing-yoga-practice`, changefreq: 'monthly', priority: 0.8 },
    { url: `${baseUrl}/blog/science-behind-mindful-journaling`, changefreq: 'monthly', priority: 0.8 },
    { url: `${baseUrl}/blog/perfect-morning-yoga-routine`, changefreq: 'monthly', priority: 0.8 },
    { url: `${baseUrl}/blog/digital-detox-finding-balance`, changefreq: 'monthly', priority: 0.8 },
    { url: `${baseUrl}/blog/art-of-self-reflection`, changefreq: 'monthly', priority: 0.8 },
    { url: `${baseUrl}/blog/yoga-stress-relief-poses`, changefreq: 'monthly', priority: 0.8 },
  ];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries.map(entry => `  <url>
    <loc>${entry.url}</loc>
    ${entry.lastmod ? `<lastmod>${entry.lastmod}</lastmod>` : ''}
    ${entry.changefreq ? `<changefreq>${entry.changefreq}</changefreq>` : ''}
    ${entry.priority ? `<priority>${entry.priority}</priority>` : ''}
  </url>`).join('\n')}
</urlset>`;

  return sitemap;
};

export const generateRobotsTxt = (baseUrl: string): string => {
  return `User-agent: *
Allow: /

# Sitemap
Sitemap: ${baseUrl}/sitemap.xml

# Disallow admin and private areas
Disallow: /admin/
Disallow: /private/
Disallow: /api/

# Allow important pages
Allow: /blog/
Allow: /yoga/
Allow: /journal/
Allow: /about/
Allow: /contact/
Allow: /pricing/

# Crawl delay (optional)
Crawl-delay: 1`;
};

// SEO-friendly URL generation
export const generateSEOUrl = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single
    .trim();
};

// Meta description generator
export const generateMetaDescription = (content: string, maxLength: number = 160): string => {
  // Remove markdown and HTML tags
  const plainText = content
    .replace(/[#*`]/g, '') // Remove markdown syntax
    .replace(/<[^>]*>/g, '') // Remove HTML tags
    .replace(/\s+/g, ' ') // Replace multiple spaces with single
    .trim();

  if (plainText.length <= maxLength) {
    return plainText;
  }

  // Truncate at word boundary
  const truncated = plainText.substring(0, maxLength);
  const lastSpace = truncated.lastIndexOf(' ');
  
  return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
};

// Structured data for blog posts
export const generateArticleStructuredData = (post: {
  title: string;
  description: string;
  author: string;
  publishedAt: string;
  url: string;
  image?: string;
  tags: string[];
}) => {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": post.title,
    "description": post.description,
    "image": post.image || "https://mindfulsphere.com/og-image.jpg",
    "author": {
      "@type": "Person",
      "name": post.author
    },
    "publisher": {
      "@type": "Organization",
      "name": "MindfulSphere",
      "logo": {
        "@type": "ImageObject",
        "url": "https://mindfulsphere.com/logo.png"
      }
    },
    "datePublished": post.publishedAt,
    "dateModified": post.publishedAt,
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": post.url
    },
    "keywords": post.tags.join(', '),
    "articleSection": post.tags[0] || "Wellness"
  };
};

// Breadcrumb structured data
export const generateBreadcrumbStructuredData = (items: Array<{ name: string; url: string }>) => {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items.map((item, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "name": item.name,
      "item": item.url
    }))
  };
}; 