import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
const HomePage = lazy(() => import('./pages/HomePage'));
const YogaPage = lazy(() => import('./pages/YogaPage'));
const JournalPage = lazy(() => import('./pages/JournalPage'));
const JournalEntryPage = lazy(() => import('./pages/JournalEntryPage'));
const JournalEditPage = lazy(() => import('./pages/JournalEditPage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));
const RegisterPage = lazy(() => import('./pages/RegisterPage'));
const ContentPage = lazy(() => import('./pages/ContentPage'));
const PricingPage = lazy(() => import('./pages/PricingPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const ContactPage = lazy(() => import('./pages/ContactPage'));
const PrivacyPolicyPage = lazy(() => import('./pages/PrivacyPolicyPage'));
const TermsOfServicePage = lazy(() => import('./pages/TermsOfServicePage'));
const BlogPage = lazy(() => import('./pages/BlogPage'));
const BlogPostPage = lazy(() => import('./pages/BlogPostPage'));
const TeacherDirectoryPage = lazy(() => import('./pages/TeacherDirectoryPage'));
import { Helmet } from 'react-helmet-async';

const App: React.FC = () => {
  return (
    <HelmetProvider>
      {/* Meta Pixel code removed: now in index.html */}
      <ThemeProvider>
        <AuthProvider>
          <Router>
            <Suspense fallback={<div style={{minHeight:'60vh'}} aria-busy="true" />}>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="yoga" element={<YogaPage />} />
                <Route path="yoga/:id" element={<YogaPage />} /> {/* Add this line */}
                <Route path="journal" element={<JournalPage />} />
                <Route path="journal/:id" element={<JournalEntryPage />} />
                <Route path="journal/edit/:id" element={<JournalEditPage />} />
                <Route path="journal/new" element={<JournalEditPage />} />
                <Route path="profile" element={<ProfilePage />} />
                <Route path="content/*" element={<ContentPage />} />
                <Route path="login" element={<LoginPage />} />
                <Route path="register" element={<RegisterPage />} />
                <Route path="pricing" element={<PricingPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
                <Route path="/terms-of-service" element={<TermsOfServicePage />} />
                <Route path="/blog" element={<BlogPage />} />
                <Route path="/blog/:slug" element={<BlogPostPage />} />
                <Route path="/teachers" element={<TeacherDirectoryPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Route>
            </Routes>
            </Suspense>
          </Router>
        </AuthProvider>
      </ThemeProvider>
    </HelmetProvider>
  );
};

export default App;