import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string[];
  author?: string;
  publishedAt?: string;
  updatedAt?: string;
  image?: string;
  url?: string;
  type?: 'article' | 'website';
  tags?: string[];
  readTime?: number;
  featured?: boolean;
}

const SEOHead: React.FC<SEOHeadProps> = ({
  title = 'MindfulSphere - AI-Powered Yoga & Mindfulness Platform',
  description = 'Transform your yoga practice with AI-powered personalized sequences, mindful journaling, and comprehensive wellness tracking. Join our community of mindful practitioners.',
  keywords = ['yoga', 'mindfulness', 'AI yoga', 'meditation', 'wellness', 'mindful journaling', 'personal growth'],
  author = 'MindfulSphere Team',
  publishedAt,
  updatedAt,
  image = 'https://mindfulsphere.com/og-image.jpg',
  url,
  type = 'website',
  tags = [],
  readTime,
  featured = false
}) => {
  const currentUrl = url || window.location.href;
  const fullTitle = title.includes('MindfulSphere') ? title : `${title} | MindfulSphere`;
  
  // Structured data for articles
  const articleStructuredData = type === 'article' ? {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": title,
    "description": description,
    "image": image,
    "author": {
      "@type": "Person",
      "name": author
    },
    "publisher": {
      "@type": "Organization",
      "name": "MindfulSphere",
      "logo": {
        "@type": "ImageObject",
        "url": "https://mindfulsphere.com/logo.png"
      }
    },
    "datePublished": publishedAt,
    "dateModified": updatedAt || publishedAt,
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": currentUrl
    },
    "keywords": keywords.join(', '),
    "articleSection": tags[0] || "Wellness",
    "wordCount": readTime ? readTime * 200 : undefined // Rough estimate
  } : null;

  // Organization structured data
  const organizationStructuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "MindfulSphere",
    "url": "https://mindfulsphere.com",
    "logo": "https://mindfulsphere.com/logo.png",
    "description": "AI-powered yoga and mindfulness platform",
    "sameAs": [
      "https://twitter.com/mindfulsphere",
      "https://facebook.com/mindfulsphere",
      "https://instagram.com/mindfulsphere"
    ]
  };

  // Website structured data
  const websiteStructuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "MindfulSphere",
    "url": "https://mindfulsphere.com",
    "description": description,
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://mindfulsphere.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords.join(', ')} />
      <meta name="author" content={author} />
      
      {/* Open Graph Meta Tags */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content={type} />
      <meta property="og:url" content={currentUrl} />
      <meta property="og:image" content={image} />
      <meta property="og:site_name" content="MindfulSphere" />
      <meta property="og:locale" content="en_US" />
      
      {/* Twitter Card Meta Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      <meta name="twitter:site" content="@mindfulsphere" />
      
      {/* Article-specific meta tags */}
      {type === 'article' && (
        <>
          <meta property="article:published_time" content={publishedAt} />
          {updatedAt && <meta property="article:modified_time" content={updatedAt} />}
          <meta property="article:author" content={author} />
          {tags.map(tag => (
            <meta key={tag} property="article:tag" content={tag} />
          ))}
          {featured && <meta property="article:section" content="Featured" />}
        </>
      )}
      
      {/* Additional Meta Tags */}
      <meta name="robots" content="index, follow" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="theme-color" content="#6366f1" />
      
      {/* Canonical URL */}
      <link rel="canonical" href={currentUrl} />
      
      {/* Favicon */}
      <link rel="icon" type="image/x-icon" href="/favicon.ico" />
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
      
      {/* Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(organizationStructuredData)}
      </script>
      
      <script type="application/ld+json">
        {JSON.stringify(websiteStructuredData)}
      </script>
      
      {articleStructuredData && (
        <script type="application/ld+json">
          {JSON.stringify(articleStructuredData)}
        </script>
      )}
      
      {/* Additional SEO optimizations */}
      <meta name="application-name" content="MindfulSphere" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      <meta name="apple-mobile-web-app-title" content="MindfulSphere" />
      <meta name="format-detection" content="telephone=no" />
      <meta name="mobile-web-app-capable" content="yes" />
      <meta name="msapplication-config" content="/browserconfig.xml" />
      <meta name="msapplication-TileColor" content="#6366f1" />
      <meta name="msapplication-tap-highlight" content="no" />
      
      {/* Preconnect to external domains for performance */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link rel="preconnect" href="https://images.unsplash.com" />
      
      {/* DNS prefetch for performance */}
      <link rel="dns-prefetch" href="//fonts.googleapis.com" />
      <link rel="dns-prefetch" href="//images.unsplash.com" />
    </Helmet>
  );
};

export default SEOHead; 