import React from 'react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  maxWidth?: string; // e.g. 'max-w-2xl'
}

const Modal: React.FC<ModalProps> = ({ open, onClose, title, children, actions, maxWidth }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-100 flex items-center justify-center bg-black/70 backdrop-blur-xl animate-fade-in">
      <div className={`bg-gradient-to-br from-primary-50 via-purple-50 to-indigo-100 dark:from-gray-900 dark:via-primary-950 dark:to-indigo-950 rounded-3xl p-10 ${maxWidth || 'max-w-md'} w-full text-center shadow-2xl border-0 relative transition-all duration-300 scale-100 animate-slide-up`}>
        <button
          className="absolute top-4 right-4 text-gray-400 hover:text-primary-500 dark:hover:text-primary-400 text-2xl font-bold focus:outline-none focus:ring-2 focus:ring-primary-400 rounded-full w-10 h-10 flex items-center justify-center"
          onClick={onClose}
          aria-label="Close"
        >
          &times;
        </button>
        <h2 className="text-2xl md:text-3xl font-extrabold mb-4 tracking-tight bg-gradient-to-r from-primary-600 via-indigo-500 to-purple-500 bg-clip-text text-transparent font-sora">
          {title}
        </h2>
        <div className="mb-6 text-base text-gray-700 dark:text-gray-300 font-sora max-h-[60vh] overflow-y-auto scrollbar-thin scrollbar-thumb-indigo-300 scrollbar-track-transparent">{children}</div>
        {actions && <div className="flex justify-center gap-4">{actions}</div>}
      </div>
    </div>
  );
};

export default Modal; 