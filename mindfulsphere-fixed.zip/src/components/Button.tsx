import React from 'react';
import { motion } from 'framer-motion';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  className = '',
  disabled,
  ...rest
}) => {
  const baseStyles = "inline-flex items-center justify-center rounded-full font-semibold transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none shadow-md";
  
  const variantStyles = {
    primary: `bg-gradient-to-r from-primary-500 via-indigo-500 to-purple-500 text-white border-0 shadow-xl
      hover:from-primary-600 hover:via-indigo-600 hover:to-purple-600
      focus:ring-4 focus:ring-primary-300
      active:brightness-95
      disabled:opacity-60 disabled:cursor-not-allowed`,
    secondary: `bg-primary-600 text-white border-0 shadow-lg
      hover:bg-primary-700 focus:ring-4 focus:ring-primary-300 active:brightness-95 disabled:opacity-60 disabled:cursor-not-allowed`,
    outline: `border-2 border-primary-400 bg-primary-50 text-primary-700 shadow-md
      dark:border-primary-500 dark:bg-primary-950 dark:text-primary-200
      hover:bg-primary-100 dark:hover:bg-primary-900 focus:ring-4 focus:ring-primary-200 active:brightness-95 disabled:opacity-60 disabled:cursor-not-allowed`,
    ghost: `bg-transparent text-primary-700 dark:text-primary-200 hover:bg-primary-50 dark:hover:bg-primary-900 focus:ring-2 focus:ring-primary-200 active:brightness-95 disabled:opacity-60 disabled:cursor-not-allowed`,
    danger: `bg-danger text-white border-0 shadow-md hover:bg-red-700 focus:ring-4 focus:ring-danger active:brightness-95 disabled:opacity-60 disabled:cursor-not-allowed`,
  };
  
  const sizeStyles = {
    sm: "text-sm px-4 py-2",
    md: "text-base px-5 py-2.5",
    lg: "text-lg px-7 py-3 font-bold",
  };
  
  const loadingSpinner = (
    <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
  );
  
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      disabled={disabled || isLoading}
      {...rest}
    >
      {isLoading && loadingSpinner}
      {!isLoading && leftIcon && <span className="mr-2">{leftIcon}</span>}
      {children}
      {!isLoading && rightIcon && <span className="ml-2">{rightIcon}</span>}
    </motion.button>
  );
};

export default Button;