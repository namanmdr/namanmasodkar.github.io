import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './Card';
import Button from './Button';
import Select from './Select';
import { useNavigate } from 'react-router-dom';
import { Brain, Heart, Bot as Lotus, Sparkles, Scale } from 'lucide-react';
import Modal from './Modal';
import { generateJournalTitleWithAIProxy } from '../lib/ai';
import { supabase } from '../lib/supabase';
import TextArea from './TextArea';

interface IntentGeneratorProps {
  content: string;
  journalId: string; // Add this
  onClose: () => void;
}

const intentTypes = [
  {
    value: 'thinking',
    label: 'To bring clarity and perspective to my thoughts',
    icon: <Brain className="text-blue-500" size={20} />,
    description: 'For entries focused on analysis, confusion, or problem-solving'
  },
  {
    value: 'feeling',
    label: 'To honor and release the emotions within me',
    icon: <Heart className="text-rose-500\" size={20} />,
    description: 'For entries exploring emotional states or relationships'
  },
  {
    value: 'sensation',
    label: 'To reconnect with my body and the present moment',
    icon: <Lotus className="text-emerald-500" size={20} />,
    description: 'For moments of anxiety or disconnection from the body'
  },
  {
    value: 'intuition',
    label: 'To attune to deeper meaning beneath this experience',
    icon: <Sparkles className="text-purple-500\" size={20} />,
    description: 'For poetic, symbolic, or spiritual reflections'
  },
  {
    value: 'integration',
    label: 'To integrate mind, body, and insight from this entry',
    icon: <Scale className="text-amber-500" size={20} />,
    description: 'For entries seeking wholeness and balance'
  }
];

const IntentGenerator: React.FC<IntentGeneratorProps> = ({ content, journalId, onClose }) => {
  const navigate = useNavigate();
  const [selectedIntent, setSelectedIntent] = useState(intentTypes[0].value);
  const [duration, setDuration] = useState('20');
  const [level, setLevel] = useState('intermediate');
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [showOverageModal, setShowOverageModal] = useState(false);
  const [showGenericErrorModal, setShowGenericErrorModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Remove all AI intention generation logic and state
  // const [customIntention, setCustomIntention] = useState(''); // REMOVE
  // const [intentionLoading, setIntentionLoading] = useState(false); // REMOVE

  // Remove useEffect for AI intention generation

  const handleCreateSequence = () => {
    const selectedIntentType = intentTypes.find(i => i.value === selectedIntent);
    if (!selectedIntentType) return;
    const data = {
      content,
      journalId,
      intentType: selectedIntentType.value,
      intentLabel: selectedIntentType.label
    };
    const encodedData = btoa(JSON.stringify(data));
    navigate(`/yoga?data=${encodedData}&duration=${duration}&level=${level}`);
    onClose();
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Create Yoga Sequence from Journal Entry</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Choose Intent Type
            </label>
            <div className="space-y-3">
              {intentTypes.map((intent) => (
                <label
                  key={intent.value}
                  className={`flex items-start p-3 rounded-lg cursor-pointer transition-colors ${
                    selectedIntent === intent.value
                      ? 'bg-indigo-50 dark:bg-indigo-900/30 border-2 border-indigo-500'
                      : 'bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="intent"
                    value={intent.value}
                    checked={selectedIntent === intent.value}
                    onChange={(e) => setSelectedIntent(e.target.value)}
                    className="sr-only"
                  />
                  <div className="flex-1">
                    <div className="flex items-center mb-1">
                      {intent.icon}
                      <span className="ml-2 font-medium">{intent.label}</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {intent.description}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Remove custom Yoga Intention field */}
          {/*
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Custom Yoga Intention
            </label>
            {intentionLoading ? (
              <div className="text-gray-500 dark:text-gray-400 italic">Generating intention...</div>
            ) : (
              <TextArea
                value={customIntention}
                onChange={e => setCustomIntention(e.target.value)}
                placeholder="Your custom yoga intention will appear here. You can edit it before creating your sequence."
                rows={4}
                className="w-full"
              />
            )}
          </div>
          */}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Duration"
              value={duration}
              onChange={setDuration}
              options={[
                { value: '10', label: '10 minutes' },
                { value: '15', label: '15 minutes' },
                { value: '20', label: '20 minutes' },
                { value: '30', label: '30 minutes' },
                { value: '45', label: '45 minutes' },
                { value: '60', label: '60 minutes' }
              ]}
            />
            <Select
              label="Level"
              value={level}
              onChange={setLevel}
              options={[
                { value: 'beginner', label: 'Beginner' },
                { value: 'intermediate', label: 'Intermediate' },
                { value: 'advanced', label: 'Advanced' }
              ]}
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleCreateSequence}>
            Create Sequence
          </Button>
        </CardFooter>
      </Card>
      <Modal
        open={showSubscribeModal}
        onClose={() => setShowSubscribeModal(false)}
        title="Subscribe to Unlock AI Features"
        actions={
          <a href="/pricing">
            <Button variant="primary">Subscribe Now</Button>
          </a>
        }
      >
        AI-powered yoga sequence generation is available to subscribers. Please subscribe to unlock this feature.
      </Modal>
      <Modal
        open={showOverageModal}
        onClose={() => setShowOverageModal(false)}
        title="Monthly Usage Limit Reached"
        actions={
          <a href="/pricing">
            <Button variant="primary">Upgrade Plan</Button>
          </a>
        }
      >
        You have reached your monthly AI usage limit. Please wait for your usage to reset or upgrade your plan to continue using AI features.
      </Modal>
      <Modal
        open={showGenericErrorModal}
        onClose={() => setShowGenericErrorModal(false)}
        title="Error"
      >
        {errorMessage}
      </Modal>
    </>
  );
};

export default IntentGenerator;