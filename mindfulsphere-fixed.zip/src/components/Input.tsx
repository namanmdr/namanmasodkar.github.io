import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, helperText, leftIcon, className = '', ...props }, ref) => {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full"
      >
        {label && (
          <label 
            htmlFor={props.id} 
            className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1 tracking-tight"
          >
            {label}
          </label>
        )}
        <div className="relative">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-brand-500 dark:text-brand-400">
              {leftIcon}
            </div>
          )}
          <input
            ref={ref}
            className={`
              w-full px-5 ${leftIcon ? 'pl-12' : ''} py-3 bg-primary-50 dark:bg-primary-950
              border-2 border-primary-300 dark:border-primary-700 rounded-2xl shadow focus:shadow-xl font-semibold text-base text-gray-900 dark:text-gray-100
              placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:border-primary-500
              disabled:opacity-50 disabled:cursor-not-allowed
              transition-all duration-300
              ${error 
                ? 'border-danger text-danger focus:border-danger focus:ring-danger' 
                : 'border-primary-400 dark:border-primary-500 focus:border-primary-500 focus:ring-primary-500'
              }
              ${className}
            `}
            {...props}
          />
        </div>
        {error && (
          <p className="mt-1 text-sm font-semibold text-danger dark:text-danger">{error}</p>
        )}
        {helperText && !error && (
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{helperText}</p>
        )}
      </motion.div>
    );
  }
);

Input.displayName = 'Input';

export default Input;