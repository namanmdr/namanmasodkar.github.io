import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './Card';
import Button from './Button';
import Input from './Input';
import { DndContext, DragEndEvent, closestCenter } from '@dnd-kit/core';
import { arrayMove, SortableContext, rectSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Search, Plus, GripVertical, Clock, Save, Trash2, Download, Share2, Edit2, Home, HelpCircle } from 'lucide-react';
import { poseDatabase, fetchUserPoses, addUserPose, deleteUserPose } from '../lib/poses';
import type { YogaPose } from '../lib/yoga';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { exportToMarkdown, downloadAsFile, exportToPDF } from '../lib/export';
import parseDuration from '../utils/parseDuration';

// Extend YogaPose for user poses
interface UserPose extends YogaPose {
  id: string;
  createdAt?: string;
}

// Define Section type for clarity
interface Section {
  id: string;
  name: string;
  poses: SequencePose[];
}

interface SequencePose extends YogaPose {
  id: string;
}

interface SortablePoseProps {
  pose: SequencePose;
  onRemove: () => void;
  onDurationChange: (duration: number) => void;
}

const poseImages = import.meta.glob('../assets/poses/*.png', { eager: true, query: '?url', import: 'default' });

const SortablePose: React.FC<SortablePoseProps> = ({ pose, onRemove, onDurationChange }) => {
  const {
    setNodeRef,
    attributes,
    listeners,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: pose.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: transition || 'transform 250ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 200ms',
    zIndex: isDragging ? 50 : 1,
    cursor: 'grab',
    boxShadow: isDragging ? '0 8px 32px 0 rgba(80, 80, 255, 0.25), 0 2px 8px 0 rgba(0,0,0,0.10)' : undefined,
    scale: isDragging ? 1.04 : 1,
    background: undefined,
  };

  // Resolve image URL if pose.image is present
  const imageUrl = pose.image ? (poseImages[`../assets/poses/${pose.image}`] as string | undefined) : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`rounded-2xl bg-gradient-to-br from-primary-900 to-primary-800 p-4 flex flex-col items-center shadow-lg min-h-[260px] h-full relative select-none ${isDragging ? 'ring-4 ring-primary-400' : ''}`}
    >
      {/* Pose image or placeholder */}
      <div className="w-40 h-40 bg-primary-700 rounded-xl flex items-center justify-center text-primary-300 text-3xl font-bold mb-6 mt-2 overflow-hidden">
        {imageUrl ? (
          <img src={imageUrl} alt={pose.name} className="object-contain w-full h-full" />
        ) : (
          '🧘'
        )}
      </div>
      <div className="flex-1 flex flex-col items-center justify-center w-full">
        <h3 className="font-semibold text-lg text-primary-100 text-center mb-1">{pose.name}</h3>
        <p className="text-sm text-primary-300 italic text-center mb-4">{pose.sanskritName}</p>
      </div>
      <div className="flex items-center gap-3 w-full justify-center mt-auto">
        <Clock size={16} className="text-primary-400" />
        <input
          type="number"
          min="1"
          value={pose.durationInSeconds / 60}
          onClick={e => e.stopPropagation()}
          onChange={e => onDurationChange(parseInt(e.target.value) * 60)}
          className="w-14 px-2 py-1 text-sm border-2 rounded-full shadow focus:ring-2 focus:ring-primary-400 border-primary-700 bg-primary-900 text-primary-100 text-center"
        />
        <span className="text-sm text-primary-300">min</span>
        <Button
          variant="ghost"
          size="sm"
          onPointerDown={e => { e.stopPropagation(); e.preventDefault(); }}
          onClick={e => { e.stopPropagation(); e.preventDefault(); onRemove(); }}
          className="text-red-400 hover:text-red-500"
          data-no-dnd="true"
        >
          <Trash2 size={16} />
        </Button>
      </div>
    </div>
  );
};

// Add a style block for grid children to ensure equal size and smooth animation
if (typeof document !== 'undefined' && !document.getElementById('sortable-pose-grid-style')) {
  const style = document.createElement('style');
  style.id = 'sortable-pose-grid-style';
  style.innerHTML = `
    .pose-grid-card {
      min-height: 260px;
      height: 100%;
      transition: transform 250ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 200ms;
    }
  `;
  document.head.appendChild(style);
}

export const generateUniqueId = () => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

const LOCAL_STORAGE_KEY = 'manualSequenceBuilder';

type BuilderView = 'builder' | { type: 'pose-select', sectionId: string };

interface SequenceBuilderProps {
  initialSections?: Section[];
  initialSequenceName?: string;
  initialIntention?: string;
  initialLevel?: string;
  onDone?: () => void;
}

const SequenceBuilder: React.FC<SequenceBuilderProps> = ({
  initialSections,
  initialSequenceName,
  initialIntention,
  initialLevel,
  onDone,
}) => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [toast, setToast] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  // If editing (any initial* prop present), clear localStorage and use props for state
  useEffect(() => {
    if (initialSections || initialSequenceName || initialIntention || initialLevel) {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  }, [initialSections, initialSequenceName, initialIntention, initialLevel]);

  const [sections, setSections] = useState<Section[]>(() => {
    if (initialSections && Array.isArray(initialSections)) {
      return initialSections.map(section => ({
        ...section,
        id: section.id || generateUniqueId(),
        poses: (section.poses || []).map((pose: any) => ({ ...pose, id: pose.id || generateUniqueId() }))
      }));
    }
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.sections && Array.isArray(parsed.sections)) {
          return parsed.sections.map((section: any) => ({
            ...section,
            id: section.id || generateUniqueId(),
            poses: (section.poses || []).map((pose: any) => ({ ...pose, id: pose.id || generateUniqueId() }))
          }));
        }
      } catch (e) {}
    }
    return [{ id: generateUniqueId(), name: 'Section 1', poses: [] }];
  });

  const [sequenceName, setSequenceName] = useState(() => {
    if (initialSequenceName) return initialSequenceName;
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.sequenceName && typeof parsed.sequenceName === 'string') {
          return parsed.sequenceName;
        }
      } catch (e) {}
    }
    return 'Custom Yoga Sequence';
  });
  const [intention, setIntention] = useState(() => {
    if (initialIntention) return initialIntention;
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.intention && typeof parsed.intention === 'string') {
          return parsed.intention;
        }
      } catch (e) {}
    }
    return '';
  });
  const [level, setLevel] = useState(() => {
    if (initialLevel) return initialLevel;
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.level && typeof parsed.level === 'string') {
          return parsed.level;
        }
      } catch (e) {}
    }
    return 'beginner';
  });
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [view, setView] = useState<BuilderView>('builder');
  const [poseFilter, setPoseFilter] = useState<string>('');
  const [editingName, setEditingName] = useState(false);
  const [userPoses, setUserPoses] = useState<UserPose[]>([]);
  const [userPosesLoading, setUserPosesLoading] = useState(false);
  const [showCustomPoseModal, setShowCustomPoseModal] = useState(false);
  const [customPoseForm, setCustomPoseForm] = useState<any>({
    name: '',
    sanskritName: '',
    duration: '1 minute',
    durationInSeconds: 60,
    benefits: '',
    instructions: [''],
    intentRelation: '',
    audioUrl: '',
    image: '',
  });
  // Fetch user poses when pose selection modal is opened
  useEffect(() => {
    if (typeof view === 'object' && view.type === 'pose-select' && user) {
      setUserPosesLoading(true);
      fetchUserPoses(user.id).then(poses => {
        setUserPoses(poses.map(p => ({ ...p, id: p.id || generateUniqueId() })));
        setUserPosesLoading(false);
      });
    }
  }, [view, user]);
  // Handler for creating a custom pose
  const handleCreateCustomPose = async () => {
    if (!user) return;
    // Validate minimal fields
    if (!customPoseForm.name || !customPoseForm.durationInSeconds || !customPoseForm.instructions[0]) {
      setToast({ type: 'error', message: 'Please fill in at least name, duration, and one instruction.' });
      return;
    }
    const success = await addUserPose(user.id, {
      ...customPoseForm,
      instructions: customPoseForm.instructions.filter((i: string) => i.trim()),
    });
    if (success) {
      setShowCustomPoseModal(false);
      setCustomPoseForm({
        name: '', sanskritName: '', duration: '1 minute', durationInSeconds: 60, benefits: '', instructions: [''], intentRelation: '', audioUrl: '', image: ''
      });
      setToast({ type: 'success', message: 'Custom pose/block added!' });
      // Refresh user poses
      fetchUserPoses(user.id).then(poses => setUserPoses(poses.map(p => ({ ...p, id: p.id || generateUniqueId() }))));
    } else {
      setToast({ type: 'error', message: 'Failed to add custom pose.' });
    }
  };
  // Handler for deleting a user pose
  const handleDeleteUserPose = async (poseId: string) => {
    if (!user) return;
    const ok = window.confirm('Delete this custom pose/block?');
    if (!ok) return;
    const success = await deleteUserPose(user.id, poseId);
    if (success) {
      setToast({ type: 'success', message: 'Deleted.' });
      fetchUserPoses(user.id).then(poses => setUserPoses(poses.map(p => ({ ...p, id: p.id || generateUniqueId() }))));
    } else {
      setToast({ type: 'error', message: 'Failed to delete.' });
    }
  };

  // --- Local Storage Persistence ---
  // Save to localStorage on changes
  useEffect(() => {
    localStorage.setItem(
      LOCAL_STORAGE_KEY,
      JSON.stringify({ sections, sequenceName, intention, level })
    );
  }, [sections, sequenceName, intention, level]);

  // Clear localStorage on save/export/clear
  const clearLocalStorage = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
  };

  // Toast auto-dismiss
  useEffect(() => {
    if (toast) {
      const timeout = setTimeout(() => setToast(null), 2000);
      return () => clearTimeout(timeout);
    }
  }, [toast]);

  // --- Filtering logic for pose selection ---
  // Filtering by category (category name as type)
  const filteredPoseCategories = poseDatabase
    .map(category => ({
      ...category,
      poses: category.poses.filter(pose => {
        const matchesQuery =
          pose.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          pose.sanskritName.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = poseFilter ? (category.name === poseFilter) : true;
        return matchesQuery && matchesFilter;
      })
    }))
    .filter(category => category.poses.length > 0);

  const allPoseTypes = poseDatabase.map(cat => cat.name);

  // Section management handlers
  const handleAddSection = () => {
    setSections([...sections, { id: generateUniqueId(), name: `Section ${sections.length + 1}`, poses: [] }]);
  };
  const handleRemoveSection = (id: string) => {
    if (sections.length === 1) return; // Always keep at least one section
    setSections(sections.filter((section: Section) => section.id !== id));
  };
  const handleRenameSection = (id: string, newName: string) => {
    setSections(sections.map((section: Section) => section.id === id ? { ...section, name: newName } : section));
  };

  // Pose management per section
  const handleAddPose = (sectionId: string, pose: YogaPose) => {
    setSections(sections.map((section: Section) =>
      section.id === sectionId
        ? { ...section, poses: [...section.poses, { ...pose, id: generateUniqueId() }] }
        : section
    ));
    setView('builder');
  };
  const handleRemovePose = (sectionId: string, poseId: string) => {
    setSections(sections.map((section: Section) =>
      section.id === sectionId
        ? { ...section, poses: section.poses.filter((p: SequencePose) => p.id !== poseId) }
        : section
    ));
  };
  const handleDurationChange = (sectionId: string, poseId: string, duration: number) => {
    setSections(sections.map((section: Section) =>
      section.id === sectionId
        ? {
            ...section,
            poses: section.poses.map((p: SequencePose) =>
              p.id === poseId ? { ...p, duration: `${duration / 60} minutes`, durationInSeconds: duration } : p
      )
          }
        : section
    ));
  };
  const handleDragEnd = (sectionId: string, event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setSections(sections.map((section: Section) => {
        if (section.id !== sectionId) return section;
        const oldIndex = section.poses.findIndex((pose: SequencePose) => pose.id === active.id);
        const newIndex = section.poses.findIndex((pose: SequencePose) => pose.id === over.id);
        return { ...section, poses: arrayMove(section.poses, oldIndex, newIndex) };
      }));
    }
  };

  // When saving/exporting/sharing, use 'intent' instead of 'intention' in the sequence object:
  const handleSave = async () => {
    if (!user) return;
    try {
      setSaving(true);
      const sequence = {
        title: sequenceName,
        duration: sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0),
        intent: intention, // <-- use 'intent' for backend
        level,
        sections: sections.map(section => ({ title: section.name, poses: section.poses.map(({ id, ...pose }) => pose) })),
        rawMarkdown: exportToMarkdown({
          title: sequenceName,
          duration: sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0),
          intent: intention, // <-- use 'intent' for backend
          level,
          sections: sections.map(section => ({ title: section.name, poses: section.poses.map(({ id, ...pose }) => pose) }))
        }, 'yoga')
      };
      const { error } = await supabase
        .from('yoga_sessions')
        .insert({
          title: sequence.title,
          duration: sequence.duration,
          intent: sequence.intent, // <-- use 'intent' for backend
          level: sequence.level,
          user_id: user.id,
          sequence: sequence,
          completed: false
        });
      if (error) throw error;
      setToast({ type: 'success', message: 'Sequence saved successfully!' });
    } catch (error) {
      console.error('Error saving sequence:', error);
      setToast({ type: 'error', message: 'Failed to save sequence' });
    } finally {
      setSaving(false);
      clearLocalStorage();
      onDone?.();
    }
  };

  const handleExport = async (e?: React.MouseEvent) => {
    if (e && e.shiftKey) {
      // Shift-click: export Markdown
      const sequence = {
        title: sequenceName,
        duration: sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0),
        intent: intention, // <-- use 'intent' for backend/export
        level,
        sections: sections.map(section => ({ title: section.name, poses: section.poses.map(({ id, ...pose }) => pose) })),
        rawMarkdown: ''
      };
      const markdown = exportToMarkdown(sequence, 'yoga');
      downloadAsFile(markdown, `yoga-sequence-custom`);
      clearLocalStorage();
      onDone?.();
      return;
    }
    // Default: export PDF
    setExporting(true);
    try {
      const sequence = {
        title: sequenceName,
        duration: sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0),
        intent: intention, // <-- use 'intent' for backend/export
        level,
        sections: sections.map(section => ({ title: section.name, poses: section.poses.map(({ id, ...pose }) => pose) })),
        rawMarkdown: ''
      };
      await exportToPDF(sequence, poseImages as Record<string, string>);
      clearLocalStorage();
      onDone?.();
    } catch (err) {
      alert('Failed to export PDF');
    } finally {
      setExporting(false);
    }
  };

  const handleShare = async () => {
    try {
      const sequence = {
        title: sequenceName,
        duration: sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0),
        intent: intention, // <-- use 'intent' for backend/share
        level,
        sections: sections.map(section => ({ title: section.name, poses: section.poses.map(({ id, ...pose }) => pose) })),
        rawMarkdown: ''
      };
      const markdown = exportToMarkdown(sequence, 'yoga');
      await navigator.clipboard.writeText(markdown);
      alert('Sequence copied to clipboard!');
      clearLocalStorage();
      onDone?.();
    } catch (error) {
      console.error('Error sharing sequence:', error);
      alert('Failed to copy sequence to clipboard');
    }
  };

  // --- Builder View ---
  if (view === 'builder') {
    return (
      <div className="max-w-5xl mx-auto py-8">
        {/* Toast notification */}
        {toast && (
          <div className={`fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-full shadow-lg text-white text-base font-semibold transition-all duration-300 ${toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'}`}>
            {toast.message}
          </div>
        )}
        {/* Metadata fields at the top */}
        <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-primary-200 font-semibold mb-2" htmlFor="title-input">Sequence Title</label>
            <Input
              id="title-input"
              value={sequenceName}
              onChange={e => setSequenceName(e.target.value)}
              className="w-full text-base px-3 py-2 rounded-lg border-2 border-primary-700 bg-primary-900 text-primary-100"
            />
          </div>
          <div>
            <label className="block text-primary-200 font-semibold mb-2" htmlFor="intention-input">Sequence Intent</label>
            <Input
              id="intention-input"
              value={intention}
              onChange={e => setIntention(e.target.value)}
              placeholder="Describe your intention for this session. You are free to create anything: a yoga flow, a meditation, a breathwork journey, a long silent retreat, or something entirely new. For example: '5 hour meditation', 'deep relaxation', 'energy boost', 'open heart', or even 'creative writing block'. Your session can be as long, short, or unique as you wish! Let your imagination guide you."
              className="w-full text-base px-3 py-2 rounded-lg border-2 border-primary-700 bg-primary-900 text-primary-100"
            />
          </div>
          <div>
            <label className="block text-primary-200 font-semibold mb-2" htmlFor="level-input">Level</label>
            <select
              id="level-input"
              value={level}
              onChange={e => setLevel(e.target.value)}
              className="w-full text-base px-3 py-2 rounded-lg border-2 border-primary-700 bg-primary-900 text-primary-100"
            >
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>
        {/* Toolbar */}
        <div className="flex gap-2 mb-8">
          <Button variant="outline" leftIcon={<Save size={16} />} onClick={handleSave} disabled={saving || sections.every(s => s.poses.length === 0)} isLoading={saving}>Save</Button>
          <Button variant="outline" leftIcon={<Download size={16} />} onClick={handleExport} disabled={sections.every(s => s.poses.length === 0) || exporting} isLoading={exporting}>Export</Button>
          <Button variant="outline" leftIcon={<Share2 size={16} />} onClick={handleShare} disabled={sections.every(s => s.poses.length === 0)}>Share</Button>
          <Button variant="outline" leftIcon={<Plus size={16} />} onClick={handleAddSection}>Add Section</Button>
          <Button variant="outline" onClick={() => {
            clearLocalStorage();
            setSections([{ id: generateUniqueId(), name: 'Section 1', poses: [] }]);
            setSequenceName('Custom Yoga Sequence');
            setIntention('');
            setLevel('beginner');
            onDone?.();
          }}>{(initialSections || initialSequenceName || initialIntention || initialLevel) ? 'Exit Editing Mode' : 'Clear'}</Button>
        </div>
        {/* Render each section */}
        <div className="space-y-12">
          {sections.map((section, sectionIdx) => (
            <div key={section.id} className="rounded-2xl bg-gradient-to-br from-primary-900/10 to-primary-900/30 p-8 shadow-lg">
              <div className="flex items-center gap-4 mb-6">
                <input
                  type="text"
                  value={section.name}
                  onChange={e => handleRenameSection(section.id, e.target.value)}
                  className="text-lg font-bold bg-transparent border-b-2 border-primary-400 focus:outline-none focus:border-primary-600 text-primary-100 flex-1 min-w-0"
                  style={{ maxWidth: 320 }}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemoveSection(section.id)}
                  disabled={sections.length === 1}
                  className="text-red-400 hover:text-red-500"
                >
                  <Trash2 size={18} />
                </Button>
              </div>
              <DndContext collisionDetection={closestCenter} onDragEnd={event => handleDragEnd(section.id, event)}>
                <SortableContext items={section.poses.map(p => p.id)} strategy={rectSortingStrategy}>
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {section.poses.map((pose, index) => (
                  <div key={pose.id} className="relative">
                    <div className="absolute -top-3 -left-3 bg-primary-700 text-primary-100 rounded-full w-7 h-7 flex items-center justify-center font-bold shadow text-sm z-10">
                      {index + 1}
                    </div>
                    <SortablePose
                      pose={pose}
                          onRemove={() => handleRemovePose(section.id, pose.id)}
                          onDurationChange={duration => handleDurationChange(section.id, pose.id, duration)}
                    />
                  </div>
                ))}
                {/* Add pose card (not draggable) */}
                <button
                  className="flex flex-col items-center justify-center border-2 border-dashed border-primary-400 rounded-2xl bg-primary-900/10 hover:bg-primary-900/20 transition-colors text-primary-400 text-xl font-semibold gap-2 min-h-[260px] h-full py-8"
                      onClick={() => setView({ type: 'pose-select', sectionId: section.id })}
                  style={{ minHeight: '260px' }}
                >
                  <div className="w-20 h-20 bg-primary-200/40 rounded-xl flex items-center justify-center text-primary-300 text-3xl font-bold mb-4 mt-2">
                    <Plus size={36} />
                  </div>
                  <span className="font-semibold text-lg">Add pose</span>
                </button>
              </div>
            </SortableContext>
          </DndContext>
          <div className="flex justify-between items-center mt-8 w-full">
            <div className="text-sm text-gray-500 dark:text-gray-400">
                  Section Duration: {section.poses.reduce((total, pose) => total + (pose.durationInSeconds / 60), 0)} minutes
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-end mt-8">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Total Duration: {sections.reduce((total, section) => total + section.poses.reduce((t, pose) => t + (pose.durationInSeconds / 60), 0), 0)} minutes
          </div>
        </div>
      </div>
    );
  }

  // --- Pose Selection View ---
  if (typeof view === 'object' && 'type' in view && view.type === 'pose-select') {
    const sectionId = view.sectionId;
  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-primary-900/90 to-primary-800/90 flex flex-col min-h-screen overflow-y-auto">
      {/* Top bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 p-6 border-b border-primary-800 bg-primary-900/80 sticky top-0 z-30 backdrop-blur-md">
        <Button variant="ghost" onClick={() => setView('builder')} leftIcon={<Home size={18} />} className="text-primary-700 dark:text-primary-200 font-semibold hover:bg-primary-200/40 dark:hover:bg-primary-800/40">Back to Sequence</Button>
        <div className="w-full sm:w-80">
          <Input placeholder="Search by name or Sanskrit..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} leftIcon={<Search size={18} />} className="w-full" />
        </div>
        <select className="w-full sm:w-auto ml-0 sm:ml-4 px-3 py-2 rounded-lg border border-primary-700 bg-primary-900 text-primary-100" value={poseFilter} onChange={e => setPoseFilter(e.target.value)}>
          <option value="">All Categories</option>
          {allPoseTypes.map(type => (<option key={type} value={type}>{type}</option>))}
        </select>
        <Button variant="outline" leftIcon={<Plus size={16} />} onClick={() => setShowCustomPoseModal(true)} className="ml-2">Create Custom Pose/Block</Button>
      </div>
      {/* User Poses Category */}
      <div className="w-full max-w-6xl mx-auto p-8">
        {userPosesLoading ? (
          <div className="text-primary-200 text-lg">Loading your custom poses...</div>
        ) : userPoses.length > 0 && (
          <div className="mb-8">
            <div className="font-bold text-primary-100 text-xl mb-4">My Poses & Blocks</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              {userPoses.map(pose => (
                <div key={pose.id} className="relative flex flex-col items-center justify-center rounded-2xl bg-primary-900/60 p-6 shadow-lg border-2 border-primary-800 gap-4">
                  <div className="absolute top-2 right-2">
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteUserPose(pose.id)} className="text-red-400 hover:text-red-500"><Trash2 size={16} /></Button>
                  </div>
                  <div className="w-48 h-48 bg-primary-700 rounded-xl flex items-center justify-center text-primary-300 text-3xl font-bold mb-4 overflow-hidden">
                    {'🧘'}
                  </div>
                  <div className="font-semibold text-primary-100 text-lg text-center">{pose.name}</div>
                  <div className="text-primary-300 text-sm italic text-center">{pose.sanskritName}</div>
                  <Button variant="outline" size="sm" onClick={() => handleAddPose(sectionId, pose)}>Add to Sequence</Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      {/* Built-in Poses */}
      <div className="flex-1 w-full max-w-6xl mx-auto p-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {filteredPoseCategories.length === 0 && (
          <div className="col-span-full text-center text-primary-200 text-lg mt-16">No poses found.</div>
        )}
        {filteredPoseCategories.map(category => (
          <React.Fragment key={category.name}>
            {category.poses.map(pose => {
              const imgUrl = pose.image ? (poseImages[`../assets/poses/${pose.image}`] as string | undefined) : undefined;
              return (
                <button key={pose.name} className="flex flex-col items-center justify-center rounded-2xl bg-primary-900/60 hover:bg-primary-800/80 p-6 shadow-lg transition-colors border-2 border-primary-800 gap-4" onClick={() => handleAddPose(sectionId, pose)}>
                  <div className="w-48 h-48 bg-primary-700 rounded-xl flex items-center justify-center text-primary-300 text-3xl font-bold mb-4 overflow-hidden">
                    {imgUrl ? (<img src={imgUrl} alt={pose.name} className="object-contain w-full h-full" />) : ('🧘')}
                  </div>
                  <div className="font-semibold text-primary-100 text-lg text-center">{pose.name}</div>
                  <div className="text-primary-300 text-sm italic text-center">{pose.sanskritName}</div>
                </button>
              );
            })}
          </React.Fragment>
        ))}
      </div>
      {/* Custom Pose Modal */}
      {showCustomPoseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70">
          <div className="bg-primary-900 rounded-2xl p-8 w-full max-w-lg shadow-xl relative">
            <button className="absolute top-4 right-4 text-primary-400 hover:text-primary-200" onClick={() => setShowCustomPoseModal(false)}><Trash2 size={20} /></button>
            <h2 className="text-2xl font-bold mb-4 text-primary-100">Create Custom Pose/Block</h2>
            <div className="space-y-4">
              <Input label="Name" value={customPoseForm.name} onChange={e => setCustomPoseForm((f: any) => ({ ...f, name: e.target.value }))} />
              <Input label="Sanskrit Name or Subtitle" value={customPoseForm.sanskritName} onChange={e => setCustomPoseForm((f: any) => ({ ...f, sanskritName: e.target.value }))} />
              <Input label="Duration (e.g. 2 minutes)" value={customPoseForm.duration} onChange={e => {
                const val = e.target.value;
                setCustomPoseForm((f: any) => ({ ...f, duration: val, durationInSeconds: parseDuration(val) || 60 }));
              }} />
              <Input label="Benefits / Description" value={customPoseForm.benefits} onChange={e => setCustomPoseForm((f: any) => ({ ...f, benefits: e.target.value }))} />
              <div>
                <label className="block text-primary-200 font-semibold mb-2">Instructions (one per line)</label>
                <textarea className="w-full rounded-lg border-2 border-primary-700 bg-primary-900 text-primary-100 p-2" rows={3} value={customPoseForm.instructions.join('\n')} onChange={e => setCustomPoseForm((f: any) => ({ ...f, instructions: e.target.value.split('\n') }))} />
              </div>
              <Input label="Intent/Purpose (optional)" value={customPoseForm.intentRelation} onChange={e => setCustomPoseForm((f: any) => ({ ...f, intentRelation: e.target.value }))} />
              {/* Optionally add audio/image fields here */}
              <Button variant="primary" onClick={handleCreateCustomPose} className="w-full mt-4">Save Custom Pose/Block</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
  }
};

export default SequenceBuilder; 