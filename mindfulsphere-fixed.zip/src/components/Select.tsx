import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps {
  label?: string;
  options: SelectOption[];
  error?: string;
  helperText?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  className?: string;
  disabled?: boolean;
}

const Select: React.FC<SelectProps> = ({
  label,
  options,
  error,
  helperText,
  value,
  defaultValue,
  onChange,
  className = '',
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [internalValue, setInternalValue] = useState(defaultValue || options[0]?.value || '');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedValue = value !== undefined ? value : internalValue;
  const selectedOption = options.find((o) => o.value === selectedValue) || options[0];

  useEffect(() => {
    if (!isOpen) return;
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [isOpen]);

  useEffect(() => {
    if (value !== undefined) {
      setInternalValue(value);
    }
  }, [value]);

  const handleSelect = (val: string) => {
    if (onChange) onChange(val);
    setInternalValue(val);
    setIsOpen(false);
  };

  return (
    <div className={`w-full relative ${className}`} ref={dropdownRef}>
      {label && (
        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1 tracking-tight">
          {label}
        </label>
      )}
      <button
        type="button"
        className={`w-full px-5 pr-8 py-3 bg-primary-50 dark:bg-primary-950 border-2 rounded-2xl shadow font-semibold text-base text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:border-primary-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 appearance-none flex items-center justify-between ${
          error
            ? 'border-danger text-danger focus:border-danger focus:ring-danger'
            : 'border-primary-400 dark:border-primary-500 focus:border-primary-500 focus:ring-primary-500'
        } ${disabled ? 'pointer-events-none opacity-60' : ''}`}
        onClick={() => setIsOpen((v) => !v)}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span>{selectedOption?.label}</span>
        <span className={`absolute right-4 top-1/2 -translate-y-1/2 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
          <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </span>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.ul
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="absolute left-0 right-0 bottom-full mb-2 z-50 bg-primary-50 dark:bg-primary-950 border-2 border-primary-300 dark:border-primary-700 rounded-2xl shadow-xl overflow-hidden max-h-72 overflow-y-auto scrollbar-none"
            role="listbox"
          >
            {options.map((option) => (
              <li
                key={option.value}
                role="option"
                aria-selected={selectedValue === option.value}
                tabIndex={0}
                className={`px-5 py-3 cursor-pointer font-semibold text-base transition-colors duration-150
                  ${selectedValue === option.value ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-200' : 'hover:bg-primary-100 dark:hover:bg-primary-900/40 text-gray-900 dark:text-gray-100'}`}
                onClick={() => handleSelect(option.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') handleSelect(option.value);
                }}
              >
                {option.label}
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
      {error && (
        <p className="mt-1 text-sm font-semibold text-danger dark:text-danger">{error}</p>
      )}
      {helperText && !error && (
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{helperText}</p>
      )}
    </div>
  );
};

export default Select;