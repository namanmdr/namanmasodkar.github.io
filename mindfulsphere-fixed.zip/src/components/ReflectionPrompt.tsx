import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './Card';
import Button from './Button';
import TextArea from './TextArea';
import { format } from 'date-fns';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, X } from 'lucide-react';

interface ReflectionPromptProps {
  sequenceTitle: string;
  sequenceIntent: string;
  yogaSessionId: string; // Add this prop
  onClose: () => void;
}

const ReflectionPrompt: React.FC<ReflectionPromptProps> = ({
  sequenceTitle,
  sequenceIntent,
  yogaSessionId, // Add this prop
  onClose
}) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [content, setContent] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!user || !content.trim()) return;

    try {
      setSaving(true);

      const title = `Reflection: ${sequenceTitle} - ${format(new Date(), 'MMMM d, yyyy')}`;
      const tags = ['yoga-reflection'];

      // First, save the reflection as a journal entry
      const { data: journalData, error: journalError } = await supabase
        .from('journal_entries')
        .insert({
          title,
          content,
          user_id: user.id,
          tags,
          mood: 'Reflective'
        })
        .select()
        .single();

      if (journalError) throw journalError;

      // Then, find and update the practice cycle
      const { error: cycleError } = await supabase
        .from('practice_cycles')
        .update({ 
          post_journal_id: journalData.id,
          completed: true 
        })
        .eq('yoga_session_id', yogaSessionId) // Use the prop here
        .eq('user_id', user.id);

      if (cycleError) throw cycleError;

      navigate(`/journal/${journalData.id}`);
    } catch (error) {
      console.error('Error saving reflection:', error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 backdrop-blur-lg animate-fade-in">
      <Card className="w-full max-w-2xl shadow-2xl rounded-3xl border-0 bg-white dark:bg-indigo-950/90">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl md:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-primary-600 via-indigo-500 to-purple-500 bg-clip-text text-transparent">Reflect on Your Practice</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-primary-500"
            >
              <X size={20} />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="p-6 rounded-2xl shadow-inner border border-gray-200 bg-white dark:bg-indigo-900/60 dark:border-none">
            <h3 className="font-semibold mb-3 text-primary-700 dark:text-white">Prompts for Reflection:</h3>
            <ul className="space-y-2 text-gray-800 dark:text-white">
              <li>• How did this practice make you feel physically and mentally?</li>
              <li>• What insights or awareness arose during the sequence?</li>
              {sequenceIntent && (
                <li>• How did the sequence's intent ("{sequenceIntent}") resonate with you?</li>
              )}
              <li>• What would you like to remember from this practice?</li>
            </ul>
          </div>

          <TextArea
            label="Your Reflection"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Share your thoughts and experiences from this practice..."
            rows={6}
            className="rounded-2xl shadow-lg dark:bg-indigo-900/60 dark:text-white"
          />
        </CardContent>
        <CardFooter className="flex justify-end space-x-4">
          <Button variant="outline" onClick={onClose}>
            Skip
          </Button>
          <Button
            variant="primary"
            onClick={handleSave}
            isLoading={saving}
            disabled={saving || !content.trim()}
            leftIcon={<BookOpen size={16} />}
          >
            Save in Journal
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ReflectionPrompt;