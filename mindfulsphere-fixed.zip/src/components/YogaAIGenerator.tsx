import { fnUrl } from '../lib/functions';
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './Card';
import Button from './Button';
import Select from './Select';
import TextArea from './TextArea';
import Input from './Input';
import { Clock, BarChart2, Check, ArrowRight, ArrowLeft, Play, Pause, AlertCircle, Info } from 'lucide-react';
import { generateYogaSequence, validateYogaSequence, sanitizeYogaSequence, createFallbackSequence } from '../lib/yoga';
import { supabase } from '../lib/supabase';
import { exportToMarkdown, downloadAsFile } from '../lib/export';
import { generateYogaSequenceTitleWithAIProxy } from '../lib/ai';
import parseDuration from '../utils/parseDuration'; // (You will create this util)

export interface YogaAIGeneratorProps {
  user: any;
  isSubscribed: boolean;
  freeYogaUsed: boolean | null;
  onSequenceGenerated: (sequence: any) => void;
  onSequenceSaved: () => void;
  intent: string;
  setIntent: (intent: string) => void;
  showCustomIntent: boolean;
  setShowCustomIntent: (show: boolean) => void;
  duration: string;
  setDuration: (duration: string) => void;
  level: string;
  setLevel: (level: string) => void;
  intentLoading?: boolean;
}

export const YogaAIGenerator = forwardRef<unknown, YogaAIGeneratorProps>(({ user, isSubscribed, freeYogaUsed, onSequenceGenerated, onSequenceSaved, intent, setIntent, showCustomIntent, setShowCustomIntent, duration, setDuration, level, setLevel, intentLoading }, ref) => {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [streamingContent, setStreamingContent] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [showOverageModal, setShowOverageModal] = useState(false);
  const [showGenericErrorModal, setShowGenericErrorModal] = useState(false);
  // Restore these as internal state:
  const [surpriseIntent, setSurpriseIntent] = useState('');
  const [isSurprising, setIsSurprising] = useState(false);
  const [showSurpriseModal, setShowSurpriseModal] = useState(false);
  const streamingContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isStreaming && streamingContentRef.current) {
      streamingContentRef.current.scrollTop = streamingContentRef.current.scrollHeight;
    }
  }, [streamingContent, isStreaming]);

  const PRESET_INTENTS = [
    'Release Stress',
    'Boost Energy',
    'Find Calm',
    'Sleep Better',
    'Improve Flexibility',
  ];

  const durationOptions = [
    { value: '10 minutes', label: '10 minutes' },
    { value: '15 minutes', label: '15 minutes' },
    { value: '20 minutes', label: '20 minutes' },
    { value: '30 minutes', label: '30 minutes' },
    { value: '45 minutes', label: '45 minutes' },
    { value: '60 minutes', label: '60 minutes' },
    { value: '90 minutes', label: '90 minutes' },
    { value: '__custom__', label: 'Custom...' },
  ];
  const [durationMode, setDurationMode] = useState(durationOptions[0].value);
  const [durationText, setDurationText] = useState(durationOptions[0].value);
  const parsedDuration = parseDuration(durationText);

  const levelOptions = [
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  const handleGenerateSequence = async () => {
    if (!user) {
      return;
    }
    
    if (loading || isStreaming) {
      return;
    }
    
    // For subscribed users, freeYogaUsed should be false
    // For non-subscribed users, freeYogaUsed should be a boolean
    if (!isSubscribed && freeYogaUsed === null) {
      setLoading(true);
      // Wait a bit for freeYogaUsed to load
      setTimeout(() => {
        setLoading(false);
        // Try again if it's still null
        if (freeYogaUsed === null) {
          return;
        }
        handleGenerateSequence();
      }, 1000);
      return;
    }
    
    if (!isSubscribed && freeYogaUsed === true) {
      setShowSubscribeModal(true);
      setIsStreaming(false);
      setLoading(false);
      return;
    }
    
    setLoading(true);
    setErrorMessage('');
    setStreamingContent('');
    setIsStreaming(true);
    try {
      let generatedIntent = intent;
      // In handleGenerateSequence, use parsedDuration instead of parseInt(duration)
      let sequence = await generateYogaSequence(
        parsedDuration,
        level,
        generatedIntent,
        (chunk) => {
          setStreamingContent(prev => prev + chunk);
        }
      );
      
      // Validate and sanitize the sequence
      const validation = validateYogaSequence(sequence);
      if (!validation.isValid) {
        console.warn('Generated sequence has validation errors:', validation.errors);
        // Create a fallback sequence if the generated one is invalid
        sequence = createFallbackSequence(parsedDuration, level, generatedIntent);
      } else {
        // Sanitize the sequence to ensure all fields are properly set
        sequence = sanitizeYogaSequence(sequence);
      }
      
      // Save to DB
      const { data: yogaData, error: yogaError } = await supabase
        .from('yoga_sessions')
        .insert({
          title: '',
          duration: sequence.duration,
          level: sequence.level,
          intent: sequence.intent,
          user_id: user.id,
          sequence: sequence,
          completed: false
        })
        .select()
        .single();
      if (yogaError || !yogaData) {
        setErrorMessage('Failed to save sequence.');
        setShowGenericErrorModal(true);
        return;
      }
      // Generate AI title
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      let aiTitle = '';
      if (accessToken) {
        aiTitle = await generateYogaSequenceTitleWithAIProxy(sequence, accessToken);
        if (aiTitle) {
          await supabase
            .from('yoga_sessions')
            .update({ title: aiTitle })
            .eq('id', yogaData.id);
        }
      }
      onSequenceGenerated({ ...sequence, title: aiTitle });
      onSequenceSaved();
    } catch (error: any) {
      const msg = error instanceof Error ? error.message : String(error);
      console.error('Error generating sequence:', error);
      if (msg.includes('usage limit')) {
        setShowOverageModal(true);
      } else if (msg.includes('subscribed')) {
        setShowSubscribeModal(true);
      } else {
        setErrorMessage(msg);
        setShowGenericErrorModal(true);
      }
    } finally {
      setIsStreaming(false);
      setStreamingContent('');
      setLoading(false);
    }
  };

  const handleSurpriseMe = async () => {
    if (!isSubscribed) {
      setShowSubscribeModal(true);
      return;
    }
    setIsSurprising(true);
    setShowSurpriseModal(true);
    setSurpriseIntent('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      if (!accessToken) throw new Error('No access token');
      const prompt = `You are a creative yoga teacher. Randomly generate a unique, coherent, focused intent for a yoga session. Choose from a wide variety of categories, such as: breathwork, meditation, playfulness, balance, strength, flexibility, gratitude, self-compassion, energy, stillness, laughter yoga, sound, visualization, mantra, partner yoga, animal-inspired movement, elemental themes (earth, water, fire, air, space), chakras, inversions, restorative, mobility, or any other wild or unexpected focus. Make it inspiring, specific, and a little surprising. Return only the intent, 1-2 sentences.`;
      const response = await fetch(fnUrl('ai_proxy'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          messages: [{ role: 'user', content: prompt }],
          model: 'gpt-4.1',
          max_tokens: 256,
          temperature: 0.7,
        }),
      });
      const data = await response.json();
      setSurpriseIntent(data.choices?.[0]?.message?.content?.trim() || '');
    } catch (e) {
      setSurpriseIntent('Could not generate a surprise intent. Try again!');
    } finally {
      setIsSurprising(false);
    }
  };

  // Expose a reset() method to parent via ref
  useImperativeHandle(ref, () => ({
    reset: () => {
      setDuration('20');
      setLevel('intermediate');
      setLoading(false);
      setErrorMessage('');
      setStreamingContent('');
      setIsStreaming(false);
      setShowSubscribeModal(false);
      setShowOverageModal(false);
      setShowGenericErrorModal(false);
      setShowCustomIntent(false);
      setSurpriseIntent('');
      setIsSurprising(false);
      setShowSurpriseModal(false);
    }
  }), []);

  // Reset state when component mounts
  useEffect(() => {
    setLoading(false);
    setErrorMessage('');
    setStreamingContent('');
    setIsStreaming(false);
    setShowSubscribeModal(false);
    setShowOverageModal(false);
    setShowGenericErrorModal(false);
    setShowCustomIntent(false);
    setSurpriseIntent('');
    setIsSurprising(false);
    setShowSurpriseModal(false);
  }, []);

  // Debug freeYogaUsed changes
  useEffect(() => {
  }, [freeYogaUsed]);

  // Debug isSubscribed changes
  useEffect(() => {
  }, [isSubscribed]);

  // Helper to split content into lines for animation
  const streamingLines = streamingContent.split(/\n+/).filter(Boolean);

  // Debug button state
  const buttonDisabled = loading || isStreaming;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Create Your Sequence</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1 tracking-tight">Duration</label>
            <Select
              label={undefined}
              options={durationOptions}
              value={durationMode}
              onChange={val => {
                setDurationMode(val);
                if (val !== '__custom__') {
                  setDurationText(val);
                  setDuration(val);
                } else {
                  setDurationText('');
                  setDuration('');
                }
              }}
              placeholder="Select duration"
            />
            {durationMode === '__custom__' && (
              <Input
                label={undefined}
                value={durationText}
                onChange={e => {
                  setDurationText(e.target.value);
                  setDuration(e.target.value);
                }}
                placeholder="e.g. 2 hours, 90 min, 1h 30m, 5 hour meditation"
                className="mt-2"
              />
            )}
          </div>
          <Select
            label="Experience Level"
            options={levelOptions}
            value={level}
            onChange={setLevel}
          />
        </div>
        {/* Preset Intents */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1 tracking-tight">Session Intent</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {PRESET_INTENTS.map((preset) => (
              <button
                key={preset}
                type="button"
                className={`px-4 py-2 rounded-full font-semibold border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary-400 ${intent === preset && !showCustomIntent ? 'bg-primary-600 text-white border-primary-600' : 'bg-primary-50 dark:bg-primary-950 text-primary-700 dark:text-primary-200 border-primary-300 dark:border-primary-700 hover:bg-primary-100 dark:hover:bg-primary-900'}`}
                onClick={() => {
                  setIntent(preset);
                  setShowCustomIntent(false);
                }}
              >
                {preset}
              </button>
            ))}
            {/* Breathwork button */}
            <button
              type="button"
              className={`px-4 py-2 rounded-full font-semibold border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 ${intent === '__breathwork__' ? 'bg-blue-600 text-white border-blue-600' : 'bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-200 border-blue-300 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900'}`}
              onClick={() => {
                setIntent('No yoga poses, only pranayama, breathwork, or breathing exercises. Focus on breath awareness and control.');
                setShowCustomIntent(false);
              }}
            >
              Breathwork
            </button>
            {/* Meditation button */}
            <button
              type="button"
              className={`px-4 py-2 rounded-full font-semibold border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-purple-400 ${intent === '__meditation__' ? 'bg-purple-600 text-white border-purple-600' : 'bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-200 border-purple-300 dark:border-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900'}`}
              onClick={() => {
                setIntent('No yoga poses, only a meditation, inspired from a variety of sources, practices, and traditions. Focus on mindfulness, visualization, or contemplation.');
                setShowCustomIntent(false);
              }}
            >
              Meditation
            </button>
            {/* Surprise Me button */}
            <button
              type="button"
              className={`px-4 py-2 rounded-full font-semibold border-2 border-indigo-400 bg-gradient-to-r from-indigo-400 to-purple-400 text-white transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-300 hover:from-indigo-500 hover:to-purple-500 ${intent === '__surprise__' ? 'ring-2 ring-indigo-400' : ''}`}
              onClick={handleSurpriseMe}
              disabled={isSurprising}
            >
              {isSurprising ? 'Generating...' : '🎲 Surprise Me'}
            </button>
            {/* Custom intent button */}
            <button
              type="button"
              aria-label="Custom intent"
              className={`px-5 py-2 rounded-full font-bold border-2 border-indigo-500 transition-all duration-200 transform focus:outline-none focus:ring-2 focus:ring-indigo-300 hover:scale-105 hover:shadow-xl active:scale-100 ${showCustomIntent ? 'bg-white text-indigo-700 ring-2 ring-indigo-300' : 'bg-white text-indigo-700 dark:bg-indigo-950 dark:text-indigo-200'}`}
              style={!showCustomIntent ? { boxShadow: '0 4px 16px 0 rgba(99,102,241,0.16)' } : {}}
              onClick={() => {
                setShowCustomIntent(true);
                setIntent('');
              }}
            >
              <span className="mr-2 text-lg align-middle" role="img" aria-label="pencil">🖊️</span>Custom...
            </button>
          </div>
          {showCustomIntent && (
            intentLoading ? (
              <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400 min-h-[120px]">
                <span className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-500" />
                Generating intention...
              </div>
            ) : (
              <TextArea
                label={undefined}
                value={intent}
                onChange={(e) => setIntent(e.target.value)}
                placeholder="Describe your intention for this session. You are free to create anything: a yoga flow, a meditation, a breathwork journey, a long silent retreat, or something entirely new. For example: '5 hour meditation', 'deep relaxation', 'energy boost', 'open heart', or even 'creative writing block'. Your session can be as long, short, or unique as you wish! Let your imagination guide you."
                rows={6}
                style={{ minHeight: '120px', resize: 'vertical' }}
                disabled={intentLoading}
              />
            )
          )}
        </div>
        {/* Surprise Modal */}
        {showSurpriseModal && (
          <div className="fixed inset-0 z-100 flex items-center justify-center bg-transparent animate-fade-in">
            <div className="bg-gradient-to-br from-primary-50 via-purple-50 to-indigo-100 dark:from-gray-900 dark:via-primary-950 dark:to-indigo-950 rounded-3xl p-10 max-w-md w-full text-center shadow-2xl border-0 relative transition-all duration-300 scale-100 animate-slide-up">
              <button
                className="absolute top-4 right-4 text-gray-400 hover:text-primary-500 dark:hover:text-primary-400 text-2xl font-bold focus:outline-none focus:ring-2 focus:ring-primary-400 rounded-full w-10 h-10 flex items-center justify-center"
                onClick={() => setShowSurpriseModal(false)}
                aria-label="Close"
              >
                &times;
              </button>
              <h2 className="text-2xl md:text-3xl font-extrabold mb-4 tracking-tight bg-gradient-to-r from-primary-600 via-indigo-500 to-purple-500 bg-clip-text text-transparent font-sora">
                Surprise Yoga Intent!
              </h2>
              <div className="mb-6 text-base text-gray-700 dark:text-gray-300 font-sora max-h-[60vh] overflow-y-auto scrollbar-thin scrollbar-thumb-indigo-300 scrollbar-track-transparent">
                <div className="text-lg text-indigo-700 dark:text-indigo-300 min-h-[48px] flex items-center justify-center">
                  {isSurprising ? <span className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-500 mr-2" /> : null}
                  {surpriseIntent}
                </div>
              </div>
              <div className="flex justify-center gap-4">
                <Button variant="primary" onClick={() => { setIntent(surpriseIntent || ''); setShowCustomIntent(true); setShowSurpriseModal(false); }} disabled={!surpriseIntent || isSurprising}>
                  Use This Intent
                </Button>
                <Button variant="outline" onClick={handleSurpriseMe} disabled={isSurprising}>
                  {isSurprising ? 'Generating...' : 'Reroll'}
                </Button>
              </div>
            </div>
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-4 rounded-md flex items-start">
            <AlertCircle className="shrink-0 mr-3 mt-1" size={20} />
            <div>{errorMessage}</div>
          </div>
        )}
        {isStreaming && streamingContent && (
          <Card className="max-w-2xl mx-auto mt-8 animate-fadein">
            <CardHeader>
              <CardTitle>Generating Sequence...</CardTitle>
            </CardHeader>
            <CardContent>
              {intent && (
                <div className="mb-4 p-3 rounded-lg bg-indigo-50 dark:bg-indigo-900/30 text-indigo-900 dark:text-indigo-200 shadow-inner text-left">
                  <span className="font-semibold">Intent:</span> {intent}
                </div>
              )}
              <div
                ref={streamingContentRef}
                className="prose prose-indigo dark:prose-invert max-w-none whitespace-pre-wrap transition-all duration-300 overflow-y-auto max-h-64 hide-scrollbar"
                style={{ minHeight: '6rem' }}
              >
                {streamingLines.map((line, idx) => (
                  <div key={idx} className="stream-fade-in" style={{ animationDelay: `${idx * 0.04}s` }}>{line}</div>
                ))}
              </div>
              <div className="flex items-center mt-4 text-indigo-500 dark:text-indigo-300">
                Generating, please wait...
              </div>
            </CardContent>
          </Card>
        )}
        {loading && !isStreaming && (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-300">Generating your personalized sequence...</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          variant="primary"
          onClick={handleGenerateSequence}
          isLoading={loading || isStreaming}
          disabled={
            loading ||
            isStreaming
            // Removed: (!isSubscribed && freeYogaUsed === null)
            // This was causing the button to be disabled when freeYogaUsed was null
          }
          className="w-full"
        >
          Generate Sequence
        </Button>
      </CardFooter>
      {/* Subscribe Modal */}
      {showSubscribeModal && (
        <div className="fixed inset-0 z-100 flex items-center justify-center bg-black bg-opacity-40">
          <div className="bg-white dark:bg-gray-900 rounded-3xl p-10 max-w-md w-full text-center shadow-2xl border-0 relative transition-all duration-300 scale-100 animate-slide-up">
            <h2 className="text-2xl font-bold mb-4">Subscribe to Unlock AI Features</h2>
            <p className="mb-6">You need an active subscription to use AI-powered features like sequence and title generation.</p>
            <Button variant="primary" onClick={() => window.location.href = '/pricing'}>View Plans</Button>
            <Button variant="outline" onClick={() => setShowSubscribeModal(false)} className="ml-4">Cancel</Button>
          </div>
        </div>
      )}
    </Card>
  );
}); 