import React, { useRef, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Flower2 as Lotus, Heart, Moon, Sun, Sparkles, LogOut, Menu, X, Settings, BookOpen, Plus, Landmark as Temple, PenTool } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Layout: React.FC = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    if (isMenuOpen) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [isMenuOpen]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const handleSignOut = async () => {
    await signOut();
    closeMenu();
    navigate('/');
  };

  const navLinks = [
    { path: '/', label: 'Sanctuary', icon: <Temple size={20} /> },
    { path: '/yoga', label: 'Sacred Practice', icon: <Lotus size={20} /> },
    { path: '/journal', label: 'Inner Reflections', icon: <Heart size={20} /> },
    { path: '/blog', label: 'Wisdom Blog', icon: <PenTool size={20} /> },
    { path: '/content', label: 'Knowledge Base', icon: <BookOpen size={20} /> },
    { path: '/profile', label: 'Soul Settings', icon: <Sparkles size={20} /> }
  ];

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-primary-50 via-purple-100 to-indigo-100 dark:from-gray-950 dark:via-purple-950 dark:to-indigo-950 text-gray-900 dark:text-gray-100 font-sora transition-colors duration-500">
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg shadow-lg sticky top-0 z-20 rounded-b-3xl border-b border-primary-100 dark:border-primary-900/40 transition-colors duration-500">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 group" onClick={closeMenu}>
            <Lotus className="text-primary-600 dark:text-primary-400 group-hover:scale-110 transition-transform" size={32} />
            <span className="text-2xl font-extrabold tracking-tight bg-gradient-to-r from-primary-600 via-indigo-500 to-purple-500 bg-clip-text text-transparent">MindfulSphere</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30 focus:ring-2 focus:ring-primary-400 transition-colors duration-300"
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {theme === 'dark' ? <Sun size={22} /> : <Moon size={22} />}
            </button>
            
            {user && (
              <div className="hidden md:block">
                <div className="flex items-center space-x-4">
                  {navLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-full font-semibold shadow-sm transition-all duration-300 ${
                        isActive(link.path)
                          ? 'bg-gradient-to-r from-primary-100 to-indigo-100 dark:from-primary-900/40 dark:to-indigo-900/30 text-primary-700 dark:text-primary-200 shadow-md'
                          : 'hover:bg-primary-50 dark:hover:bg-primary-900/20 text-gray-700 dark:text-gray-200'
                      }`}
                    >
                      {link.icon}
                      <span>{link.label}</span>
                    </Link>
                  ))}
                  <button
                    onClick={handleSignOut}
                    className="flex items-center space-x-2 px-4 py-2 rounded-full font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 shadow-sm transition-colors duration-300"
                  >
                    <LogOut size={20} />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
            
            <button
              className="md:hidden p-2 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30 focus:ring-2 focus:ring-primary-400 transition-colors duration-300"
              onClick={toggleMenu}
              aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMenuOpen ? <X size={26} /> : <Menu size={26} />}
            </button>
          </div>
        </div>
      </header>

      {isMenuOpen && user && (
        <div
          ref={menuRef}
          className="md:hidden bg-white/90 dark:bg-gray-900/90 backdrop-blur-lg shadow-xl rounded-b-3xl border-b border-primary-100 dark:border-primary-900/40 transition-colors duration-300"
        >
          <div className="container mx-auto px-4 py-2">
            <nav className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center space-x-3 px-6 py-3 rounded-full font-semibold shadow-sm transition-all duration-300 ${
                    isActive(link.path)
                      ? 'bg-gradient-to-r from-primary-100 to-indigo-100 dark:from-primary-900/40 dark:to-indigo-900/30 text-primary-700 dark:text-primary-200 shadow-md'
                      : 'hover:bg-primary-50 dark:hover:bg-primary-900/20 text-gray-700 dark:text-gray-200'
                  }`}
                  onClick={closeMenu}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </Link>
              ))}
              <button
                onClick={handleSignOut}
                className="flex items-center space-x-3 px-6 py-3 rounded-full font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 shadow-sm transition-colors duration-300"
              >
                <LogOut size={20} />
                <span>Logout</span>
              </button>
            </nav>
          </div>
        </div>
      )}

      <main className="flex-1 container mx-auto px-4 py-10 md:py-16">
        <Outlet />
      </main>

      <footer className="bg-white/80 dark:bg-gray-900/80 border-t border-gray-200 dark:border-gray-800 py-8 mt-16">
        <div className="max-w-4xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-gray-600 dark:text-gray-400 text-sm">
          <div className="mb-4 md:mb-0">&copy; {new Date().getFullYear()} MindfulSphere. All rights reserved.</div>
          <div className="flex space-x-6">
            <Link to="/about" className="hover:text-indigo-600">About</Link>
            <Link to="/contact" className="hover:text-indigo-600">Contact</Link>
            <Link to="/privacy-policy" className="hover:text-indigo-600">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-indigo-600">Terms of Service</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;