import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './Card';
import Button from './Button';
import Input from './Input';
import { Clock, BarChart2, Edit2, Save, X, Download, Share2, Trash2 } from 'lucide-react';
import { exportToMarkdown, downloadAsFile, exportToPDF } from '../lib/export';
import { format } from 'date-fns';

export interface YogaSequenceHistoryProps {
  user: any;
  savedSequences: any[];
  onEditTitle: (id: string, newTitle: string) => void;
  onDeleteSequence: (id: string) => void;
  onExport: (sequence: any) => void;
  onShare: (sequence: any) => void;
  onLoadSequence: (sequence: any) => void;
  onEditSequence?: (sequence: any) => void;
}

export const YogaSequenceHistory: React.FC<YogaSequenceHistoryProps> = ({ user, savedSequences, onEditTitle, onDeleteSequence, onExport, onShare, onLoadSequence, onEditSequence }) => {
  // Remove all state and handlers related to inline title editing
  // const [editingTitleId, setEditingTitleId] = useState<string | null>(null);
  // const [editedTitle, setEditedTitle] = useState('');
  // const handleEditTitle = (sequence: any) => { ... }
  // const handleSaveTitle = (id: string) => { ... }
  // const handleCancelEdit = () => { ... }
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [sequenceToDelete, setSequenceToDelete] = useState<string | null>(null);
  const [showDeleteErrorModal, setShowDeleteErrorModal] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [showCopyToast, setShowCopyToast] = useState(false);
  const poseImages = import.meta.glob('../assets/poses/*.png', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
  const [exportingId, setExportingId] = useState<string | null>(null);

  // const handleEditTitle = (sequence: any) => {
  //   setEditingTitleId(sequence.id);
  //   setEditedTitle(sequence.title);
  // };

  // const handleSaveTitle = (id: string) => {
  //   onEditTitle(id, editedTitle);
  //   setEditingTitleId(null);
  // };

  // const handleCancelEdit = () => {
  //   setEditingTitleId(null);
  //   setEditedTitle('');
  // };

  const handleDeleteSequence = (id: string) => {
    setSequenceToDelete(id);
    setShowDeleteModal(true);
  };

  const confirmDeleteSequence = () => {
    if (!sequenceToDelete) return;
    onDeleteSequence(sequenceToDelete);
    setShowDeleteModal(false);
    setSequenceToDelete(null);
  };

  const handleExport = async (saved: any, e?: React.MouseEvent) => {
    const sequence = saved.sequence || saved;
    if (!sequence || !sequence.sections || !Array.isArray(sequence.sections) || !sequence.sections[0]) {
      alert('This sequence is missing details and cannot be exported.');
      console.warn('Attempted to export invalid sequence:', saved);
      return;
    }
    if (e && e.shiftKey) {
      // Shift-click: export Markdown
      const markdown = exportToMarkdown(sequence, 'yoga');
      downloadAsFile(markdown, `yoga-sequence-${sequence.title || 'custom'}`);
      return;
    }
    setExportingId(saved.id);
    try {
      // Pass saved.title as dbTitle to exportToPDF
      await exportToPDF(sequence, poseImages, saved.title);
    } catch (err) {
      alert('Failed to export PDF');
    } finally {
      setExportingId(null);
    }
  };

  const handleShare = async (sequence: any) => {
    try {
      onShare(sequence);
      setShowCopyToast(true);
      setTimeout(() => setShowCopyToast(false), 2000);
    } catch (error) {
      setDeleteError('Failed to copy sequence to clipboard');
      setShowDeleteErrorModal(true);
      console.error('Error sharing sequence:', error);
    }
  };

  const visibleSequences = savedSequences.filter(seq => seq.title && seq.title.trim() !== '');

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Your Saved Sequences</h2>
      {visibleSequences.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300">
              You haven't generated any sequences yet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {visibleSequences.map((saved) => (
            <Card key={saved.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{saved.title}</CardTitle>
                  {onEditSequence && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEditSequence(saved)}
                      leftIcon={<Edit2 size={16} />}
                      title="Edit Sequence"
                    />
                  )}
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {format(new Date(saved.created_at), 'MMM d, yyyy')}
                </p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300">
                  <span className="flex items-center">
                    <Clock size={14} className="mr-1" />
                    {saved.duration}m
                  </span>
                  <span className="flex items-center">
                    <BarChart2 size={14} className="mr-1" />
                    {saved.level}
                  </span>
                </div>
                {saved.intent && (
                  <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                    <strong>Intent:</strong> {saved.intent}
                  </p>
                )}
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 justify-between items-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onLoadSequence(saved)}
                >
                  Start Practice
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => handleExport(saved, e)}
                  leftIcon={<Download size={16} />}
                  isLoading={exportingId === saved.id}
                  disabled={exportingId === saved.id}
                >
                  Export
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleShare(saved)}
                  leftIcon={<Share2 size={16} />}
                >
                  Share
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30"
                  onClick={() => handleDeleteSequence(saved.id)}
                >
                  <Trash2 size={16} />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      {/* Modals and Toasts */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-100 flex items-center justify-center bg-transparent animate-fade-in">
          <div className="bg-white dark:bg-gray-900 rounded-3xl p-10 max-w-md w-full text-center shadow-2xl border-0 relative transition-all duration-300 scale-100 animate-slide-up">
            <h2 className="text-2xl font-bold mb-4">Delete Sequence</h2>
            <p>Are you sure you want to delete this sequence?</p>
            <div className="flex justify-center gap-4 mt-6">
              <Button variant="danger" onClick={confirmDeleteSequence}>Delete</Button>
              <Button variant="outline" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
            </div>
          </div>
        </div>
      )}
      {showDeleteErrorModal && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-red-600 text-white px-6 py-3 rounded-full shadow-lg z-50 animate-fade-in">
          {deleteError}
        </div>
      )}
      {showCopyToast && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-primary-600 text-white px-6 py-3 rounded-full shadow-lg z-50 animate-fade-in">
          Sequence copied to clipboard!
        </div>
      )}
    </div>
  );
} 