import React, { useEffect, useState } from 'react';
import { format, getISOWeek, getYear, getMonth, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isBefore, isAfter, endOfDay, endOfMonth as dfEndOfMonth, endOfWeek as dfEndOfWeek } from 'date-fns';
import { Tag, Quote, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import Button from './Button';
import {
  generateJournalAnalysisWithAIProxy
} from '../lib/ai';
import { supabase } from '../lib/supabase';

function groupByWeek(entries: any[]): Record<string, any[]> {
  const groups: Record<string, any[]> = {};
  entries.forEach((entry: any) => {
    const date = new Date(entry.created_at);
    const year = getYear(date);
    const week = getISOWeek(date);
    const key = `${year}-W${week}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(entry);
  });
  return groups;
}
function groupByMonth(entries: any[]): Record<string, any[]> {
  const groups: Record<string, any[]> = {};
  entries.forEach((entry: any) => {
    const date = new Date(entry.created_at);
    const year = getYear(date);
    const month = getMonth(date) + 1;
    const key = `${year}-${month.toString().padStart(2, '0')}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(entry);
  });
  return groups;
}
function getWeekRange(entries: any[]): string {
  if (!entries.length) return '';
  const start = startOfWeek(new Date(entries[0].created_at), { weekStartsOn: 1 });
  const end = endOfWeek(new Date(entries[0].created_at), { weekStartsOn: 1 });
  return `${format(start, 'MMM d')} – ${format(end, 'MMM d, yyyy')}`;
}
function getMonthRange(entries: any[]): string {
  if (!entries.length) return '';
  const start = startOfMonth(new Date(entries[0].created_at));
  const end = endOfMonth(new Date(entries[0].created_at));
  return `${format(start, 'MMM 1')} – ${format(end, 'MMM d, yyyy')}`;
}
const aiReflectionPrompt = (type: 'week' | 'month', content: string): string => {
  if (type === 'week') {
    return `You are an insightful mindfulness coach. Carefully read the user's journal entries for this week (below). Write a summary paragraph that mentions at least two specific events, activities, moods, or tags that actually appeared in the entries. Avoid generic or vague statements. Highlight concrete moments, feelings, or patterns. Then, list the top 3 emotional themes as tags, and finally provide a short, uplifting quote or affirmation. Format:
\nTitle: <short poetic title for the week>\nSummary: <paragraph>\nTags: <comma-separated>\nQuote: <short quote or affirmation>\n\nJOURNAL ENTRIES:\n` + content;
  } else {
    return `You are an insightful mindfulness coach. Carefully read the user's journal entries for this month (below). Write a summary paragraph that mentions at least two specific events, activities, moods, or tags that actually appeared in the entries. Avoid generic or vague statements. Highlight concrete moments, feelings, or patterns. Then, list the top 3 emotional themes as tags, and finally provide a short, uplifting quote or affirmation. Format:
\nTitle: <short poetic title for the month>\nSummary: <paragraph>\nTags: <comma-separated>\nQuote: <short quote or affirmation>\n\nJOURNAL ENTRIES:\n` + content;
  }
};
function parseAIReflection(aiText: string): { title: string; summary: string; tags: string[]; quote: string } {
  const titleMatch = aiText.match(/Title:\s*(.*)/i);
  const summaryMatch = aiText.match(/Summary:\s*([\s\S]*?)\nTags:/i);
  const tagsMatch = aiText.match(/Tags:\s*([\w\s,\-]+)/i);
  const quoteMatch = aiText.match(/Quote:\s*([\s\S]*)/i);
  let tags = tagsMatch ? tagsMatch[1].split(',').map((t: string) => t.trim()).filter(Boolean) : [];
  tags = tags.filter((t: string) => t.toLowerCase() !== 'quote');
  return {
    title: titleMatch ? titleMatch[1].trim() : '',
    summary: summaryMatch ? summaryMatch[1].trim() : '',
    tags,
    quote: quoteMatch ? quoteMatch[1].trim().replace(/^['"]+|['"]+$/g, '') : ''
  };
}
interface JournalEntry {
  id: string;
  created_at: string;
  content: string;
  mood?: string | null;
  tags?: string[] | null;
}
interface ReflectionGroup {
  type: 'week' | 'month';
  key: string;
  range: string;
  entries: JournalEntry[];
}
interface Reflection extends ReflectionGroup {
  title: string;
  summary: string;
  tags: string[];
  quote: string;
}
// Helper to get all weeks in a given month group
function getWeeksInMonth(monthGroup: ReflectionGroup, weekGroups: ReflectionGroup[]): ReflectionGroup[] {
  const month = monthGroup.key.split('-')[1];
  const year = monthGroup.key.split('-')[0];
  return weekGroups.filter(wg => {
    const [wYear, wWeek] = wg.key.split('-W');
    if (wYear !== year) return false;
    // Check if the week's entries fall within the month
    return wg.entries.some(e => (new Date(e.created_at).getMonth() + 1) === parseInt(month));
  });
}
// Helper to check if a week is completed (ends before today)
function isWeekCompleted(entries: JournalEntry[]): boolean {
  if (!entries.length) return false;
  const weekEnd = endOfWeek(new Date(entries[0].created_at), { weekStartsOn: 1 });
  return isBefore(weekEnd, endOfDay(new Date()));
}
// Helper to check if a month is completed (ends before today)
function isMonthCompletedFromKey(monthKey: string): boolean {
  // monthKey is like '2025-07'
  const [year, month] = monthKey.split('-').map(Number);
  const monthEnd = endOfMonth(new Date(year, month - 1, 1));
  return isBefore(monthEnd, endOfDay(new Date()));
}
// Helper to convert JS array to Postgres array string
function toPostgresArray(arr: string[]): string {
  return '{' + arr.map(t => t.replace(/}/g, '\}').replace(/{/g, '\{').replace(/,/g, '\,')).join(',') + '}';
}
// Robust tags parser for DB values
function parseTags(tags: any): string[] {
  if (Array.isArray(tags)) return tags;
  if (typeof tags === 'string') {
    // Try JSON parse
    try {
      const parsed = JSON.parse(tags);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      // Try Postgres array string: {progress,balance,simplicity}
      if (tags.startsWith('{') && tags.endsWith('}')) {
        return tags
          .slice(1, -1)
          .split(',')
          .map(t => t.replace(/^"|"$/g, '').trim())
          .filter(Boolean);
      }
    }
  }
  return [];
}

interface InnerMirrorTimelineProps {
  journalEntries: JournalEntry[];
  session: any;
  isSubscribed: boolean;
}

const InnerMirrorTimeline: React.FC<InnerMirrorTimelineProps> = ({ journalEntries, session, isSubscribed }) => {
  // Early return for unsubscribed users (no hooks before this!)
  if (!isSubscribed) {
    return (
      <div className="relative mb-8 transition-opacity duration-700 opacity-100" style={{ zIndex: 1 }}>
        <div className="backdrop-blur-lg bg-white/60 dark:bg-[#23124d]/60 border border-white/30 dark:border-[#a78bfa]/20 shadow-xl rounded-3xl px-8 py-8 md:py-10 md:px-12 max-w-3xl mx-auto flex flex-col gap-2">
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-2">Inner Mirror</h2>
          <div className="text-center py-8">
            <h3 className="text-2xl font-bold mb-4">Unlock Reflections with MindfulSphere Pro</h3>
            <p className="mb-6 text-gray-600 dark:text-gray-300">
              AI-powered weekly and monthly reflections are available to subscribers.
            </p>
            <a
              href="/pricing"
              className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold shadow hover:bg-indigo-700 transition"
            >
              View Plans & Pricing
            </a>
          </div>
        </div>
      </div>
    );
  }

  const [reflections, setReflections] = useState<Reflection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [fadeIn, setFadeIn] = useState(false);
  const [inProgressKeys, setInProgressKeys] = useState<Set<string>>(new Set());

  // Upsert only handles DB, not AI
  const upsertReflection = async (group: ReflectionGroup, type: 'week' | 'month', title: string, summary: string, tags: string[], quote: string) => {
    try {
      const tagsValue = toPostgresArray(Array.isArray(tags) ? tags : []);
      const { error } = await supabase.from('journal_reflections').upsert([
        {
          user_id: session.user.id,
          type,
          period_key: group.key,
          range: group.range,
          title,
          summary,
          tags: tagsValue,
          quote,
        }
      ], { onConflict: ['user_id', 'type', 'period_key'] });
      if (error) throw error;
      // Refetch reflections after upsert
      const { data } = await supabase
        .from('journal_reflections')
        .select('*')
        .eq('user_id', session.user.id)
        .order('type', { ascending: true })
        .order('period_key', { ascending: false });
      setReflections(Array.isArray(data) ? data.map(r => ({ ...r, key: r.period_key, tags: parseTags(r.tags) })) : []);
    } catch (e: any) {
      setError(e.message || 'Failed to generate/store reflection');
    }
  };

  // Only include completed weeks/months
  const weekGroups: ReflectionGroup[] = Object.entries(groupByWeek(journalEntries || []))
    .map(([key, entries]) => ({
      type: 'week' as 'week',
      key,
      range: getWeekRange(entries),
      entries: entries as JournalEntry[],
    }))
    .filter(g => isWeekCompleted(g.entries))
    .sort((a, b) => b.entries[0].created_at.localeCompare(a.entries[0].created_at));

  const monthGroups: ReflectionGroup[] = Object.entries(groupByMonth(journalEntries || []))
    .map(([key, entries]) => ({
      type: 'month' as 'month',
      key,
      range: getMonthRange(entries),
      entries: entries as JournalEntry[],
    }))
    .filter(g => isMonthCompletedFromKey(g.key))
    .sort((a, b) => b.entries[0].created_at.localeCompare(a.entries[0].created_at));

  // Timeline data for current view mode
  const timelineGroups = viewMode === 'week' ? weekGroups : monthGroups;

  // Fetch reflections from DB on mount or when user/session changes
  useEffect(() => {
    const fetchReflections = async () => {
      setLoading(true);
      setError(null);
      try {
        if (!session?.user?.id) return;
        const { data, error } = await supabase
          .from('journal_reflections')
          .select('*')
          .eq('user_id', session.user.id)
          .order('type', { ascending: true })
          .order('period_key', { ascending: false });
        if (error) throw error;
        // When fetching reflections, parse tags if needed
        setReflections(Array.isArray(data) ? data.map(r => ({ ...r, key: r.period_key, tags: parseTags(r.tags) })) : []);
      } catch (e: any) {
        setError(e.message || 'Failed to load reflections');
      } finally {
        setLoading(false);
      }
    };
    fetchReflections();
  }, [session?.user?.id]);

  // On week/month completion, generate and store new reflection if missing
  useEffect(() => {
    if (loading || !session?.access_token || !session?.user?.id) return;
    let cancelled = false;
    const processNext = async () => {
      // Find the first missing reflection not in progress
      const groupsToGenerate = [...weekGroups, ...(weekGroups.every(w => reflections.find(r => r.key === w.key)) ? monthGroups : [])];
      const nextGroup = groupsToGenerate.find(group => {
        const exists = reflections.find(r => r.key === group.key);
        return !exists && !inProgressKeys.has(group.key);
      });
      if (!nextGroup) return;
      setInProgressKeys(prev => new Set(prev).add(nextGroup.key));
      console.log('Generating reflection for period:', nextGroup.key);
      const entriesWithContent = nextGroup.entries.filter(e => e.content && e.content.trim().length > 0);
      if (entriesWithContent.length > 0) {
        const content = entriesWithContent.map(e => e.content).join('\n---\n');
        const prompt = aiReflectionPrompt(nextGroup.type, content);
        const aiText = await generateJournalAnalysisWithAIProxy(content, session.access_token, 'custom', prompt);
        const parsed = parseAIReflection(aiText);
        await upsertReflection(
          nextGroup,
          nextGroup.type,
          parsed.title,
          parsed.summary,
          Array.isArray(parsed.tags) ? parsed.tags : [],
          parsed.quote
        );
      } else {
        await upsertReflection(
          nextGroup,
          nextGroup.type,
          nextGroup.type === 'week' ? 'Moments Unwritten' : 'A Quiet Month',
          `This ${nextGroup.type === 'week' ? "week's" : "month's"} journal does not contain any specific entries, leaving a blank canvas open to future experiences and reflections. Sometimes, the absence of words speaks to a pause—a space for rest, quiet, or simply a period where observation took precedence over documentation. This can be a gentle reminder that every journey includes moments of stillness, and those, too, are part of growth.`,
          [],
          ''
        );
      }
      setInProgressKeys(prev => {
        const newSet = new Set(prev);
        newSet.delete(nextGroup.key);
        return newSet;
      });
      if (!cancelled) processNext(); // Process next in queue
    };
    processNext();
    return () => { cancelled = true; };
  }, [journalEntries, session, reflections, weekGroups, monthGroups, loading]);

  // Always show the most recent completed week/month by default
  useEffect(() => {
    setCurrentIdx(0);
  }, [viewMode, weekGroups.length, monthGroups.length]);

  useEffect(() => {
    setFadeIn(true);
  }, []);

  const sortedReflections = timelineGroups
    .map(g => reflections.find(r => r.key === g.key))
    .filter(Boolean) as Reflection[];
  const current = sortedReflections[currentIdx] || null;
  console.log('Displaying reflection for period:', current?.key);

  return (
    <div className={`relative mb-8 transition-opacity duration-700 ${fadeIn ? 'opacity-100' : 'opacity-0'}`}
      style={{ zIndex: 1 }}>
      <div className="backdrop-blur-lg bg-white/60 dark:bg-[#23124d]/60 border border-white/30 dark:border-[#a78bfa]/20 shadow-xl rounded-3xl px-8 py-8 md:py-10 md:px-12 max-w-3xl mx-auto flex flex-col gap-2">
        <div className="flex items-center gap-3 mb-2">
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">Inner Mirror</h2>
        </div>
        {/* Toggle for week/month */}
        <div className="flex gap-2 mb-4">
          <button
            className={`px-4 py-1 rounded-full font-semibold transition-all ${viewMode === 'week' ? 'bg-indigo-500 text-white shadow' : 'bg-indigo-100/70 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-200'}`}
            onClick={() => setViewMode('week')}
          >
            Weekly
          </button>
          <button
            className={`px-4 py-1 rounded-full font-semibold transition-all ${viewMode === 'month' ? 'bg-indigo-500 text-white shadow' : 'bg-indigo-100/70 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-200'}`}
            onClick={() => setViewMode('month')}
          >
            Monthly
          </button>
        </div>
        {loading ? (
          <div className="flex items-center gap-2 text-indigo-500"><Sparkles className="animate-spin" /> Loading your reflection...</div>
        ) : error ? (
          <div className="text-red-500 text-center py-4">{error}</div>
        ) : current ? (
          <>
            <div className="text-xl md:text-2xl font-bold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-1">{current.title || (current.type === 'week' ? `Week Reflection` : `Monthly Mirror`)}</div>
            <div className="text-sm text-gray-500 mb-3">{current.range}</div>
            <div className="mb-4 text-base md:text-lg leading-relaxed text-gray-700 dark:text-gray-200" style={{ maxWidth: 700 }}>{current.summary}</div>
            <div className="flex flex-wrap gap-2 mb-4">
              {current.tags.map(tag => (
                <span key={tag} className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-indigo-100/70 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-200 text-xs font-medium shadow-sm hover:bg-indigo-200/80 transition"> <Tag size={13} /> {tag} </span>
              ))}
            </div>
            {current.quote && (
              <blockquote className="relative text-lg md:text-xl italic text-indigo-600 dark:text-indigo-300 border-l-4 border-indigo-400/60 pl-5 mb-4 py-2">
                <Quote size={20} className="inline-block mr-2 align-text-top opacity-80" />
                <span className="align-middle">{current.quote}</span>
              </blockquote>
            )}
            {/* Timeline navigation */}
            <div className="flex items-center justify-center gap-4 mt-4">
              <button
                className="rounded-full p-2 bg-indigo-100/80 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-200 shadow hover:bg-indigo-200/90 dark:hover:bg-indigo-800/60 transition disabled:opacity-40"
                onClick={() => setCurrentIdx(i => Math.max(0, i - 1))}
                disabled={currentIdx === 0}
                aria-label="Previous reflection"
              >
                <ChevronLeft size={28} />
              </button>
              <div className="flex-1 px-2 min-w-[120px] max-w-[220px] text-center text-sm text-gray-500 dark:text-gray-400">
                {viewMode === 'week' ? `Week ${sortedReflections.length - currentIdx}` : `Month ${sortedReflections.length - currentIdx}`}
              </div>
              <button
                className="rounded-full p-2 bg-indigo-100/80 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-200 shadow hover:bg-indigo-200/90 dark:hover:bg-indigo-800/60 transition disabled:opacity-40"
                onClick={() => setCurrentIdx(i => Math.min(sortedReflections.length - 1, i + 1))}
                disabled={currentIdx === sortedReflections.length - 1}
                aria-label="Next reflection"
              >
                <ChevronRight size={28} />
              </button>
            </div>
            <div className="flex justify-center gap-2 mt-2">
              {sortedReflections.map((r, i) => (
                <button
                  key={r.key}
                  className={`w-3 h-3 rounded-full border-2 border-indigo-300 dark:border-indigo-700 transition-all duration-200 ${i === currentIdx ? 'bg-indigo-500 scale-110' : 'bg-indigo-200 dark:bg-indigo-800'}`}
                  onClick={() => setCurrentIdx(i)}
                  aria-label={`Go to reflection ${i + 1}`}
                />
              ))}
            </div>
          </>
        ) : (
          <div className="text-indigo-400 text-center py-4">
            {viewMode === 'month'
              ? 'No completed months to reflect on yet. Reflections will appear here after a month is over!'
              : 'No completed weeks to reflect on yet. Reflections will appear here after a week is over!'}
          </div>
        )}
      </div>
    </div>
  );
};

export default InnerMirrorTimeline; 