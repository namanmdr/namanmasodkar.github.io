import React, { useEffect, useRef, useState } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import * as d3 from 'd3-force';
import { Card, CardContent, CardHeader, CardTitle } from './Card';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

const NODE_RADIUS = 18; // slightly larger for aesthetics
const LABEL_MARGIN = 12;
const MARGIN = 40;

type PracticeNode = {
    id: string;
    type: 'journal' | 'yoga';
    title: string;
    created_at: string;
  x?: number;
  y?: number;
};
type PracticeLink = {
    source: string;
    target: string;
    type: 'pre_practice' | 'post_practice' | 'shared_journal' | 'journal_link';
};

function layoutNodes(nodes: PracticeNode[], width: number, height: number): PracticeNode[] {
  const MARGIN = 40;
  const n = nodes.length;
  if (n === 1) {
    return [{ ...nodes[0], x: width / 2, y: height / 2 }];
  } else if (n <= 8) {
    // Circle layout
    const angleStep = (2 * Math.PI) / n;
    const r = Math.min((width - 2 * MARGIN), (height - 2 * MARGIN)) / 2;
    return nodes.map((node, i) => ({
      ...node,
      x: width / 2 + Math.cos(i * angleStep) * r,
      y: height / 2 + Math.sin(i * angleStep) * r,
    }));
  } else {
    // Grid layout
    const cols = Math.ceil(Math.sqrt(n));
    const rows = Math.ceil(n / cols);
    const cellW = (width - 2 * MARGIN) / cols;
    const cellH = (height - 2 * MARGIN) / rows;
    return nodes.map((node, i) => {
      const row = Math.floor(i / cols);
      const col = i % cols;
      return {
        ...node,
        x: MARGIN + col * cellW + cellW / 2,
        y: MARGIN + row * cellH + cellH / 2,
      };
    });
  }
}

const PracticeGraph: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { theme } = useTheme();
  const containerRef = useRef<HTMLDivElement>(null);
  const fgRef = useRef<any>(null);
  const [dimensions, setDimensions] = useState({ width: 900, height: 500 });
  const [rawNodes, setRawNodes] = useState<PracticeNode[]>([]);
  const [graphData, setGraphData] = useState<{ nodes: PracticeNode[]; links: PracticeLink[] }>({ nodes: [], links: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [shouldZoomToFit, setShouldZoomToFit] = useState(false);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };
    handleResize();
    const resizeObserver = new (window as any).ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);
    window.addEventListener('resize', handleResize);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (user) {
      fetchGraphData();
      // Listen for custom event to refresh graph
      const handler = () => fetchGraphData();
      window.addEventListener('practice-cycle-updated', handler);
      return () => window.removeEventListener('practice-cycle-updated', handler);
    }
  }, [user]);

  // Replace fetchGraphData to build the graph in the frontend
  const fetchGraphData = async () => {
    try {
      setLoading(true);
      setError(null);
      if (!user) return;

      // Fetch all relevant data, including linked_entry_ids
      const [cyclesRes, journalsRes, yogasRes] = await Promise.all([
        supabase.from('practice_cycles').select('*').eq('user_id', user.id),
        supabase.from('journal_entries').select('id, title, created_at, linked_entry_ids').eq('user_id', user.id),
        supabase.from('yoga_sessions').select('id, title, created_at').eq('user_id', user.id),
      ]);

      if (cyclesRes.error || journalsRes.error || yogasRes.error) throw cyclesRes.error || journalsRes.error || yogasRes.error;

      const journals = journalsRes.data || [];
      const yogas = yogasRes.data || [];
      const cycles = cyclesRes.data || [];

      // Build nodes
      const nodes: PracticeNode[] = [
        ...journals.map(j => ({ id: j.id, type: 'journal' as const, title: j.title, created_at: j.created_at })),
        ...yogas.map(y => ({ id: y.id, type: 'yoga' as const, title: y.title, created_at: y.created_at })),
      ];
      const nodeIds = new Set(nodes.map(n => n.id));

      // Build edges
      let links: PracticeLink[] = [];
      // Pre-practice edges
      for (const c of cycles) {
        if (c.pre_journal_id && c.yoga_session_id && nodeIds.has(c.pre_journal_id) && nodeIds.has(c.yoga_session_id)) {
          links.push({ source: c.pre_journal_id, target: c.yoga_session_id, type: 'pre_practice' });
        }
        if (c.yoga_session_id && c.post_journal_id && nodeIds.has(c.yoga_session_id) && nodeIds.has(c.post_journal_id)) {
          links.push({ source: c.yoga_session_id, target: c.post_journal_id, type: 'post_practice' });
        }
      }
      // Shared journal edges
      for (const c1 of cycles) {
        if (c1.post_journal_id) {
          for (const c2 of cycles) {
            if (c2.pre_journal_id && c1.post_journal_id === c2.pre_journal_id && nodeIds.has(c1.post_journal_id) && nodeIds.has(c2.pre_journal_id)) {
              links.push({ source: c1.post_journal_id, target: c2.pre_journal_id, type: 'shared_journal' as const });
            }
          }
        }
      }
      // Journal-to-journal links (Obsidian-style)
      for (const j of journals) {
        if (Array.isArray(j.linked_entry_ids)) {
          for (const targetId of j.linked_entry_ids) {
            if (nodeIds.has(targetId)) {
              links.push({ source: j.id, target: targetId, type: 'journal_link' });
            }
          }
        }
      }

      setGraphData({ nodes, links });
      console.log('PracticeGraph data:', { nodes, links });
      setShouldZoomToFit(true);
      setInitialized(true);
    } catch (err: any) {
      setError('Could not load practice graph.');
      setGraphData({ nodes: [], links: [] });
      setInitialized(true);
    } finally {
      setLoading(false);
    }
  };

  const graphWidth = Math.max(200, dimensions.width);
  const graphHeight = Math.max(200, dimensions.height);

  // Only call zoomToFit once after first simulation
  useEffect(() => {
    if (shouldZoomToFit && fgRef.current) {
      setTimeout(() => {
        fgRef.current.zoomToFit(400, 40);
        setShouldZoomToFit(false);
      }, 400);
    }
  }, [shouldZoomToFit, graphData]);

  // Set force parameters for good spread
  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('center', d3.forceCenter(graphWidth / 2, graphHeight / 2));
      fgRef.current.d3Force('charge', d3.forceManyBody().strength(-100));
      fgRef.current.d3Force('collide', d3.forceCollide(NODE_RADIUS * 1.05));
      fgRef.current.d3Force('link', d3.forceLink().distance(140));
    }
  }, [graphData, graphWidth, graphHeight]);

  // Remove all clamping, mutation, and layout logic after render
  // Remove all clamping, mutation, and layout logic after render

  const getNodeColor = (node: any) => {
    switch (node.type) {
      case 'journal':
        return '#10B981'; // emerald-500
      case 'yoga':
        return '#6366F1'; // indigo-500
      default:
        return '#6B7280'; // gray-500
    }
  };

  // Add a gradient for yoga and journal nodes
  const getNodeGradient = (node: any, ctx: CanvasRenderingContext2D, x: number, y: number) => {
    if (!isFinite(x) || !isFinite(y)) {
      // fallback: simple color
      return node.type === 'journal' ? '#10B981' : node.type === 'yoga' ? '#6366F1' : '#6B7280';
    }
    const r = NODE_RADIUS;
    let grad = ctx.createRadialGradient(x, y, r * 0.2, x, y, r);
    if (node.type === 'journal') {
      grad.addColorStop(0, '#6ee7b7'); // emerald-300
      grad.addColorStop(1, '#10b981'); // emerald-500
    } else if (node.type === 'yoga') {
      grad.addColorStop(0, '#a5b4fc'); // indigo-300
      grad.addColorStop(1, '#6366f1'); // indigo-500
    } else {
      grad.addColorStop(0, '#d1d5db'); // gray-300
      grad.addColorStop(1, '#6b7280'); // gray-500
    }
    return grad;
  };

  const handleNodeClick = (node: any) => {
    if (node.type === 'journal') {
      navigate(`/journal/${node.id}`);
    } else if (node.type === 'yoga') {
      navigate(`/yoga/${node.id}`);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading practice graph...</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <p className="text-red-500">{error}</p>
        </CardContent>
      </Card>
    );
  }

  if (!graphData.nodes.length) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <p className="text-gray-600 dark:text-gray-300">
            No practice data available yet. Start your journey by creating a journal entry or yoga sequence!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Practice Journey</CardTitle>
      </CardHeader>
      <CardContent>
        <div
          ref={containerRef}
          className={
            `h-[600px] rounded-3xl shadow-2xl p-4 flex items-center justify-center overflow-hidden ` +
            'backdrop-blur-xl border border-white/30 ' +
            (theme === 'dark'
              ? 'bg-gradient-to-br from-gray-900/80 via-indigo-950/80 to-purple-950/80'
              : 'bg-gradient-to-br from-white/80 via-indigo-100/80 to-purple-100/80')
          }
          style={{ boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.18)' }}
        >
          <ForceGraph2D
            ref={fgRef}
            graphData={graphData}
            width={graphWidth}
            height={graphHeight}
            nodeRelSize={NODE_RADIUS}
            linkColor={(link: any) => {
              if (link.type === 'journal_link') return theme === 'dark' ? '#f472b6' : '#db2777'; // pink-400/600
              if (link.type === 'pre_practice' || link.type === 'post_practice') return theme === 'dark' ? '#818cf8' : '#a5b4fc';
              if (link.type === 'shared_journal') return theme === 'dark' ? '#fbbf24' : '#f59e42';
              return '#a5b4fc';
            }}
            linkWidth={(link: any) => link.type === 'journal_link' ? 3.5 : 2.5}
            linkDirectionalParticles={2}
            linkDirectionalParticleSpeed={0.005}
            onNodeClick={handleNodeClick}
            cooldownTicks={100}
            nodeCanvasObject={(node: any, ctx, globalScale) => {
              // Defensive: only draw if x and y are finite
              if (!isFinite(node.x) || !isFinite(node.y)) return;
              // Draw node with gradient and border
              ctx.save();
              ctx.beginPath();
              ctx.arc(node.x, node.y, NODE_RADIUS, 0, 2 * Math.PI, false);
              ctx.fillStyle = getNodeGradient(node, ctx, node.x, node.y);
              ctx.shadowColor = 'rgba(99,102,241,0.18)';
              ctx.shadowBlur = 16;
              ctx.fill();
              ctx.lineWidth = 3.5;
              ctx.strokeStyle = theme === 'dark' ? '#18181b' : '#fff';
              ctx.stroke();
              ctx.restore();

              // Draw label with high-contrast and shadow
              ctx.save();
              ctx.font = `${16 / globalScale}px 'Inter', 'Sora', 'Poppins', Sans-Serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'top';
              ctx.fillStyle = theme === 'dark' ? '#fff' : '#222';
              ctx.shadowColor = theme === 'dark' ? '#000' : '#fff';
              ctx.shadowBlur = 6;
              ctx.fillText(node.title, node.x, node.y + NODE_RADIUS + 6);
              ctx.restore();
            }}
            nodePointerAreaPaint={(node: any, color, ctx) => {
              ctx.beginPath();
              ctx.arc(node.x, node.y, NODE_RADIUS + 6, 0, 2 * Math.PI, false);
              ctx.fillStyle = color;
              ctx.fill();
            }}
          />
        </div>
        <div className={
          'mt-6 flex items-center justify-center space-x-8 text-base font-sora ' +
          (theme === 'dark'
            ? 'text-gray-100 bg-gray-900/70 rounded-xl py-2 backdrop-blur-md border border-white/10'
            : 'text-gray-800 bg-white/80 rounded-xl py-2 shadow backdrop-blur-md border border-gray-200/60')
        } style={{ fontFamily: 'Inter, Sora, Poppins, sans-serif', fontWeight: 500 }}>
          <div className="flex items-center">
            <div className="w-5 h-5 rounded-full mr-2 shadow border-2 border-white" style={{ background: 'radial-gradient(circle at 60% 40%, #a5b4fc 0%, #6366f1 100%)' }}></div>
            <span>Yoga Sessions</span>
          </div>
          <div className="flex items-center">
            <div className="w-5 h-5 rounded-full mr-2 shadow border-2 border-white" style={{ background: 'radial-gradient(circle at 60% 40%, #6ee7b7 0%, #10b981 100%)' }}></div>
            <span>Journal Entries</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PracticeGraph;