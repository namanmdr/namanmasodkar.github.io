import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

// Create a single supabase client for interacting with your database
export const supabase = createClient<Database>(supabaseUrl, supabaseKey);

export async function isUserSubscribed(userId: string): Promise<boolean> {
  // Query the user's subscription status from the user_settings table
  const { data, error } = await supabase
    .from('user_settings')
    .select('subscription_status')
    .eq('user_id', userId)
    .single();
  if (error) {
    console.error('Error checking subscription status:', error);
    return false;
  }
  return data?.subscription_status === 'active';
}

export async function getFreeYogaUsed(userId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('user_settings')
    .select('free_yoga_used')
    .eq('user_id', userId)
    .single();
  if (error) {
    console.error('Error checking free_yoga_used:', error);
    return false;
  }
  return !!data?.free_yoga_used;
}

export async function setFreeYogaUsed(userId: string): Promise<void> {
  const { error } = await supabase
    .from('user_settings')
    .update({ free_yoga_used: true })
    .eq('user_id', userId);
  if (error) {
    console.error('Error setting free_yoga_used:', error);
  }
}