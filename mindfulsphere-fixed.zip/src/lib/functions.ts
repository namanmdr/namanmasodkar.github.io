// Central place to build Supabase Edge Function URLs.
// Derives the base from VITE_SUPABASE_URL so the project ref is never hardcoded.
// Uses the stable /functions/v1/<name> path (works on every Supabase project).
const base = import.meta.env.VITE_SUPABASE_URL;

if (!base) {
  // Surface misconfiguration early instead of silently hitting a broken URL.
  console.error('VITE_SUPABASE_URL is not set — Edge Function calls will fail.');
}

export function fnUrl(name: string): string {
  return `${base}/functions/v1/${name}`;
}
