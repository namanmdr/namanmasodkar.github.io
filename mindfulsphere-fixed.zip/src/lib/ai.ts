import { fnUrl } from './functions';
export async function generateJournalTitleWithAIProxy(content: string, accessToken: string): Promise<string> {
  const prompt = `Generate a short, descriptive title (max 8 words) for this journal entry:\n${content.slice(0, 300)}`;
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 16,
      temperature: 0.5,
    }),
  });
  const data = await response.json();
  let title = data.choices?.[0]?.message?.content?.trim() || '';
  // Remove leading/trailing quotes (single or double)
  title = title.replace(/^['"]+|['"]+$/g, '');
  return title;
}

export async function generateYogaSequenceTitleWithAIProxy(sequence: any, accessToken: string): Promise<string> {
  // Compose a prompt using the intent, level, and a summary of the sequence
  const intent = sequence.intent || '';
  const level = sequence.level || '';
  const poses = sequence.sections?.flatMap((s: any) => s.poses?.map((p: any) => p.name)).filter(Boolean).slice(0, 5).join(', ');
  const prompt = `Generate a short, descriptive title (max 8 words) for a yoga sequence.\nIntent: ${intent}\nLevel: ${level}\nKey poses: ${poses}`;
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 16,
      temperature: 0.5,
    }),
  });
  const data = await response.json();
  let title = data.choices?.[0]?.message?.content?.trim() || '';
  // Remove leading/trailing quotes (single or double)
  title = title.replace(/^['"]+|['"]+$/g, '');
  return title;
}

export async function generateJournalMoodWithAIProxy(content: string, accessToken: string): Promise<string> {
  const prompt = `Given the following journal entry, identify the user's primary mood in one word (e.g., Happy, Calm, Anxious, Grateful, etc.). Only return the mood word, nothing else.\n\n${content.slice(0, 500)}`;
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 4,
      temperature: 0.3,
    }),
  });
  const data = await response.json();
  let mood = data.choices?.[0]?.message?.content?.trim() || '';
  mood = mood.replace(/^['"]+|['"]+$/g, '');
  return mood;
}

export async function generateJournalTagsWithAIProxy(content: string, accessToken: string): Promise<string[]> {
  const prompt = `Given the following journal entry, extract up to 5 relevant tags (single words or short phrases, comma-separated, no hashtags). Only return the tags, comma-separated.\n\n${content.slice(0, 500)}`;
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 32,
      temperature: 0.4,
    }),
  });
  const data = await response.json();
  let tagsRaw = data.choices?.[0]?.message?.content?.trim() || '';
  tagsRaw = tagsRaw.replace(/^['"]+|['"]+$/g, '');
  return tagsRaw.split(',').map((t: string) => t.trim()).filter(Boolean);
}

export async function generateJournalAnalysisWithAIProxy(content: string, accessToken: string, type: string, customPrompt?: string): Promise<string> {
  let prompt = '';
  switch (type) {
    case 'dream':
      prompt = `Analyze this journal entry as a dream. Interpret symbols, themes, and possible subconscious meanings. Only return the analysis.\n\n${content}`;
      break;
    case 'emotional':
      prompt = `Analyze the emotions present in this journal entry. What are the main feelings and possible causes? Only return the analysis.\n\n${content}`;
      break;
    case 'cognitive':
      prompt = `Identify any cognitive distortions or recurring thought patterns in this journal entry. Only return the analysis.\n\n${content}`;
      break;
    case 'spiritual':
      prompt = `Analyze the spiritual or mythological themes present in this journal entry. Only return the analysis.\n\n${content}`;
      break;
    case 'advice':
      prompt = `Based on this journal entry, suggest practical steps or advice for the user. Only return the advice.\n\n${content}`;
      break;
    case 'relationship':
      prompt = `Analyze the relationship dynamics described in this journal entry. Only return the analysis.\n\n${content}`;
      break;
    case 'custom':
      prompt = `${customPrompt || 'Analyze this journal entry.'}\n\n${content}`;
      break;
    default:
      prompt = `Analyze this journal entry. Only return the analysis.\n\n${content}`;
  }
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 512, // increased from 256
      temperature: 0.7,
    }),
  });
  const data = await response.json();
  let analysis = data.choices?.[0]?.message?.content?.trim() || '';
  analysis = analysis.replace(/^['"]+|['"]+$/g, '');
  return analysis;
}

export async function generateReflectionPromptWithAIProxy(content: string, accessToken: string, isFollowUp: boolean = false): Promise<string> {
  const prompt = isFollowUp
    ? `Given the following journal reflection answer, suggest a deeper follow-up question to help the user explore further. Only return the question.\n\n${content.slice(0, 500)}`
    : `Based on this journal entry, suggest a thoughtful reflection question to help the user gain deeper insight. Only return the question.\n\n${content.slice(0, 500)}`;
  const response = await fetch(fnUrl('ai_proxy'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      model: 'gpt-4.1',
      max_tokens: 48,
      temperature: 0.7,
    }),
  });
  const data = await response.json();
  let question = data.choices?.[0]?.message?.content?.trim() || '';
  question = question.replace(/^['"]+|['"]+$/g, '');
  return question;
} 