// NOTE: Usage metering to Stripe is handled SERVER-SIDE inside the `ai-proxy`
// Edge Function, which reports the real OpenAI token count using the service-role
// key after each successful call. Reporting usage from the browser is unsafe
// (a client can't hold the service key, and could forge arbitrary token counts),
// so this client-side helper is intentionally a no-op kept only for backward
// compatibility with existing call sites. Prefer removing the call sites entirely.
export async function reportStripeUsage(_userId: string, _tokensUsed: number): Promise<boolean> {
  // Deliberately does nothing. See note above.
  return true;
}
