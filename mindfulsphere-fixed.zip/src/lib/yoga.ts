import { fnUrl } from './functions';
import { supabase } from './supabase';
import { jsonrepair } from 'jsonrepair';

// Enhanced type definitions for better structure and validation
export interface YogaPose {
  name: string;
  sanskritName: string;
  duration: string;
  durationInSeconds: number;
  benefits: string;
  instructions: string[];
  intentRelation?: string;
  audioUrl?: string; // For OpenAI TTS audio URLs
  audioEntryUrl?: string; // For entry/instructions TTS audio
  audioTransitionUrl?: string; // For transition TTS audio
  image?: string; // Path to pose-specific image asset
}

export interface YogaSection {
  title: string;
  poses: YogaPose[];
  rawMarkdown?: string;
}

export interface YogaSequence {
  title: string;
  duration: number;
  level: string;
  intent?: string;
  sections: YogaSection[];
  rawMarkdown?: string;
}

// Structured LLM response interface for better validation
interface StructuredYogaResponse {
  sections: {
    title: string;
    poses: {
      name: string;
      sanskritName: string;
      durationMinutes: number;
      benefits: string;
      instructions: string[];
      intentRelation: string;
    }[];
  }[];
}

// Validation functions for robust data handling
function validatePose(pose: any): pose is YogaPose {
  return (
    typeof pose.name === 'string' &&
    typeof pose.sanskritName === 'string' &&
    typeof pose.duration === 'string' &&
    typeof pose.durationInSeconds === 'number' &&
    typeof pose.benefits === 'string' &&
    Array.isArray(pose.instructions) &&
    pose.instructions.every((instruction: any) => typeof instruction === 'string')
  );
}

function validateSection(section: any): section is YogaSection {
  return (
    typeof section.title === 'string' &&
    Array.isArray(section.poses) &&
    section.poses.every(validatePose)
  );
}

function validateSequence(sequence: any): sequence is YogaSequence {
  return (
    typeof sequence.title === 'string' &&
    typeof sequence.duration === 'number' &&
    typeof sequence.level === 'string' &&
    Array.isArray(sequence.sections) &&
    sequence.sections.every(validateSection)
  );
}

// Enhanced parsing with better error handling and fallbacks
export function parseYogaSequence(content: string): YogaSection[] {
  const sections: YogaSection[] = [];
  let currentSection: YogaSection | null = null;
  let currentSectionMarkdown = '';
  let currentPose: YogaPose | null = null;

  // Normalize content: handle markdown line breaks and escaped newlines
  const normalizedContent = content
    .replace(/  +\n/g, '\n') // Convert markdown line breaks to real newlines
    .replace(/\\n/g, '\n')  // Convert escaped newlines to real newlines
    .replace(/\r/g, '');      // Remove carriage returns

  const lines = normalizedContent
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0); // Remove empty lines

  for (const line of lines) {
    currentSectionMarkdown += line + '\n';

    // Section header: more flexible matching
    const sectionMatch = line.match(/^section:?\s*(.+)$/i) || 
                        line.match(/^(warmup|main sequence|cooldown|warm-up|main|cooldown)$/i) ||
                        line.match(/^#\s*(.+)$/i);
    
    if (sectionMatch) {
      if (currentSection) {
        if (currentPose) {
          currentSection.poses.push(currentPose);
          currentPose = null;
        }
        currentSection.rawMarkdown = currentSectionMarkdown.trim();
        sections.push(currentSection);
        currentSectionMarkdown = line + '\n';
      }
      const sectionTitle = sectionMatch[1] ? sectionMatch[1].trim() : sectionMatch[0].trim();
      currentSection = {
        title: sectionTitle.charAt(0).toUpperCase() + sectionTitle.slice(1),
        poses: [],
        rawMarkdown: ''
      };
      continue;
    }

    // Enhanced pose line matching with better flexibility
    const poseMatch = line.match(/^(\d+\.)?\s*([A-Za-z\s\-]+)\s*\(([^)]+)\)\s*[-–—]\s*(\d+)\s*(minute|min|m)?s?/i) ||
                     line.match(/^(\d+\.)?\s*([A-Za-z\s\-]+)\s*[-–—]\s*(\d+)\s*(minute|min|m)?s?/i);
    
    if (poseMatch && currentSection) {
      if (currentPose) {
        currentSection.poses.push(currentPose);
      }
      const name = poseMatch[2]?.trim() || poseMatch[3]?.trim() || '';
      const sanskritName = poseMatch[3]?.trim() || name; // Fallback to English name if no Sanskrit
      const durationMinutes = parseInt(poseMatch[4] || poseMatch[3] || '1');
      
      currentPose = {
        name,
        sanskritName,
        duration: `${durationMinutes} minutes`,
        durationInSeconds: durationMinutes * 60,
        benefits: '',
        instructions: [],
        intentRelation: ''
      };
      continue;
    }

    // Benefits line with more flexible matching
    const benefitsMatch = line.match(/benefits?:?\s*(.+)/i) ||
                         line.match(/^benefits?:?\s*(.+)/i);
    if (benefitsMatch && currentPose) {
      currentPose.benefits = benefitsMatch[1].replace(/^\*|\*$/g, '').trim();
      continue;
    }

    // Intent relation line with more flexible matching
    const intentMatch = line.match(/intent relation:?\s*(.+)/i) ||
                       line.match(/connection:?\s*(.+)/i) ||
                       line.match(/purpose:?\s*(.+)/i);
    if (intentMatch && currentPose) {
      currentPose.intentRelation = intentMatch[1].replace(/^\*|\*$/g, '').trim();
      continue;
    }

    // Enhanced instruction line matching
    const instructionMatch = line.match(/^[-*•●]\s*(.+)/) ||
                           line.match(/^(\d+\.)\s*(.+)/) ||
                           line.match(/^[•●]\s*(.+)/);
    if (instructionMatch && currentPose) {
      const instruction = instructionMatch[1] || instructionMatch[2];
      const cleanInstruction = instruction.replace(/^\*|\*$/g, '').trim();
      if (cleanInstruction && !currentPose.instructions.includes(cleanInstruction)) {
        currentPose.instructions.push(cleanInstruction);
      }
    }
  }

  // Final cleanup
  if (currentPose && currentSection) {
    currentSection.poses.push(currentPose);
  }

  if (currentSection) {
    currentSection.rawMarkdown = currentSectionMarkdown.trim();
    sections.push(currentSection);
  }

  // If parsing failed, log the content for debugging
  if (sections.length === 0) {
    console.error('parseYogaSequence: Failed to parse any sections. Raw content:', content);
  }

  return sections;
}

// Enhanced duration adjustment with better error handling
function adjustDurationsToMatch(sections: YogaSection[], targetMinutes: number, rawMarkdown: string): { sections: YogaSection[], updatedMarkdown: string } {
  // Flatten all poses
  const allPoses = sections.flatMap(section => section.poses);
  
  if (allPoses.length === 0) {
    return { sections, updatedMarkdown: rawMarkdown };
  }
  
  // Calculate current total duration in minutes
  let currentTotal = allPoses.reduce((sum, pose) => sum + (pose.durationInSeconds / 60), 0);
  
  // If we're within 0.5 minutes of target, no need to adjust
  if (Math.abs(currentTotal - targetMinutes) < 0.5) {
    return { sections, updatedMarkdown: rawMarkdown };
  }

  let updatedMarkdown = rawMarkdown;

  // Helper function to create patterns for a pose and duration
  const createPatterns = (pose: YogaPose, durationText: string) => [
    // Format: "Pose Name (Sanskrit) - X minutes Benefits: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText}\\s*Benefits:`, 'g'),
    // Format: "Pose Name (Sanskrit) - X min Benefits: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace('minutes', 'min')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name (Sanskrit) - Xm Benefits: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace(' minutes', 'm')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name (Sanskrit) - X Benefits: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace(' minutes', '')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name - X minutes Benefits: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText}\\s*Benefits:`, 'g'),
    // Format: "Pose Name - X min Benefits: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace('minutes', 'min')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name - Xm Benefits: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace(' minutes', 'm')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name - X Benefits: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace(' minutes', '')}\\s*Benefits:`, 'g'),
    // Format: "Pose Name (Sanskrit) - X minutes Intent Relation: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name (Sanskrit) - X min Intent Relation: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace('minutes', 'min')}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name (Sanskrit) - Xm Intent Relation: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace(' minutes', 'm')}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name (Sanskrit) - X Intent Relation: ..."
    new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${durationText.replace(' minutes', '')}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name - X minutes Intent Relation: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name - X min Intent Relation: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace('minutes', 'min')}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name - Xm Intent Relation: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace(' minutes', 'm')}\\s*Intent Relation:`, 'g'),
    // Format: "Pose Name - X Intent Relation: ..."
    new RegExp(`${pose.name}\\s*[-–—]\\s*${durationText.replace(' minutes', '')}\\s*Intent Relation:`, 'g')
  ];

  // Helper function to update markdown with new duration
  const updateMarkdown = (pose: YogaPose, oldDurationText: string, newDurationText: string) => {
    const patterns = createPatterns(pose, oldDurationText);
    for (const pattern of patterns) {
      if (pattern.test(updatedMarkdown)) {
        // Find the line containing the pose
        const lines = updatedMarkdown.split('\n');
        const lineIndex = lines.findIndex(line => pattern.test(line));
        if (lineIndex !== -1) {
          // Replace the duration in the line while preserving the rest
          const line = lines[lineIndex];
          const newLine = line.replace(
            new RegExp(`${pose.name}\\s*\\(${pose.sanskritName}\\)\\s*[-–—]\\s*${oldDurationText}`, 'g'),
            `${pose.name} (${pose.sanskritName}) - ${newDurationText}`
          );
          lines[lineIndex] = newLine;
          updatedMarkdown = lines.join('\n');
        }
        break; // Stop after first successful match
      }
    }
  };

  // Step 1: Proportional scaling
  const scale = targetMinutes / currentTotal;
  
  // First pass: Scale all durations proportionally and round to nearest minute
  allPoses.forEach(pose => {
    const oldDuration = pose.durationInSeconds;
    const scaledDuration = Math.round((oldDuration / 60) * scale) * 60; // Round to nearest minute
    pose.durationInSeconds = Math.max(60, scaledDuration); // Ensure minimum 1 minute
    pose.duration = `${pose.durationInSeconds / 60} minutes`;
    
    // Update markdown
    const oldDurationText = `${oldDuration / 60} minutes`;
    const newDurationText = `${pose.durationInSeconds / 60} minutes`;
    updateMarkdown(pose, oldDurationText, newDurationText);
  });

  // Step 2: Fix rounding errors
  currentTotal = allPoses.reduce((sum, pose) => sum + (pose.durationInSeconds / 60), 0);
  let lastModifiedPoseIndex = -1;

  while (Math.abs(currentTotal - targetMinutes) >= 1) {
    if (currentTotal > targetMinutes) {
      // Find longest pose(s) excluding the last modified one
      const longestPoses = allPoses
        .map((pose, index) => ({ pose, index, duration: pose.durationInSeconds }))
        .filter(({ index }) => index !== lastModifiedPoseIndex)
        .reduce((acc, curr) => {
          if (acc.length === 0 || curr.duration === acc[0].duration) {
            return [...acc, curr];
          }
          return curr.duration > acc[0].duration ? [curr] : acc;
        }, [] as { pose: YogaPose; index: number; duration: number }[]);

      // Pick a random longest pose
      const { pose, index } = longestPoses[Math.floor(Math.random() * longestPoses.length)];
      
      // Reduce duration by 1 minute
      const oldDuration = pose.durationInSeconds;
      pose.durationInSeconds = Math.max(60, pose.durationInSeconds - 60); // Ensure minimum 1 minute
      pose.duration = `${pose.durationInSeconds / 60} minutes`;
      
      // Update markdown
      const oldDurationText = `${oldDuration / 60} minutes`;
      const newDurationText = `${pose.durationInSeconds / 60} minutes`;
      updateMarkdown(pose, oldDurationText, newDurationText);
      
      lastModifiedPoseIndex = index;
      currentTotal -= 1;
    } else {
      // Find shortest pose(s) excluding the last modified one
      const shortestPoses = allPoses
        .map((pose, index) => ({ pose, index, duration: pose.durationInSeconds }))
        .filter(({ index }) => index !== lastModifiedPoseIndex)
        .reduce((acc, curr) => {
          if (acc.length === 0 || curr.duration === acc[0].duration) {
            return [...acc, curr];
          }
          return curr.duration < acc[0].duration ? [curr] : acc;
        }, [] as { pose: YogaPose; index: number; duration: number }[]);

      // Pick a random shortest pose
      const { pose, index } = shortestPoses[Math.floor(Math.random() * shortestPoses.length)];
      
      // Increase duration by 1 minute
      const oldDuration = pose.durationInSeconds;
      pose.durationInSeconds += 60;
      pose.duration = `${pose.durationInSeconds / 60} minutes`;
      
      // Update markdown
      const oldDurationText = `${oldDuration / 60} minutes`;
      const newDurationText = `${pose.durationInSeconds / 60} minutes`;
      updateMarkdown(pose, oldDurationText, newDurationText);
      
      lastModifiedPoseIndex = index;
      currentTotal += 1;
    }
  }

  return { sections, updatedMarkdown };
}

// Enhanced sequence generation with structured output
export async function generateYogaSequence(
  duration: number,
  level: string,
  intent: string = '',
  onChunk?: (chunk: string, usage?: { total_tokens: number }) => void,
  isCustomIntent: boolean = false
): Promise<YogaSequence> {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (!user) throw new Error('User not authenticated');
  const { data: { session } } = await supabase.auth.getSession();
  if (!session || !session.access_token) throw new Error('No access token found');

  // Use two different prompts
  const inclusivePrompt = `Create a ${duration}-minute ${level} level session. This session can be a yoga flow, meditation, breathwork, or any custom sequence. The 'poses' array can include any type of block (e.g. yoga pose, meditation, breathwork, rest, or other activity). Use the user's intent below to guide the session content.

Intent for this session: ${intent}

IMPORTANT: Return ONLY a JSON object with this exact structure:
{
  "sections": [
    {
      "title": "Section Name",
      "poses": [
        {
          "name": "Block Name (e.g. Mountain Pose, Meditation, Breathwork)",
          "sanskritName": "Sanskrit or Subtitle (optional)",
          "durationMinutes": 2,
          "benefits": "Describe the benefit or purpose of this block",
          "instructions": [
            "Step-by-step instructions or guidance for this block"
          ],
          "intentRelation": "How this block supports the session intent"
        }
      ]
    },
    // ... more sections ...
  ]
}

Guidelines:
- Total duration should be exactly ${duration}
- Each block should have 2-4 clear instructions or guidance
- Benefits should be concise and specific
- Intent relation should explain how the block connects to the session intent
- Use proper names for blocks (yoga poses, meditation types, breathwork, etc.)
- Include 3-5 blocks per section, for longer session durations (+30 minutes), have more blocks to make up the time rather than extending the length of each block too much, unless the user asks for it
- Ensure smooth transitions between blocks

All property names and string values must be in double quotes. Do not omit any quotes. If you are unsure, output valid JSON only.

Return ONLY the JSON object, no explanations or markdown formatting.`;

  const yogaPrompt = `Create a ${duration}-minute ${level} level yoga sequence.

Intent for this session: ${intent}

IMPORTANT: Return ONLY a JSON object with this exact structure:
{
  "sections": [
    {
      "title": "Warmup",
      "poses": [
        {
          "name": "Mountain Pose",
          "sanskritName": "Tadasana", 
          "durationMinutes": 2,
          "benefits": "Improves posture and body awareness",
          "instructions": [
            "Stand with feet together",
            "Ground down through the feet",
            "Engage thighs and lift chest"
          ],
          "intentRelation": "Grounds energy and establishes connection with the earth, supporting emotional stability"
        }
      ]
    },
    {
      "title": "Main Sequence", 
      "poses": [...]
    },
    {
      "title": "Cooldown",
      "poses": [...]
    }
  ]
}

Guidelines:
- Total duration should be exactly ${duration}
- Each pose should have 2-4 clear instructions
- Benefits should be concise and specific
- Intent relation should explain how the pose connects to the session intent
- Use proper Sanskrit names for poses
- Include 3-5 poses per section, for longer session durations (+30 minutes), have more poses to make up the time rather than extending the length of each pose too much
- Ensure smooth transitions between poses

All property names and string values must be in double quotes. Do not omit any quotes. If you are unsure, output valid JSON only.

Return ONLY the JSON object, no explanations or markdown formatting.`;

  const enhancedPrompt = isCustomIntent ? inclusivePrompt : yogaPrompt;

  if (onChunk) {
    // Streaming mode with structured output
    const response = await fetch(fnUrl('ai_proxy'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        messages: [{
          role: 'user',
          content: enhancedPrompt
        }],
        model: 'gpt-4.1',
        max_tokens: 4000,
        temperature: 0.3,
        stream: true
      })
    });
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Failed to generate yoga sequence');
    }
    
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let content = '';
    let usage = null;
    
    if (!reader) throw new Error('Failed to get response reader');
    
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter(line => line.trim() !== '');
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            const text = parsed.choices?.[0]?.delta?.content || '';
            if (text) {
              content += text;
              onChunk(text, parsed.usage);
            }
            if (parsed.usage && typeof parsed.usage.total_tokens === 'number') {
              usage = parsed.usage;
            }
          } catch (e) {
            // ignore
          }
        }
      }
    }

    // Try to parse as structured JSON first
    try {
      const repaired = jsonrepair(content);
      const structuredResponse = JSON.parse(repaired) as StructuredYogaResponse;
      const sections: YogaSection[] = structuredResponse.sections.map(section => ({
        title: section.title,
        poses: section.poses.map(pose => ({
          name: pose.name,
          sanskritName: pose.sanskritName,
          duration: `${pose.durationMinutes} minutes`,
          durationInSeconds: pose.durationMinutes * 60,
          benefits: pose.benefits,
          instructions: pose.instructions,
          intentRelation: pose.intentRelation
        })),
        rawMarkdown: ''
      }));

      // Adjust durations to match target
      const { sections: adjustedSections, updatedMarkdown } = adjustDurationsToMatch(sections, duration, content);
      
      return {
        title: `Yoga Flow - ${duration} minutes`,
        duration,
        level,
        intent,
        sections: adjustedSections,
        rawMarkdown: updatedMarkdown
      };
    } catch (e) {
      // Fallback to markdown parsing if JSON parsing fails
      console.warn('Failed to parse structured JSON, falling back to markdown parsing:', e);
    const parsedSections = parseYogaSequence(content);
    return {
      title: `Yoga Flow - ${duration} minutes`,
      duration,
      level,
      intent,
      sections: parsedSections,
      rawMarkdown: content
    };
    }
  } else {
    // Non-streaming mode with structured output
    const response = await fetch(fnUrl('ai_proxy'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        messages: [{
          role: 'user',
          content: enhancedPrompt
        }],
        model: 'gpt-4.1',
        max_tokens: 4000,
        temperature: 0.1
      })
    });
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to generate yoga sequence');
    }
    
    const rawContent = data.choices?.[0]?.message?.content || '';
    
    // Try to parse as structured JSON first
    try {
      const repaired = jsonrepair(rawContent);
      const structuredResponse = JSON.parse(repaired) as StructuredYogaResponse;
      const sections: YogaSection[] = structuredResponse.sections.map(section => ({
        title: section.title,
        poses: section.poses.map(pose => ({
          name: pose.name,
          sanskritName: pose.sanskritName,
          duration: `${pose.durationMinutes} minutes`,
          durationInSeconds: pose.durationMinutes * 60,
          benefits: pose.benefits,
          instructions: pose.instructions,
          intentRelation: pose.intentRelation
        })),
        rawMarkdown: ''
      }));

      // Adjust durations to match target
      const { sections: adjustedSections, updatedMarkdown } = adjustDurationsToMatch(sections, duration, rawContent);
      
      return {
        title: `Yoga Flow - ${duration} minutes`,
        duration,
        level,
        intent,
        sections: adjustedSections,
        rawMarkdown: updatedMarkdown
      };
    } catch (e) {
      // Fallback to markdown parsing if JSON parsing fails
      console.warn('Failed to parse structured JSON, falling back to markdown parsing:', e);
      const parsedSections = parseYogaSequence(rawContent);
    return {
      title: `Yoga Flow - ${duration} minutes`,
      duration,
      level,
      intent,
      sections: parsedSections,
        rawMarkdown: rawContent
      };
    }
  }
}

// Utility functions for sequence validation and error handling
export function validateYogaSequence(sequence: any): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!sequence) {
    errors.push('Sequence is null or undefined');
    return { isValid: false, errors };
  }
  
  if (!Array.isArray(sequence.sections) || sequence.sections.length === 0) {
    errors.push('Sequence must have at least one section');
    return { isValid: false, errors };
  }
  
  let totalPoses = 0;
  let totalDuration = 0;
  
  for (let i = 0; i < sequence.sections.length; i++) {
    const section = sequence.sections[i];
    
    if (!section.title || typeof section.title !== 'string') {
      errors.push(`Section ${i + 1} must have a valid title`);
    }
    
    if (!Array.isArray(section.poses)) {
      errors.push(`Section "${section.title}" must have a poses array`);
      continue;
    }
    
    for (let j = 0; j < section.poses.length; j++) {
      const pose = section.poses[j];
      totalPoses++;
      
      if (!pose.name || typeof pose.name !== 'string') {
        errors.push(`Pose ${j + 1} in section "${section.title}" must have a valid name`);
      }
      
      if (!pose.sanskritName || typeof pose.sanskritName !== 'string') {
        errors.push(`Pose "${pose.name}" must have a valid Sanskrit name`);
      }
      
      if (!pose.duration || typeof pose.duration !== 'string') {
        errors.push(`Pose "${pose.name}" must have a valid duration`);
      }
      
      if (typeof pose.durationInSeconds !== 'number' || pose.durationInSeconds <= 0) {
        errors.push(`Pose "${pose.name}" must have a valid duration in seconds`);
      } else {
        totalDuration += pose.durationInSeconds;
      }
      
      if (!pose.benefits || typeof pose.benefits !== 'string') {
        errors.push(`Pose "${pose.name}" must have benefits description`);
      }
      
      if (!Array.isArray(pose.instructions) || pose.instructions.length === 0) {
        errors.push(`Pose "${pose.name}" must have at least one instruction`);
      }
    }
  }
  
  if (totalPoses === 0) {
    errors.push('Sequence must have at least one pose');
  }
  
  if (totalDuration === 0) {
    errors.push('Sequence must have a total duration greater than 0');
  }
  
  return { isValid: errors.length === 0, errors };
}

export function sanitizeYogaSequence(sequence: any): YogaSequence {
  // Deep clone to avoid mutating the original
  const sanitized = JSON.parse(JSON.stringify(sequence));
  
  // Ensure all required fields exist with defaults
  sanitized.title = sanitized.title || 'Untitled Sequence';
  sanitized.duration = sanitized.duration || 20;
  sanitized.level = sanitized.level || 'intermediate';
  sanitized.intent = sanitized.intent || '';
  sanitized.sections = sanitized.sections || [];
  
  // Sanitize each section
  sanitized.sections = sanitized.sections.map((section: any, sectionIndex: number) => ({
    title: section.title || `Section ${sectionIndex + 1}`,
    poses: (section.poses || []).map((pose: any, poseIndex: number) => ({
      name: pose.name || `Pose ${poseIndex + 1}`,
      sanskritName: pose.sanskritName || pose.name || `Pose ${poseIndex + 1}`,
      duration: pose.duration || '1 minutes',
      durationInSeconds: pose.durationInSeconds || 60,
      benefits: pose.benefits || 'Improves overall well-being',
      instructions: Array.isArray(pose.instructions) ? pose.instructions : ['Follow your breath'],
      intentRelation: pose.intentRelation || 'Supports the overall practice intention',
      rawMarkdown: pose.rawMarkdown || ''
    })),
    rawMarkdown: section.rawMarkdown || ''
  }));
  
  return sanitized;
}

export function createFallbackSequence(duration: number, level: string, intent: string): YogaSequence {
  return {
    title: `Yoga Flow - ${duration} minutes`,
    duration,
    level,
    intent,
    sections: [
      {
        title: 'Warmup',
        poses: [
          {
            name: 'Mountain Pose',
            sanskritName: 'Tadasana',
            duration: '2 minutes',
            durationInSeconds: 120,
            benefits: 'Improves posture and body awareness',
            instructions: [
              'Stand with feet together',
              'Ground down through the feet',
              'Engage thighs and lift chest'
            ],
            intentRelation: 'Grounds energy and establishes connection with the earth'
          }
        ],
        rawMarkdown: ''
      },
      {
        title: 'Main Sequence',
        poses: [
          {
            name: 'Child\'s Pose',
            sanskritName: 'Balasana',
            duration: `${Math.max(1, Math.floor(duration * 0.4))} minutes`,
            durationInSeconds: Math.max(60, Math.floor(duration * 0.4 * 60)),
            benefits: 'Relaxes the back and calms the mind',
            instructions: [
              'Kneel on the mat',
              'Sit back on your heels',
              'Fold forward with arms extended'
            ],
            intentRelation: 'Provides a moment of rest and reflection'
          }
        ],
        rawMarkdown: ''
      },
      {
        title: 'Cooldown',
        poses: [
          {
            name: 'Corpse Pose',
            sanskritName: 'Savasana',
            duration: `${Math.max(1, Math.floor(duration * 0.2))} minutes`,
            durationInSeconds: Math.max(60, Math.floor(duration * 0.2 * 60)),
            benefits: 'Allows complete relaxation and integration',
            instructions: [
              'Lie on your back',
              'Close your eyes',
              'Relax completely'
            ],
            intentRelation: 'Integrates the practice and allows for deep rest'
          }
        ],
        rawMarkdown: ''
      }
    ],
    rawMarkdown: ''
  };
}

/**
 * Converts a yoga sequence JSON (with sections, poses, etc.) to markdown.
 * @param json - The parsed yoga sequence JSON object (with sections, poses, etc.)
 * @returns Markdown string
 */
export function yogaSequenceJsonToMarkdown(json: any): string {
  if (!json.sections || !Array.isArray(json.sections)) return 'Invalid sequence data';

  let md = '';
  for (const section of json.sections) {
    md += `## ${section.title}\n\n`;
    for (const pose of section.poses) {
      // Support both durationMinutes and duration fields
      const duration = pose.durationMinutes !== undefined ? `${pose.durationMinutes} minutes` : (pose.duration || '');
      md += `### ${pose.name} (${pose.sanskritName}) - ${duration}\n\n`;
      if (pose.benefits) {
        md += `**Benefits:** ${pose.benefits}\n\n`;
      }
      if (pose.instructions && pose.instructions.length) {
        md += `**Instructions:**\n`;
        for (const step of pose.instructions) {
          md += `- ${step}\n`;
        }
        md += '\n';
      }
      if (pose.intentRelation) {
        md += `**Intent Relation:** ${pose.intentRelation}\n\n`;
      }
    }
  }
  return md.trim();
}