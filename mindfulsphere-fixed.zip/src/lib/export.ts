import { YogaSequence } from './yoga';
import jsPDF from 'jspdf';
import { poseDatabase } from './poses';

export function exportToMarkdown(content: string | YogaSequence, type: 'yoga' | 'journal'): string {
  if (type === 'yoga' && typeof content !== 'string') {
    const sequence = content as YogaSequence;
    return `# ${sequence.title}

Duration: ${sequence.duration} minutes
Level: ${sequence.level}
Focus: ${sequence.focus}

${sequence.sections.map(section => `
## ${section.title}

${section.poses.map(pose => `
### ${pose.name} (${pose.sanskritName}) - ${pose.duration}

**Benefits:** ${pose.benefits}

**Instructions:**
${pose.instructions.map(instruction => `- ${instruction}`).join('\n')}
`).join('\n')}
`).join('\n')}`;
  }

  // For journal entries, content is already a string
  return content as string;
}

export function downloadAsFile(content: string, filename: string, format: 'md' | 'pdf' = 'md') {
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.${format}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function normalizePoseName(name: string) {
  return name
    .toLowerCase()
    .replace(/[-_ ]+/g, '')
    .replace(/[^a-z0-9]/g, '');
}

/**
 * Resolves the image URL for a pose, using the same logic as the UI.
 * - If pose.image exists, use it.
 * - Otherwise, search poseDatabase by normalized name, then by sanskritName.
 * - Returns the image URL from poseImages, or undefined if not found.
 */
export function resolvePoseImage(pose: any, poseDatabase: any, poseImages: Record<string, string>): string | undefined {
  let imageName = pose.image;
  if (!imageName) {
    const normalizedPoseName = normalizePoseName(pose.name || '');
    let foundPose;
    for (const category of poseDatabase) {
      foundPose = category.poses.find((p: any) => normalizePoseName(p.name) === normalizedPoseName);
      if (foundPose && foundPose.image) {
        imageName = foundPose.image;
        break;
      }
    }
    // If not found by name, try sanskritName
    if (!imageName && pose.sanskritName) {
      const normalizedSanskrit = normalizePoseName(pose.sanskritName);
      for (const category of poseDatabase) {
        foundPose = category.poses.find((p: any) => normalizePoseName(p.sanskritName) === normalizedSanskrit);
        if (foundPose && foundPose.image) {
          imageName = foundPose.image;
          break;
        }
      }
    }
  }
  return imageName ? poseImages[`../assets/poses/${imageName}`] : undefined;
}

export async function exportToPDF(sequence: YogaSequence, poseImages: Record<string, string>, dbTitle?: string) {
  try {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
    const margin = 40;
    let y = margin;
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const usableWidth = pageWidth - margin * 2;

    // Soft background for all pages
    function setSoftBackground() {
      doc.setFillColor(245, 242, 255);
      doc.rect(0, 0, pageWidth, pageHeight, 'F');
    }
    // Add MindfulSphere watermark
    function addWatermark() {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(200, 200, 220);
      doc.text('MindfulSphere', pageWidth - margin, pageHeight - 10, { align: 'right' });
    }
    setSoftBackground();

    // --- Adaptive Title Rendering ---
    let title = dbTitle || sequence.title || 'Yoga Sequence';
    let titleFontSize = 28;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(60, 40, 120);
    // Reduce font size if title is too wide
    let titleWidth = doc.getTextWidth(title);
    const maxTitleWidth = usableWidth;
    while (titleWidth > maxTitleWidth && titleFontSize > 16) {
      titleFontSize -= 2;
      doc.setFontSize(titleFontSize);
      titleWidth = doc.getTextWidth(title);
    }
    doc.setFontSize(titleFontSize);
    doc.text(title, pageWidth / 2, y, { align: 'center', maxWidth: usableWidth });
    y += titleFontSize + 8;

    // --- Adaptive Metadata (Intent, Level, Duration) ---
    doc.setFont('helvetica', 'normal');
    let metaFontSize = 14;
    doc.setFontSize(metaFontSize);
    doc.setTextColor(80, 60, 140);
    const metaFields = [
      `Intent: ${sequence.intent || ''}`,
      `Level: ${sequence.level || ''}`,
      `Total Duration: ${sequence.duration || ''} min`
    ];
    // Try to fit all fields in one line, else stack vertically or reduce font size
    let metaY = y;
    let metaX = margin;
    let metaSpacing = 220;
    let fitsInline = true;
    let totalMetaWidth = metaFields.reduce((sum, field) => sum + doc.getTextWidth(field), 0) + metaSpacing * 2;
    if (totalMetaWidth > usableWidth) {
      // Try reducing font size
      while (totalMetaWidth > usableWidth && metaFontSize > 10) {
        metaFontSize -= 1;
        doc.setFontSize(metaFontSize);
        totalMetaWidth = metaFields.reduce((sum, field) => sum + doc.getTextWidth(field), 0) + metaSpacing * 2;
      }
      if (totalMetaWidth > usableWidth) {
        fitsInline = false;
      }
    }
    if (fitsInline) {
      // Draw inline
      doc.setFontSize(metaFontSize);
      doc.text(metaFields[0], margin, metaY);
      doc.text(metaFields[1], margin + metaSpacing, metaY);
      doc.text(metaFields[2], margin + metaSpacing * 2, metaY);
      y += metaFontSize + 10;
    } else {
      // Stack vertically
      for (const field of metaFields) {
        doc.setFontSize(metaFontSize);
        doc.text(field, margin, y);
        y += metaFontSize + 6;
      }
      y += 4;
    }

    // --- Pose Cards Grid (all sections) ---
    let poseGlobalIndex = 1;
    let isFirstSection = true;
    for (const section of sequence.sections) {
      if (!section.poses || !section.poses.length) continue;
      // --- Always start a new page for each section except the first ---
      if (!isFirstSection) {
        addWatermark();
        doc.addPage();
        setSoftBackground();
        y = margin;
      }
      isFirstSection = false;
      // Section title
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 80, 180);
      doc.text(section.title || '', margin, y);
      y += 24;

      // Dynamically choose columns (2 or 3)
      let numCols = 2;
      if (section.poses.length >= 6 && usableWidth > 500) numCols = 3;
      const colGap = 20;
      const colWidth = (usableWidth - (numCols - 1) * colGap) / numCols;
      const minCardHeight = 120;
      const cardVerticalMargin = 12;
      // --- Pre-measure all card heights and determine max image size for the row ---
      const cardHeights: number[] = [];
      const nameLinesArr: string[][] = [];
      const sanskritLinesArr: string[][] = [];
      const imageSizes: number[] = [];
      const nameFontSizes: number[] = [];
      const sanskritFontSizes: number[] = [];
      for (const pose of section.poses) {
        let imgSize = Math.min(colWidth * 0.9, 180);
        let nameFont = 14;
        let sanskritFont = 11;
        const textMaxWidth = colWidth - 32;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(nameFont);
        const nameLines = doc.splitTextToSize(pose.name || '', textMaxWidth);
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(sanskritFont);
        const sanskritLines = doc.splitTextToSize(pose.sanskritName || '', textMaxWidth);
        // Card height is always: padding + image + padding + name + sanskrit + padding
        let cardHeight = cardVerticalMargin + 16 + imgSize + 18 + nameLines.length * (nameFont + 4) + sanskritLines.length * (sanskritFont + 4) + 18 + cardVerticalMargin;
        nameLinesArr.push(nameLines);
        sanskritLinesArr.push(sanskritLines);
        cardHeights.push(Math.max(minCardHeight, cardHeight));
        imageSizes.push(imgSize);
        nameFontSizes.push(nameFont);
        sanskritFontSizes.push(sanskritFont);
      }
      // --- Group into rows ---
      const rows: { poses: typeof section.poses, heights: number[], nameLines: string[][], sanskritLines: string[][], imageSizes: number[], nameFontSizes: number[], sanskritFontSizes: number[] }[] = [];
      for (let i = 0; i < section.poses.length; i += numCols) {
        rows.push({
          poses: section.poses.slice(i, i + numCols),
          heights: cardHeights.slice(i, i + numCols),
          nameLines: nameLinesArr.slice(i, i + numCols),
          sanskritLines: sanskritLinesArr.slice(i, i + numCols),
          imageSizes: imageSizes.slice(i, i + numCols),
          nameFontSizes: nameFontSizes.slice(i, i + numCols),
          sanskritFontSizes: sanskritFontSizes.slice(i, i + numCols),
        });
      }
      // --- Draw rows, never split a row across pages ---
      for (const row of rows) {
        // For this row, use the max card height and max image size among all cards in the row
        const rowHeight = Math.max(...row.heights);
        const rowImgSize = Math.max(...row.imageSizes);
        // Check if row fits
        if (y + rowHeight + cardVerticalMargin > pageHeight - 20) {
          addWatermark();
          doc.addPage();
          setSoftBackground();
          y = margin;
        }
        // Draw all cards in the row
        for (let col = 0; col < row.poses.length; col++) {
          const pose = row.poses[col];
          const x = margin + col * (colWidth + colGap + 12); // extra horizontal gap
          const poseY = y + cardVerticalMargin;
          let imgSize = rowImgSize;
          let imageY = poseY + 16;
          const imgX = x + (colWidth - imgSize) / 2;
          // Draw card background + border
          doc.setFillColor(255, 255, 255);
          doc.setDrawColor(220, 210, 255);
          doc.roundedRect(x, y, colWidth, rowHeight, 16, 16, 'FD');
          // Draw number badge (top-left)
          const badgeRadius = 18;
          const badgeX = x + 16;
          const badgeY = y + 16;
          doc.setFillColor(120, 100, 180);
          doc.setDrawColor(255, 255, 255);
          doc.circle(badgeX, badgeY, badgeRadius, 'FD');
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(18);
          doc.setTextColor(255, 255, 255);
          // Center the number perfectly in the badge
          doc.text(String(poseGlobalIndex), badgeX, badgeY, { align: 'center', baseline: 'middle' });
          poseGlobalIndex++;
          // Draw image (with true rounded corners using canvas)
          const imageUrl = resolvePoseImage(pose, poseDatabase, poseImages);
          if (imageUrl) {
            try {
              // Use a weak (subtle) corner radius, e.g., 12px or 10% of imgSize
              const radius = Math.max(12, Math.floor(imgSize * 0.10));
              // Preprocess image with canvas to get rounded corners
              const roundedImg = await loadImageWithRoundedCorners(imageUrl, Math.round(imgSize), Math.round(imgSize), radius);
              doc.addImage(roundedImg, 'PNG', imgX, imageY, imgSize, imgSize, undefined, 'FAST');
            } catch (e) {}
          }
          // Draw text
          let nameY = imageY + imgSize + 18;
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(row.nameFontSizes[col]);
          doc.setTextColor(60, 40, 120);
          for (const line of row.nameLines[col]) {
            doc.text(line, x + colWidth / 2, nameY, { align: 'center', maxWidth: colWidth - 32 });
            nameY += row.nameFontSizes[col] + 4;
          }
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(row.sanskritFontSizes[col]);
          doc.setTextColor(120, 100, 180);
          let sanskritY = nameY;
          for (const line of row.sanskritLines[col]) {
            doc.text(line, x + colWidth / 2, sanskritY, { align: 'center', maxWidth: colWidth - 32 });
            sanskritY += row.sanskritFontSizes[col] + 4;
          }
        }
        y += rowHeight + cardVerticalMargin + 8; // extra vertical gap
      }
      // If near bottom, add new page
      if (y > pageHeight - 60) {
        addWatermark();
        doc.addPage();
        setSoftBackground();
        y = margin;
      }
    }

    // --- Detailed Instructions (new page, with soft background) ---
    addWatermark();
    doc.addPage();
    setSoftBackground();
    y = margin;
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(120, 90, 180);
    doc.text('Instructions', margin, y);
    y += 28;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(12);
    doc.setTextColor(60, 40, 120);
    for (const section of sequence.sections) {
      for (const pose of section.poses) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.text(`${pose.name} (${pose.sanskritName || ''})`, margin, y);
        y += 16;
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(11);
        doc.setTextColor(120, 100, 180);
        doc.text(`Duration: ${(pose.durationInSeconds / 60).toFixed(0)} min`, margin, y);
        y += 14;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(11);
        doc.setTextColor(120, 120, 140);
        if (pose.benefits) {
          const benefitLines = doc.splitTextToSize(`Benefits: ${pose.benefits}`, pageWidth - margin * 2 - 16);
          for (const line of benefitLines) {
            doc.text(line, margin, y);
            y += 13;
          }
        }
        if (pose.intentRelation) {
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(11);
          doc.setTextColor(100, 120, 180);
          const intentLines = doc.splitTextToSize(`Connection to Intent: ${pose.intentRelation}`, pageWidth - margin * 2 - 16);
          for (const line of intentLines) {
            doc.text(line, margin, y);
            y += 13;
          }
        }
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(11);
        doc.setTextColor(80, 80, 120);
        if (pose.instructions && pose.instructions.length) {
          for (const line of pose.instructions) {
            doc.text(`- ${line}`, margin + 16, y, { maxWidth: pageWidth - margin * 2 - 32 });
            y += 13;
            if (y > pageHeight - margin) {
              addWatermark();
              doc.addPage();
              setSoftBackground();
              y = margin;
            }
          }
        }
        y += 10;
        if (y > pageHeight - margin) {
          addWatermark();
          doc.addPage();
          setSoftBackground();
          y = margin;
        }
      }
    }
    addWatermark();
    // Save
    doc.save(`${sequence.title || 'yoga-sequence'}.pdf`);
  } catch (err) {
    console.error('PDF export failed:', err);
    throw err;
  }
}

// Helper to load image as data URL for jsPDF
async function loadImageAsDataUrl(url: string): Promise<string> {
  const res = await fetch(url);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('Failed to load image as data URL'));
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// --- NEW: Helper to load image and apply rounded rectangle mask using canvas ---
async function loadImageWithRoundedCorners(url: string, width: number, height: number, radius: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('No canvas context'));
      // Draw rounded rect path
      ctx.clearRect(0, 0, width, height);
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(radius, 0);
      ctx.lineTo(width - radius, 0);
      ctx.quadraticCurveTo(width, 0, width, radius);
      ctx.lineTo(width, height - radius);
      ctx.quadraticCurveTo(width, height, width - radius, height);
      ctx.lineTo(radius, height);
      ctx.quadraticCurveTo(0, height, 0, height - radius);
      ctx.lineTo(0, radius);
      ctx.quadraticCurveTo(0, 0, radius, 0);
      ctx.closePath();
      ctx.clip();
      // Draw image inside clipped area
      ctx.drawImage(img, 0, 0, width, height);
      ctx.restore();
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = reject;
    img.src = url;
  });
}