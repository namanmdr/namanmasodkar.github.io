import { 
  parseYogaSequence, 
  validateYogaSequence, 
  sanitizeYogaSequence, 
  createFallbackSequence,
  type YogaSequence,
  type YogaPose 
} from './yoga';

// Test data for various scenarios
const validMarkdown = `
Section: Warmup
1. Mountain Pose (Tadasana) - 2 minutes
   Benefits: Improves posture and body awareness
   Intent Relation: Grounds energy and establishes connection with the earth
   - Stand with feet together
   - Ground down through the feet
   - Engage thighs and lift chest

2. Cat-Cow (Marjaryasana-Bitilasana) - 3 minutes
   Benefits: Warms up spine and improves mobility
   Intent Relation: Harmonizes breath with movement
   - Come to all fours
   - Inhale, arch the back and lift the tailbone
   - Exhale, round the spine and tuck the chin

Section: Main Sequence
1. Downward Dog (Adho Mukha Svanasana) - 5 minutes
   Benefits: Strengthens arms and legs, stretches shoulders
   Intent Relation: Builds strength and focus
   - Start on hands and knees
   - Lift hips up and back
   - Press through the hands and feet

Section: Cooldown
1. Child's Pose (Balasana) - 3 minutes
   Benefits: Relaxes the back and calms the mind
   Intent Relation: Provides rest and integration
   - Kneel on the mat
   - Sit back on your heels
   - Fold forward with arms extended
`;

const malformedMarkdown = `
Section: Warmup
Mountain Pose - 2 minutes
Benefits: Improves posture
- Stand with feet together

Section: Main Sequence
Downward Dog - 5 minutes
Benefits: Strengthens arms
- Start on hands and knees
`;

const emptyMarkdown = `
Section: Warmup
Section: Main Sequence
Section: Cooldown
`;

const validSequence: YogaSequence = {
  title: 'Test Sequence',
  duration: 20,
  level: 'intermediate',
  intent: 'Test intent',
  sections: [
    {
      title: 'Warmup',
      poses: [
        {
          name: 'Mountain Pose',
          sanskritName: 'Tadasana',
          duration: '2 minutes',
          durationInSeconds: 120,
          benefits: 'Improves posture',
          instructions: ['Stand with feet together'],
          intentRelation: 'Grounds energy'
        }
      ],
      rawMarkdown: ''
    }
  ],
  rawMarkdown: ''
};

const invalidSequence = {
  title: 'Invalid Sequence',
  duration: 20,
  level: 'intermediate',
  sections: [] // Missing poses
};

describe('Yoga Sequence System', () => {
  describe('parseYogaSequence', () => {
    test('should parse valid markdown correctly', () => {
      const sections = parseYogaSequence(validMarkdown);
      
      expect(sections).toHaveLength(3);
      expect(sections[0].title).toBe('Warmup');
      expect(sections[0].poses).toHaveLength(2);
      expect(sections[1].title).toBe('Main Sequence');
      expect(sections[1].poses).toHaveLength(1);
      expect(sections[2].title).toBe('Cooldown');
      expect(sections[2].poses).toHaveLength(1);
      
      // Check first pose details
      const firstPose = sections[0].poses[0];
      expect(firstPose.name).toBe('Mountain Pose');
      expect(firstPose.sanskritName).toBe('Tadasana');
      expect(firstPose.duration).toBe('2 minutes');
      expect(firstPose.durationInSeconds).toBe(120);
      expect(firstPose.benefits).toBe('Improves posture and body awareness');
      expect(firstPose.instructions).toHaveLength(3);
      expect(firstPose.intentRelation).toBe('Grounds energy and establishes connection with the earth');
    });

    test('should handle malformed markdown gracefully', () => {
      const sections = parseYogaSequence(malformedMarkdown);
      
      expect(sections).toHaveLength(2);
      expect(sections[0].title).toBe('Warmup');
      expect(sections[0].poses).toHaveLength(1);
      expect(sections[1].title).toBe('Main Sequence');
      expect(sections[1].poses).toHaveLength(1);
      
      // Check that missing fields are handled
      const firstPose = sections[0].poses[0];
      expect(firstPose.name).toBe('Mountain Pose');
      expect(firstPose.sanskritName).toBe('Mountain Pose'); // Fallback to English name
      expect(firstPose.duration).toBe('2 minutes');
      expect(firstPose.benefits).toBe('Improves posture');
      expect(firstPose.instructions).toHaveLength(1);
    });

    test('should handle empty markdown', () => {
      const sections = parseYogaSequence(emptyMarkdown);
      expect(sections).toHaveLength(3);
      sections.forEach(section => {
        expect(section.poses).toHaveLength(0);
      });
    });

    test('should handle various markdown formats', () => {
      const flexibleMarkdown = `
# Warmup
1. Mountain Pose (Tadasana) - 2 min
   Benefits: Improves posture
   - Stand with feet together

# Main Sequence  
Downward Dog (Adho Mukha Svanasana) - 5m
Benefits: Strengthens arms
- Start on hands and knees
      `;
      
      const sections = parseYogaSequence(flexibleMarkdown);
      expect(sections).toHaveLength(2);
      expect(sections[0].poses).toHaveLength(1);
      expect(sections[1].poses).toHaveLength(1);
    });
  });

  describe('validateYogaSequence', () => {
    test('should validate correct sequence', () => {
      const result = validateYogaSequence(validSequence);
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should detect invalid sequence', () => {
      const result = validateYogaSequence(invalidSequence);
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors).toContain('Sequence must have at least one pose');
    });

    test('should handle null/undefined sequence', () => {
      const result = validateYogaSequence(null);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Sequence is null or undefined');
    });

    test('should validate pose structure', () => {
      const invalidPoseSequence = {
        ...validSequence,
        sections: [
          {
            title: 'Warmup',
            poses: [
              {
                name: '', // Invalid: empty name
                sanskritName: 'Tadasana',
                duration: '2 minutes',
                durationInSeconds: 120,
                benefits: 'Improves posture',
                instructions: ['Stand with feet together'],
                intentRelation: 'Grounds energy'
              }
            ]
          }
        ]
      };
      
      const result = validateYogaSequence(invalidPoseSequence);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(error => error.includes('must have a valid name'))).toBe(true);
    });
  });

  describe('sanitizeYogaSequence', () => {
    test('should sanitize valid sequence', () => {
      const sanitized = sanitizeYogaSequence(validSequence);
      expect(sanitized.title).toBe('Test Sequence');
      expect(sanitized.sections).toHaveLength(1);
      expect(sanitized.sections[0].poses).toHaveLength(1);
    });

    test('should add defaults to incomplete sequence', () => {
      const incomplete = {
        sections: [
          {
            title: '',
            poses: [
              {
                name: '',
                sanskritName: '',
                duration: '',
                durationInSeconds: 0,
                benefits: '',
                instructions: [],
                intentRelation: ''
              }
            ]
          }
        ]
      };
      
      const sanitized = sanitizeYogaSequence(incomplete);
      expect(sanitized.title).toBe('Untitled Sequence');
      expect(sanitized.duration).toBe(20);
      expect(sanitized.level).toBe('intermediate');
      expect(sanitized.intent).toBe('');
      expect(sanitized.sections[0].title).toBe('Section 1');
      expect(sanitized.sections[0].poses[0].name).toBe('Pose 1');
      expect(sanitized.sections[0].poses[0].durationInSeconds).toBe(60);
      expect(sanitized.sections[0].poses[0].instructions).toHaveLength(1);
    });
  });

  describe('createFallbackSequence', () => {
    test('should create valid fallback sequence', () => {
      const fallback = createFallbackSequence(30, 'beginner', 'Test intent');
      
      expect(fallback.title).toBe('Yoga Flow - 30 minutes');
      expect(fallback.duration).toBe(30);
      expect(fallback.level).toBe('beginner');
      expect(fallback.intent).toBe('Test intent');
      expect(fallback.sections).toHaveLength(3);
      
      // Check section titles
      expect(fallback.sections[0].title).toBe('Warmup');
      expect(fallback.sections[1].title).toBe('Main Sequence');
      expect(fallback.sections[2].title).toBe('Cooldown');
      
      // Check that all poses have required fields
      fallback.sections.forEach(section => {
        section.poses.forEach(pose => {
          expect(pose.name).toBeTruthy();
          expect(pose.sanskritName).toBeTruthy();
          expect(pose.duration).toBeTruthy();
          expect(pose.durationInSeconds).toBeGreaterThan(0);
          expect(pose.benefits).toBeTruthy();
          expect(pose.instructions.length).toBeGreaterThan(0);
          expect(pose.intentRelation).toBeTruthy();
        });
      });
    });

    test('should calculate durations correctly', () => {
      const fallback = createFallbackSequence(20, 'intermediate', 'Test');
      
      // Main sequence should be 40% of total duration
      const mainPose = fallback.sections[1].poses[0];
      expect(mainPose.durationInSeconds).toBe(480); // 20 * 0.4 * 60
      
      // Cooldown should be 20% of total duration
      const cooldownPose = fallback.sections[2].poses[0];
      expect(cooldownPose.durationInSeconds).toBe(240); // 20 * 0.2 * 60
    });
  });

  describe('Integration tests', () => {
    test('should handle complete workflow', () => {
      // Parse markdown
      const sections = parseYogaSequence(validMarkdown);
      
      // Create sequence
      const sequence: YogaSequence = {
        title: 'Test Sequence',
        duration: 20,
        level: 'intermediate',
        intent: 'Test intent',
        sections,
        rawMarkdown: validMarkdown
      };
      
      // Validate
      const validation = validateYogaSequence(sequence);
      expect(validation.isValid).toBe(true);
      
      // Sanitize
      const sanitized = sanitizeYogaSequence(sequence);
      expect(sanitized.sections).toHaveLength(3);
      expect(sanitized.sections.every(s => s.poses.length > 0)).toBe(true);
    });

    test('should handle error recovery', () => {
      // Start with invalid sequence
      const invalid = {
        sections: []
      };
      
      // Validation should fail
      const validation = validateYogaSequence(invalid);
      expect(validation.isValid).toBe(false);
      
      // Sanitization should fix it
      const sanitized = sanitizeYogaSequence(invalid);
      const revalidation = validateYogaSequence(sanitized);
      expect(revalidation.isValid).toBe(true);
    });
  });
}); 