import { supabase } from './supabase';
import type { YogaPose } from './yoga';

export interface PoseCategory {
  name: string;
  poses: YogaPose[];
}

export interface UserPose extends YogaPose {
  id: string;
  createdAt?: string;
}

export const poseDatabase: PoseCategory[] = [
  {
    name: "Standing Poses",
    poses: [
      {
        name: "Mountain Pose",
        sanskritName: "Tadasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Improves posture, balance, and body awareness. Grounds energy and establishes a strong foundation for practice.",
        instructions: [
          "Stand with feet together, big toes touching, heels slightly apart.",
          "Ground down through all four corners of the feet.",
          "Engage thighs, lift kneecaps, and draw tailbone down.",
          "Lengthen spine, broaden collarbones, and relax shoulders back and down.",
          "Reach through the crown of the head and breathe deeply."
        ],
        image: "mountain-pose.png"
      },
      {
        name: "Downward-Facing Dog",
        sanskritName: "Adho Mukha Svanasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches the hamstrings, calves, and spine. Strengthens arms and legs. Calms the mind.",
        instructions: [
          "Start on hands and knees, wrists under shoulders, knees under hips.",
          "Spread fingers wide and press firmly into the mat.",
          "Tuck toes, lift knees, and send hips up and back.",
          "Straighten legs as much as possible, heels reaching toward the floor.",
          "Relax head between arms and gaze toward feet."
        ],
        image: "downward-facing-dog.png"
      },
      {
        name: "Warrior I",
        sanskritName: "Virabhadrasana I",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens legs, opens hips and chest, improves focus and balance.",
        instructions: [
          "Step one foot forward and bend the front knee to 90 degrees.",
          "Back foot turns out slightly, heel grounded.",
          "Square hips and shoulders to the front.",
          "Reach arms overhead, palms facing each other.",
          "Engage core and gaze forward or up."
        ],
        image: "warrior-i.png"
      },
      {
        name: "Warrior II",
        sanskritName: "Virabhadrasana II",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens legs and arms, opens hips and chest, builds stamina and concentration.",
        instructions: [
          "From standing, step feet wide apart.",
          "Turn right foot out 90 degrees, left foot slightly in.",
          "Bend right knee over ankle, thigh parallel to floor.",
          "Extend arms out to sides, palms down, gaze over front hand."
        ],
        image: "warrior-ii.png"
      },
      {
        name: "Warrior III",
        sanskritName: "Virabhadrasana III",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Strengthens legs, core, and back. Improves balance and posture.",
        instructions: [
          "From standing, shift weight onto one leg.",
          "Hinge forward at hips, lifting back leg parallel to floor.",
          "Extend arms forward or to the sides for balance.",
          "Keep hips level and gaze down."
        ],
        image: "warrior-iii.png"
      },
      {
        name: "Triangle Pose",
        sanskritName: "Trikonasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches legs, hips, and spine. Opens chest and shoulders. Improves stability.",
        instructions: [
          "Stand with feet wide apart, arms extended at shoulder height.",
          "Turn right foot out, left foot slightly in.",
          "Reach right hand forward, then lower to shin or floor.",
          "Extend left arm up, stack shoulders, and gaze up."
        ],
        image: "triangle-pose.png"
      },
      {
        name: "Extended Side Angle",
        sanskritName: "Utthita Parsvakonasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens legs, stretches groins and waist, opens chest and shoulders.",
        instructions: [
          "From Warrior II, lower front forearm to thigh or hand to floor.",
          "Extend top arm over ear, palm facing down.",
          "Lengthen from back heel to fingertips.",
          "Gaze under top arm."
        ],
        image: "extended-side-angle.png"
      },
      {
        name: "Chair Pose",
        sanskritName: "Utkatasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens thighs, ankles, and back. Tones core and stimulates heart.",
        instructions: [
          "Stand with feet together, bend knees, and sink hips back as if sitting in a chair.",
          "Reach arms overhead, palms facing each other.",
          "Draw shoulders down and in.",
          "Keep weight in heels and chest lifted."
        ],
        image: "chair-pose.png"
      },
      {
        name: "Tree Pose",
        sanskritName: "Vrksasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Improves balance, focus, and concentration. Strengthens legs and core.",
        instructions: [
          "Stand on one leg, place other foot on inner thigh or calf (avoid knee).",
          "Press foot into leg and leg into foot.",
          "Bring hands to heart or overhead.",
          "Keep gaze steady and breathe."
        ],
        image: "tree-pose.png"
      },
      {
        name: "Crescent Lunge",
        sanskritName: "Anjaneyasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hips, strengthens legs, improves balance and focus.",
        instructions: [
          "Step one foot forward, bend front knee to 90 degrees.",
          "Back leg straight, heel lifted.",
          "Reach arms overhead, palms facing each other.",
          "Draw tailbone down and lift chest."
        ],
        image: "crescent-lunge.png"
      }
    ]
  },
  {
    name: "Seated Poses",
    poses: [
      {
        name: "Easy Pose",
        sanskritName: "Sukhasana",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Calms mind, opens hips, and lengthens spine. Encourages steady breath and relaxation.",
        instructions: [
          "Sit cross-legged, hands on knees or in lap.",
          "Stack shoulders over hips, lengthen spine.",
          "Relax shoulders down and away from ears.",
          "Close eyes and focus on breath."
        ],
        image: "easy-pose.png"
      },
      {
        name: "Staff Pose",
        sanskritName: "Dandasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens back, stretches hamstrings, improves posture and alignment.",
        instructions: [
          "Sit with legs extended, feet flexed.",
          "Engage thighs and press legs into floor.",
          "Sit tall with chest lifted and spine long.",
          "Place hands beside hips, fingers pointing forward."
        ],
        image: "staff-pose.png"
      },
      {
        name: "Seated Forward Bend",
        sanskritName: "Paschimottanasana",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Stretches spine, shoulders, and hamstrings. Calms the mind and relieves stress.",
        instructions: [
          "Sit with legs extended, feet flexed.",
          "Inhale, reach arms overhead, lengthen spine.",
          "Exhale, hinge at hips and fold forward, reaching for feet or shins.",
          "Keep spine long and relax neck."
        ],
        image: "seated-forward-bend.png"
      },
      {
        name: "Bound Angle Pose",
        sanskritName: "Baddha Konasana",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Opens hips and groins, stretches inner thighs, improves circulation.",
        instructions: [
          "Sit with soles of feet together, knees out to sides.",
          "Hold feet or ankles, sit tall.",
          "Gently press knees toward floor.",
          "Lengthen spine and breathe deeply."
        ],
        image: "bound-angle-pose.png"
      },
      {
        name: "Head-to-Knee Forward Bend",
        sanskritName: "Janu Sirsasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hamstrings, spine, and groins. Calms the mind.",
        instructions: [
          "Sit with one leg extended, other foot to inner thigh.",
          "Inhale, lengthen spine, exhale, fold over extended leg.",
          "Hold foot or shin, keep spine long.",
          "Repeat on other side."
        ],
        image: "head-to-knee-forward-bend.png"
      }
    ]
  },
  {
    name: "Balancing Poses",
    poses: [
      {
        name: "Eagle Pose",
        sanskritName: "Garudasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Improves balance, focus, and concentration. Stretches shoulders, hips, and thighs.",
        instructions: [
          "Stand on one leg, wrap other leg around standing leg.",
          "Wrap arms, right under left, palms touching.",
          "Bend knees, sink hips, and lift elbows.",
          "Gaze at a fixed point."
        ],
        image: "eagle-pose.png"
      },
      {
        name: "Dancer’s Pose",
        sanskritName: "Natarajasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Improves balance, stretches chest and shoulders, strengthens legs.",
        instructions: [
          "Stand on one leg, grab inside of opposite foot behind you.",
          "Press foot into hand, lift leg and chest.",
          "Extend other arm forward, keep hips square.",
          "Gaze forward."
        ],
        image: "dancers-pose.png"
      },
      {
        name: "Half Moon Pose",
        sanskritName: "Ardha Chandrasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Improves balance and coordination. Strengthens legs and stretches sides.",
        instructions: [
          "From standing, reach one hand to floor or block, lift back leg parallel to floor.",
          "Extend top arm up, open chest.",
          "Keep hips stacked and gaze up."
        ],
        image: "half-moon-pose.png"
      }
    ]
  },
  {
    name: "Backbends",
    poses: [
      {
        name: "Cobra Pose",
        sanskritName: "Bhujangasana",
        duration: "30 seconds",
        durationInSeconds: 30,
        benefits: "Strengthens spine, opens chest and shoulders, increases flexibility.",
        instructions: [
          "Lie on belly, place hands under shoulders.",
          "Press tops of feet down, engage legs.",
          "Inhale, lift chest, keep elbows bent and close to body.",
          "Shoulders away from ears, gaze forward."
        ],
        image: "cobra-pose.png"
      },
      {
        name: "Upward-Facing Dog",
        sanskritName: "Urdhva Mukha Svanasana",
        duration: "30 seconds",
        durationInSeconds: 30,
        benefits: "Strengthens arms, wrists, and spine. Opens chest and lungs.",
        instructions: [
          "Lie on belly, place hands under shoulders.",
          "Press into hands, straighten arms, lift chest and thighs off floor.",
          "Roll shoulders back, open chest.",
          "Gaze forward or slightly up."
        ],
        image: "upward-facing-dog.png"
      },
      {
        name: "Bridge Pose",
        sanskritName: "Setu Bandhasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens back, glutes, and legs. Opens chest and stretches spine.",
        instructions: [
          "Lie on back, bend knees, feet hip-width apart.",
          "Press feet and arms into floor, lift hips.",
          "Clasp hands under back, roll shoulders under.",
          "Hold and breathe."
        ],
        image: "bridge-pose.png"
      },
      {
        name: "Bow Pose",
        sanskritName: "Dhanurasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Stretches front body, strengthens back, improves posture.",
        instructions: [
          "Lie on belly, bend knees, grab ankles with hands.",
          "Inhale, lift chest and legs off floor.",
          "Press feet into hands, open chest.",
          "Gaze forward."
        ],
        image: "bow-pose.png"
      },
      {
        name: "Camel Pose",
        sanskritName: "Ustrasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches front of body, opens chest and shoulders, strengthens back.",
        instructions: [
          "Kneel on mat, knees hip-width apart.",
          "Place hands on lower back or heels.",
          "Press hips forward, lift chest, arch back.",
          "Gaze up or back."
        ],
        image: "camel-pose.png"
      },
      {
        name: "Wheel Pose",
        sanskritName: "Urdhva Dhanurasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Deep backbend, strengthens arms, legs, and spine. Energizes body and mind.",
        instructions: [
          "Lie on back, bend knees, place feet near hips.",
          "Place hands beside ears, fingers pointing toward shoulders.",
          "Press into hands and feet, lift body off floor.",
          "Straighten arms and legs as much as possible."
        ],
        image: "wheel-pose.png"
      }
    ]
  },
  {
    name: "Forward Bends",
    poses: [
      {
        name: "Standing Forward Bend",
        sanskritName: "Uttanasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hamstrings, calves, and spine. Calms the mind and relieves stress.",
        instructions: [
          "Stand with feet hip-width apart, hinge at hips to fold forward.",
          "Let head and arms hang, relax neck.",
          "Bend knees if needed, keep weight in balls of feet.",
          "Breathe deeply."
        ],
        image: "standing-forward-bend.png"
      },
      {
        name: "Wide-Legged Forward Bend",
        sanskritName: "Prasarita Padottanasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches inner thighs, hamstrings, and spine. Relieves mild backache.",
        instructions: [
          "Stand with feet wide apart, hands on hips.",
          "Inhale, lengthen spine, exhale, fold forward.",
          "Place hands on floor or grab ankles.",
          "Let head hang, relax neck."
        ],
        image: "wide-legged-forward-bend.png"
      },
      {
        name: "Child’s Pose",
        sanskritName: "Balasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Gently stretches hips, thighs, and ankles. Calms the brain and relieves stress.",
        instructions: [
          "Kneel on mat, big toes touching, knees apart.",
          "Sit back on heels, fold forward, arms extended or by sides.",
          "Rest forehead on mat, relax shoulders.",
          "Breathe deeply."
        ],
        image: "childs-pose.png"
      }
    ]
  },
  {
    name: "Twists",
    poses: [
      {
        name: "Seated Spinal Twist",
        sanskritName: "Ardha Matsyendrasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Increases spinal flexibility, stimulates digestion, relieves tension.",
        instructions: [
          "Sit with legs extended, bend right knee, place foot outside left thigh.",
          "Left arm hugs right knee, right hand behind hips.",
          "Inhale, lengthen spine, exhale, twist to right.",
          "Repeat on other side."
        ],
        image: "seated-spinal-twist.png"
      },
      {
        name: "Revolved Triangle Pose",
        sanskritName: "Parivrtta Trikonasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Strengthens and stretches legs, hips, and spine. Improves balance and digestion.",
        instructions: [
          "Stand with feet wide apart, turn right foot out, left foot in.",
          "Square hips to front, reach left hand to right foot, right arm up.",
          "Twist torso to right, gaze up.",
          "Repeat on other side."
        ],
        image: "revolved-triangle-pose.png"
      }
    ]
  },
  {
    name: "Inversions",
    poses: [
      {
        name: "Shoulder Stand",
        sanskritName: "Sarvangasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stimulates thyroid, calms mind, strengthens shoulders and core.",
        instructions: [
          "Lie on back, lift legs overhead, support lower back with hands.",
          "Stack hips over shoulders, legs straight up.",
          "Keep neck relaxed, gaze upward.",
          "Breathe steadily."
        ],
        image: "shoulder-stand.png"
      },
      {
        name: "Plow Pose",
        sanskritName: "Halasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches shoulders and spine, calms nervous system, improves flexibility.",
        instructions: [
          "From Shoulder Stand, lower legs overhead to floor.",
          "Keep hands on back or extend arms on floor.",
          "Relax neck and face, breathe deeply."
        ],
        image: "plow-pose.png"
      },
      {
        name: "Headstand",
        sanskritName: "Sirsasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Builds strength in shoulders, arms, and core. Improves balance and focus.",
        instructions: [
          "Kneel, interlace fingers, place forearms on mat.",
          "Crown of head on mat, lift hips, walk feet in.",
          "Lift legs overhead, stack hips over shoulders.",
          "Hold and breathe."
        ],
        image: "headstand.png"
      },
      {
        name: "Legs-Up-the-Wall Pose",
        sanskritName: "Viparita Karani",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Relieves tired legs, calms nervous system, improves circulation.",
        instructions: [
          "Sit next to wall, lie back, swing legs up wall.",
          "Arms by sides, palms up.",
          "Relax and breathe deeply."
        ],
        image: "legs-up-the-wall.png"
      }
    ]
  },
  {
    name: "Restorative/Finishing",
    poses: [
      {
        name: "Corpse Pose",
        sanskritName: "Savasana",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Allows complete relaxation, integrates practice, reduces stress and fatigue.",
        instructions: [
          "Lie on back, legs extended, arms by sides, palms up.",
          "Close eyes, relax entire body.",
          "Let breath become natural and effortless.",
          "Remain still and present."
        ],
        image: "corpse-pose.png"
      },
      {
        name: "Reclined Twist",
        sanskritName: "Supta Matsyendrasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Releases tension in spine, massages abdominal organs, calms mind.",
        instructions: [
          "Lie on back, hug knees to chest.",
          "Drop knees to one side, extend arms out.",
          "Gaze opposite direction, relax shoulders.",
          "Repeat on other side."
        ],
        image: "reclined-twist.png"
      },
      {
        name: "Happy Baby Pose",
        sanskritName: "Ananda Balasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Gently opens hips, stretches inner thighs and back, calms the mind.",
        instructions: [
          "Lie on back, bend knees, grab outside edges of feet.",
          "Draw knees toward armpits, ankles over knees.",
          "Gently rock side to side."
        ],
        image: "happy-baby-pose.png"
      }
    ]
  },
  // --- New Categories and Poses Added Below ---
  {
    name: "Arm Balance",
    poses: [
      {
        name: "Crow Pose",
        sanskritName: "Bakasana",
        duration: "30 seconds",
        durationInSeconds: 30,
        benefits: "Strengthens arms, wrists, and core. Improves balance and concentration.",
        instructions: [
          "Start in a squat with feet hip-width apart.",
          "Place hands on the mat, shoulder-width apart, fingers spread.",
          "Bend elbows, lift hips, and place knees on upper arms.",
          "Shift weight forward, lift feet off the ground, and balance."
        ],
        image: "crow-pose.png"
      }
    ]
  },
  {
    name: "Binding Poses",
    poses: [
      {
        name: "Bound Side Angle Pose",
        sanskritName: "Baddha Parsvakonasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Opens shoulders and chest, stretches legs, improves balance.",
        instructions: [
          "From side angle, thread bottom arm under thigh and top arm behind back.",
          "Clasp hands or use a strap.",
          "Open chest and gaze upward."
        ],
        image: "bound-side-angle-pose.png"
      }
    ]
  },
  {
    name: "Chest-Opening",
    poses: [
      {
        name: "Fish Pose",
        sanskritName: "Matsyasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Opens chest and throat, strengthens upper back and neck.",
        instructions: [
          "Lie on back, legs extended, arms by sides.",
          "Slide hands under hips, press elbows into mat.",
          "Lift chest and head, arching back, crown of head to mat."
        ],
        image: "fish-pose.png"
      }
    ]
  },
  {
    name: "Core",
    poses: [
      {
        name: "Boat Pose",
        sanskritName: "Navasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Strengthens core, hip flexors, and spine.",
        instructions: [
          "Sit with knees bent, feet on floor.",
          "Lean back slightly, lift feet, and balance on sit bones.",
          "Extend arms forward, straighten legs if possible."
        ],
        image: "boat-pose.png"
      }
    ]
  },
  {
    name: "Forward Fold",
    poses: [
      {
        name: "Pyramid Pose",
        sanskritName: "Parsvottanasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hamstrings, hips, and spine. Improves balance.",
        instructions: [
          "Stand with feet about 3 feet apart, right foot forward.",
          "Square hips, fold forward over front leg.",
          "Hands on floor, blocks, or shins."
        ],
        image: "pyramid-pose.png"
      }
    ]
  },
  {
    name: "Hamstring Stretch",
    poses: [
      {
        name: "Half Splits",
        sanskritName: "Ardha Hanumanasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hamstrings and calves, improves flexibility.",
        instructions: [
          "From kneeling lunge, shift hips back, straighten front leg.",
          "Flex front foot, fold over extended leg.",
          "Keep spine long and breathe."
        ],
        image: "half-splits.png"
      },
      {
        name: "Supine Hamstring Stretch",
        sanskritName: "Supta Padangusthasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches hamstrings and calves, relieves lower back tension.",
        instructions: [
          "Lie on back, extend one leg up, hold big toe or use a strap.",
          "Keep other leg extended on mat.",
          "Gently draw leg toward you, keeping hips grounded."
        ],
        image: "supine-hamstring-stretch.png"
      }
    ]
  },
  {
    name: "Hip-Opening",
    poses: [
      {
        name: "Lizard Pose",
        sanskritName: "Utthan Pristhasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Opens hips, groins, and hamstrings. Strengthens legs.",
        instructions: [
          "From lunge, bring both hands inside front foot.",
          "Lower elbows to mat or blocks if possible.",
          "Keep back leg extended, hips sinking."
        ],
        image: "lizard-pose.png"
      }
    ]
  },
  {
    name: "Kneeling",
    poses: [
      {
        name: "Cat-Cow Pose",
        sanskritName: "Marjaryasana-Bitilasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Warms up spine, improves flexibility, relieves back tension.",
        instructions: [
          "Start on hands and knees, wrists under shoulders, knees under hips.",
          "Inhale, arch back (Cow), lift tailbone and head.",
          "Exhale, round spine (Cat), tuck chin and tailbone.",
          "Repeat, moving with breath."
        ],
        image: "cat-cow-pose.png"
      }
    ]
  },
  {
    name: "Mudra",
    poses: [
      {
        name: "Gyan Mudra",
        sanskritName: "Gyan Mudra",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Promotes calmness, improves concentration, enhances meditation.",
        instructions: [
          "Sit comfortably, touch tip of index finger to tip of thumb.",
          "Extend other fingers, rest hands on knees, palms up.",
          "Breathe naturally."
        ],
        image: "gyan-mudra.png"
      }
    ]
  },
  {
    name: "Pranayama",
    poses: [
      {
        name: "Alternate Nostril Breathing",
        sanskritName: "Nadi Shodhana",
        duration: "2 minutes",
        durationInSeconds: 120,
        benefits: "Balances energy, calms mind, reduces stress.",
        instructions: [
          "Sit comfortably, spine tall.",
          "Close right nostril with thumb, inhale left.",
          "Close left nostril, exhale right. Inhale right, exhale left. Repeat."
        ],
        image: "alternate-nostril-breathing.png"
      }
    ]
  },
  {
    name: "Prone",
    poses: [
      {
        name: "Locust Pose",
        sanskritName: "Salabhasana",
        duration: "45 seconds",
        durationInSeconds: 45,
        benefits: "Strengthens back, glutes, and legs. Improves posture.",
        instructions: [
          "Lie on belly, arms by sides, palms down.",
          "Inhale, lift chest, arms, and legs off floor.",
          "Gaze forward, keep neck long."
        ],
        image: "locust-pose.png"
      }
    ]
  },
  {
    name: "Shoulder-Opening",
    poses: [
      {
        name: "Thread the Needle Pose",
        sanskritName: "Parsva Balasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches shoulders, upper back, and relieves tension.",
        instructions: [
          "Start on hands and knees.",
          "Slide right arm under left, rest right shoulder and ear on mat.",
          "Hold, then switch sides."
        ],
        image: "thread-the-needle-pose.png"
      }
    ]
  },
  {
    name: "Side-Bending",
    poses: [
      {
        name: "Gate Pose",
        sanskritName: "Parighasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Stretches sides of body, opens chest and shoulders.",
        instructions: [
          "Kneel, extend right leg to side, foot flat.",
          "Inhale, lift left arm overhead, exhale, lean right.",
          "Hold, then switch sides."
        ],
        image: "gate-pose.png"
      }
    ]
  },
  {
    name: "Supine",
    poses: [
      {
        name: "Supine Spinal Twist",
        sanskritName: "Supta Matsyendrasana",
        duration: "1 minute",
        durationInSeconds: 60,
        benefits: "Releases tension in spine, massages abdominal organs, calms mind.",
        instructions: [
          "Lie on back, hug knees to chest.",
          "Drop knees to one side, extend arms out.",
          "Gaze opposite direction, relax shoulders.",
          "Repeat on other side."
        ],
        image: "reclined-twist.png"
      }
    ]
  }
];

export async function fetchUserPoses(userId: string): Promise<UserPose[]> {
  const { data, error } = await supabase
    .from('user_poses')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) {
    console.error('Error fetching user poses:', error);
    return [];
  }
  return (data || []).map((pose: any) => ({
    name: pose.name,
    sanskritName: pose.sanskrit_name,
    duration: pose.duration,
    durationInSeconds: pose.duration_in_seconds,
    benefits: pose.benefits,
    instructions: pose.instructions,
    intentRelation: pose.intent_relation,
    audioUrl: pose.audio_url,
    image: pose.image,
    id: pose.id,
    createdAt: pose.created_at,
  }));
}

export async function addUserPose(userId: string, pose: Omit<YogaPose, 'id' | 'createdAt'>): Promise<boolean> {
  const { error } = await supabase.from('user_poses').insert({
    user_id: userId,
    name: pose.name,
    sanskrit_name: pose.sanskritName,
    duration: pose.duration,
    duration_in_seconds: pose.durationInSeconds,
    benefits: pose.benefits,
    instructions: pose.instructions,
    intent_relation: pose.intentRelation,
    audio_url: pose.audioUrl,
    image: pose.image,
  });
  if (error) {
    console.error('Error adding user pose:', error);
    return false;
  }
  return true;
}

export async function deleteUserPose(userId: string, poseId: string): Promise<boolean> {
  const { error } = await supabase
    .from('user_poses')
    .delete()
    .eq('user_id', userId)
    .eq('id', poseId);
  if (error) {
    console.error('Error deleting user pose:', error);
    return false;
  }
  return true;
}