export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          email: string
          full_name: string | null
          avatar_url: string | null
          gender: string | null
          birth_date: string | null
          location: string | null
          experience_level: string | null
          preferred_practice_time: string | null
          goals: string[] | null
          bio: string | null
          website: string | null
          social_links: Json | null
          preferences: Json | null
        }
        Insert: {
          id: string
          created_at?: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          gender?: string | null
          birth_date?: string | null
          location?: string | null
          experience_level?: string | null
          preferred_practice_time?: string | null
          goals?: string[] | null
          bio?: string | null
          website?: string | null
          social_links?: Json | null
          preferences?: Json | null
        }
        Update: {
          id?: string
          created_at?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          gender?: string | null
          birth_date?: string | null
          location?: string | null
          experience_level?: string | null
          preferred_practice_time?: string | null
          goals?: string[] | null
          bio?: string | null
          website?: string | null
          social_links?: Json | null
          preferences?: Json | null
        }
      }
      journal_entries: {
        Row: {
          id: string
          created_at: string
          title: string
          content: string
          user_id: string
          mood: string | null
          tags: string[] | null
        }
        Insert: {
          id?: string
          created_at?: string
          title: string
          content: string
          user_id: string
          mood?: string | null
          tags?: string[] | null
        }
        Update: {
          id?: string
          created_at?: string
          title?: string
          content?: string
          user_id?: string
          mood?: string | null
          tags?: string[] | null
        }
      }
      yoga_sessions: {
        Row: {
          id: string
          created_at: string
          title: string
          duration: number
          level: string
          intent: string
          user_id: string
          sequence: Json
          completed: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          title: string
          duration: number
          level: string
          intent: string
          user_id: string
          sequence: Json
          completed?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          title?: string
          duration?: number
          level?: string
          intent?: string
          user_id?: string
          sequence?: Json
          completed?: boolean
        }
      }
      user_settings: {
        Row: {
          user_id: string
          api_key: string | null
          api_provider: string | null
          monthly_usage: number
          last_reset: string
          subscription_id: string | null
          subscription_status: string | null
          current_period_end: string | null
          founding_member: boolean
          founding_member_date: string | null
          free_yoga_used: boolean
        }
        Insert: {
          user_id: string
          api_key?: string | null
          api_provider?: string | null
          monthly_usage?: number
          last_reset?: string
          subscription_id?: string | null
          subscription_status?: string | null
          current_period_end?: string | null
          founding_member?: boolean
          founding_member_date?: string | null
          free_yoga_used?: boolean
        }
        Update: {
          user_id?: string
          api_key?: string | null
          api_provider?: string | null
          monthly_usage?: number
          last_reset?: string
          subscription_id?: string | null
          subscription_status?: string | null
          current_period_end?: string | null
          founding_member?: boolean
          founding_member_date?: string | null
          free_yoga_used?: boolean
        }
      },
      user_poses: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          sanskrit_name: string;
          duration: string;
          duration_in_seconds: number;
          benefits: string;
          instructions: Json;
          intent_relation: string | null;
          audio_url: string | null;
          image: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          sanskrit_name: string;
          duration: string;
          duration_in_seconds: number;
          benefits: string;
          instructions: Json;
          intent_relation?: string | null;
          audio_url?: string | null;
          image?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          sanskrit_name?: string;
          duration?: string;
          duration_in_seconds?: number;
          benefits?: string;
          instructions?: Json;
          intent_relation?: string | null;
          audio_url?: string | null;
          image?: string | null;
          created_at?: string;
        };
      }
    }
  }
}