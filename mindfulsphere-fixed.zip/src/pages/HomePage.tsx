import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import PracticeGraph from '../components/PracticeGraph';
import { Flower2 as Lotus, Heart, Sparkles, TrendingUp, Calendar, Key, Check, AlertCircle, MessageCircle, Crown, Cpu, Info, BookOpen, ChevronLeft, ChevronRight, X as CloseIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { format, differenceInDays, getISOWeek, getYear, getMonth, getQuarter } from 'date-fns';
import { useSubscription } from '../hooks/useSubscription';
import { motion } from 'framer-motion';
// @ts-ignore
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend } from 'recharts';
// @ts-ignore
import cloud from 'd3-cloud';
import Modal from '../components/Modal';
import InnerMirrorTimeline from '../components/InnerMirrorTimeline';

interface DashboardStats {
  practiceCount: number;
  availableSequences: number;
  totalJournalEntries: number;
  currentStreak: number;
  lastActivity: Date | null;
}

// Add ErrorBoundary component at the top of the file
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }
  componentDidCatch(error: any, info: any) {
    // You can log error here
    // console.error(error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="max-w-2xl mx-auto text-center py-12">
          <h2 className="text-2xl font-bold mb-4 text-red-600">Something went wrong</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-4">An unexpected error occurred. Please try refreshing the page or clearing your browser data.</p>
          <pre className="bg-gray-100 dark:bg-gray-800 text-xs p-4 rounded text-left overflow-x-auto max-w-full">{String(this.state.error)}</pre>
        </div>
      );
    }
    return this.props.children;
  }
}

// Move these above App so they are always in scope
const FullscreenOverlay: React.FC<{ onClose: () => void; children: React.ReactNode }> = ({ onClose, children }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80">
    <button
      className="absolute top-6 right-8 text-white text-3xl p-2 rounded hover:bg-white/10 focus:outline-none"
      onClick={onClose}
      aria-label="Close"
    >
      <CloseIcon size={32} />
    </button>
    <div className="w-full max-w-5xl h-[80vh] bg-[#23124d] rounded-xl shadow-2xl flex items-center justify-center p-8 relative overflow-auto">
      {children}
    </div>
  </div>
);

// Screenshot Carousel Component
const ScreenshotCarousel: React.FC = () => {
  const screenshots = [
    { src: new URL('../assets/screenshots/aigenerator.jpg', import.meta.url).href, alt: 'AI Generator Interface' },
    { src: new URL('../assets/screenshots/aisequence.jpg', import.meta.url).href, alt: 'AI Sequence Example' },
    { src: new URL('../assets/screenshots/sequence.jpg', import.meta.url).href, alt: 'Yoga Sequence Builder' },
    { src: new URL('../assets/screenshots/knowledge.jpg', import.meta.url).href, alt: 'Knowledge Base' },
    { src: new URL('../assets/screenshots/sanctuary.jpg', import.meta.url).href, alt: 'Mindful Sanctuary' },
    { src: new URL('../assets/screenshots/journal.jpg', import.meta.url).href, alt: 'Journal Feature' }
  ];

  const [allLoaded, setAllLoaded] = React.useState(false);
  const [current, setCurrent] = React.useState(0);
  const timeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  // Preload all images
  React.useEffect(() => {
    let loaded = 0;
    screenshots.forEach(({ src }) => {
      const img = new window.Image();
      img.src = src;
      img.onload = () => {
        loaded++;
        if (loaded === screenshots.length) setAllLoaded(true);
      };
      img.onerror = () => {
        loaded++;
        if (loaded === screenshots.length) setAllLoaded(true);
      };
    });
  }, []);

  // Auto-advance every 4s
  React.useEffect(() => {
    if (!allLoaded) return;
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setCurrent((c) => (c + 1) % screenshots.length);
    }, 4000);
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [current, allLoaded, screenshots.length]);

  // Manual navigation
  const goTo = (idx: number) => {
    setCurrent(idx);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  };
  const prev = () => goTo((current - 1 + screenshots.length) % screenshots.length);
  const next = () => goTo((current + 1) % screenshots.length);

  return (
    <div className="relative w-full max-w-2xl mx-auto flex flex-col items-center justify-center aspect-[3/4] min-h-[400px] max-h-[700px]">
      <style>{`
        .fade-enter {
          opacity: 0;
        }
        .fade-enter-active {
          opacity: 1;
          transition: opacity 0.7s;
        }
        .fade-exit {
          opacity: 1;
        }
        .fade-exit-active {
          opacity: 0;
          transition: opacity 0.7s;
        }
      `}</style>
      {!allLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900 z-10 rounded-2xl">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500" />
        </div>
      )}
      {/* Image display */}
      <div className="relative w-full h-full flex items-center justify-center">
        {screenshots.map((s, idx) => (
          <img
            key={s.src}
            src={s.src}
            alt={s.alt}
            className={`absolute left-0 top-0 w-full h-full object-contain rounded-xl transition-opacity duration-700 ${idx === current ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
            style={{ maxHeight: 700, maxWidth: '100%' }}
            draggable={false}
          />
        ))}
        {/* Left arrow */}
        <button
          onClick={prev}
          aria-label="Previous"
          className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white rounded-full p-2 z-20 focus:outline-none"
          style={{ display: allLoaded ? undefined : 'none' }}
        >
          <svg width="28" height="28" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7"/></svg>
        </button>
        {/* Right arrow */}
        <button
          onClick={next}
          aria-label="Next"
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white rounded-full p-2 z-20 focus:outline-none"
          style={{ display: allLoaded ? undefined : 'none' }}
        >
          <svg width="28" height="28" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/></svg>
        </button>
      </div>
      {/* Dots */}
      <div className="flex space-x-2 mt-4 z-20">
        {screenshots.map((_, idx) => (
          <button
            key={idx}
            onClick={() => goTo(idx)}
            className={`w-3 h-3 rounded-full focus:outline-none transition-all duration-200 ${idx === current ? 'bg-indigo-400 scale-110' : 'bg-gray-400/50'}`}
            aria-label={`Go to screenshot ${idx + 1}`}
            style={{ display: allLoaded ? undefined : 'none' }}
          />
        ))}
      </div>
    </div>
  );
};

const AxisTickWithTooltip: React.FC<any> = (props) => {
  const { x, y, payload } = props;
  const label = payload.value;
  const maxLen = 10;
  const displayLabel = label.length > maxLen ? label.slice(0, maxLen) + '…' : label;
  return (
    <g transform={`translate(${x},${y})`}>
      <title>{label}</title>
      <text
        x={0}
        y={0}
        dy={16}
        textAnchor="end"
        fill="#fff"
        style={{ fontSize: 14, cursor: 'pointer' }}
        transform="rotate(-30)"
      >
        {displayLabel}
      </text>
    </g>
  );
};

function App() {
  // All hooks at the top, always called
  const { user, session } = useAuth();
  const { monthlyUsage, loading: subLoading, isSubscribed } = useSubscription();
  const [stats, setStats] = useState<DashboardStats>({
    practiceCount: 0,
    availableSequences: 0,
    totalJournalEntries: 0,
    currentStreak: 0,
    lastActivity: null
  });
  const [loading, setLoading] = useState(true);
  const [journalEntries, setJournalEntries] = useState<any[]>([]);
  const [moodData, setMoodData] = useState<any[]>([]);
  const [moodTimeline, setMoodTimeline] = useState<any[]>([]);
  const [tagData, setTagData] = useState<any[]>([]);
  const [tagCloudWords, setTagCloudWords] = useState<any[]>([]);
  const [analyticsLoading, setAnalyticsLoading] = useState(true);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [tagCloudSize, setTagCloudSize] = useState({ width: 400, height: 200 });
  const [tagCloudArr, setTagCloudArr] = useState<{ text: string, value: number }[]>([]);
  const [moodGranularity, setMoodGranularity] = useState<'day' | 'week' | 'month' | 'quarter' | 'halfyear' | 'year'>('day');
  const [tagPeriod, setTagPeriod] = useState<'all' | 'week' | 'month' | 'quarter' | 'halfyear' | 'year'>('all');
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [tagSearch, setTagSearch] = useState('');
  const [tagDropdownOpen, setTagDropdownOpen] = useState(false);
  const [expandedCombinedCard, setExpandedCombinedCard] = useState<string | null>(null);
  const [minRuleConfidence, setMinRuleConfidence] = useState(0.5);
  const [minRuleSupport, setMinRuleSupport] = useState(2);
  const [showRuleTable, setShowRuleTable] = useState(false);
  
  // Define mood colors
  const moodColors = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#ec4899', '#84cc16', '#06b6d4'];
  
  // Defensive moods
  const moods = React.useMemo(() => {
    const safeTimeline = Array.isArray(moodTimeline) ? moodTimeline : [];
    const uniqueMoods = new Set<string>();
    safeTimeline.forEach(({ mood }) => {
      if (mood) uniqueMoods.add(mood);
    });
    return Array.from(uniqueMoods);
  }, [moodTimeline]);
  
  // Defensive stackedMoodData
  const stackedMoodData = React.useMemo(() => {
    const safeTimeline = Array.isArray(moodTimeline) ? moodTimeline : [];
    if (!safeTimeline.length) return [];
    const dateMoodCounts: Record<string, Record<string, number>> = {};
    safeTimeline.forEach(({ date, mood }) => {
      if (!dateMoodCounts[date]) {
        dateMoodCounts[date] = {};
      }
      dateMoodCounts[date][mood] = (dateMoodCounts[date][mood] || 0) + 1;
    });
    return Object.entries(dateMoodCounts).map(([date, moodCounts]) => ({
      date,
      ...moodCounts
    }));
  }, [moodTimeline]);

  // Helper to get aggregation key
  const getGranularityKey = (dateStr: string, granularity: string) => {
    const date = new Date(dateStr);
    switch (granularity) {
      case 'day':
        return format(date, 'yyyy-MM-dd');
      case 'week':
        return `${getYear(date)}-W${getISOWeek(date)}`;
      case 'month':
        return format(date, 'yyyy-MM');
      case 'quarter':
        return `${getYear(date)}-Q${getQuarter(date)}`;
      case 'halfyear':
        return `${getYear(date)}-H${getMonth(date) < 6 ? 1 : 2}`;
      case 'year':
        return `${getYear(date)}`;
      default:
        return format(date, 'yyyy-MM-dd');
    }
  };

  // Defensive aggregatedMoodData
  const aggregatedMoodData = React.useMemo(() => {
    const safeTimeline = Array.isArray(moodTimeline) ? moodTimeline : [];
    if (!safeTimeline.length) return [];
    const grouped: Record<string, Record<string, number>> = {};
    safeTimeline.forEach(({ date, mood }) => {
      const key = getGranularityKey(date, moodGranularity);
      if (!grouped[key]) grouped[key] = {};
      grouped[key][mood] = (grouped[key][mood] || 0) + 1;
    });
    return Object.entries(grouped).map(([date, moodCounts]) => ({ date, ...moodCounts }));
  }, [moodTimeline, moodGranularity]);

  // Helper to check if a date is within the selected period
  const isInPeriod = (dateStr: string, period: string) => {
    const now = new Date();
    const date = new Date(dateStr);
    switch (period) {
      case 'week':
        return differenceInDays(now, date) < 7;
      case 'month':
        return differenceInDays(now, date) < 31;
      case 'quarter':
        return differenceInDays(now, date) < 93;
      case 'halfyear':
        return differenceInDays(now, date) < 186;
      case 'year':
        return differenceInDays(now, date) < 366;
      case 'all':
      default:
        return true;
    }
  };

  // Defensive topTagsForPeriod
  const topTagsForPeriod = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    if (!safeEntries.length) return [];
    const tagCounts: Record<string, number> = {};
    safeEntries.forEach((entry: any) => {
      if (entry.created_at && isInPeriod(entry.created_at, tagPeriod)) {
        if (entry.tags && Array.isArray(entry.tags)) {
          entry.tags.forEach((tag: string) => {
            tagCounts[tag] = (tagCounts[tag] || 0) + 1;
          });
        }
      }
    });
    return Object.entries(tagCounts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [journalEntries, tagPeriod]);

  // Defensive allTags
  const allTags = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    const tagSet = new Set<string>();
    safeEntries.forEach((entry: any) => {
      if (entry.tags && Array.isArray(entry.tags)) {
        entry.tags.forEach((tag: string) => tagSet.add(tag));
      }
    });
    return Array.from(tagSet);
  }, [journalEntries]);

  // Defensive allMoods
  const allMoods = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    const moodSet = new Set<string>();
    safeEntries.forEach((entry: any) => {
      if (entry.mood) moodSet.add(entry.mood);
    });
    return Array.from(moodSet);
  }, [journalEntries]);

  // Set default selectedTag and selectedMood when data loads
  useEffect(() => {
    if (!selectedTag && allTags.length > 0) setSelectedTag(allTags[0]);
    if (!selectedMood && allMoods.length > 0) setSelectedMood(allMoods[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allTags, allMoods]);

  // Defensive moodDistByTag
  const moodDistByTag = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    if (!selectedTag) return [];
    const moodCounts: Record<string, number> = {};
    safeEntries.forEach((entry: any) => {
      if (entry.tags && Array.isArray(entry.tags) && entry.tags.includes(selectedTag)) {
        if (entry.mood) moodCounts[entry.mood] = (moodCounts[entry.mood] || 0) + 1;
      }
    });
    return Object.entries(moodCounts)
      .map(([mood, count]) => ({ mood, count }))
      .sort((a, b) => b.count - a.count);
  }, [journalEntries, selectedTag]);

  // Defensive tagDistByMood
  const tagDistByMood = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    if (!selectedMood) return [];
    const tagCounts: Record<string, number> = {};
    safeEntries.forEach((entry: any) => {
      if (entry.mood === selectedMood && entry.tags && Array.isArray(entry.tags)) {
        entry.tags.forEach((tag: string) => {
          tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        });
      }
    });
    return Object.entries(tagCounts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);
  }, [journalEntries, selectedMood]);

  // Defensive filteredTags
  const filteredTags = React.useMemo(() => {
    const safeTags = Array.isArray(allTags) ? allTags : [];
    if (!tagSearch) return safeTags;
    return safeTags.filter(tag => tag.toLowerCase().includes(tagSearch.toLowerCase()));
  }, [allTags, tagSearch]);

  useEffect(() => {
    if (user) {
      fetchStats();
      fetchJournalAnalytics();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      if (!user) return;

      // Fetch yoga sessions count
      const { data: yogaSessions, error: yogaError } = await supabase
        .from('yoga_sessions')
        .select('id, created_at')
        .eq('user_id', user.id);

      // Fetch journal entries count
      const { data: journalEntries, error: journalError } = await supabase
        .from('journal_entries')
        .select('id, created_at')
        .eq('user_id', user.id);

      if (yogaError) throw yogaError;
      if (journalError) throw journalError;

      // Calculate stats
      const practiceCount = yogaSessions?.length || 0;
      const totalJournalEntries = journalEntries?.length || 0;

      // Calculate streak and last activity
      const allActivities = [
        ...(yogaSessions || []).map(s => new Date(s.created_at)),
        ...(journalEntries || []).map(e => new Date(e.created_at))
      ].sort((a, b) => b.getTime() - a.getTime());

      const lastActivity = allActivities.length > 0 ? allActivities[0] : null;
      const currentStreak = calculateStreak(allActivities);

      setStats({
        practiceCount,
        availableSequences: 100 - (practiceCount % 100),
        totalJournalEntries,
        currentStreak,
        lastActivity
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStreak = (activities: Date[]): number => {
    if (!activities.length) return 0;

    // Normalize all activity dates to YYYY-MM-DD and create a Set
    const activityDays = new Set(
      activities.map(date => {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        return d.toISOString().slice(0, 10);
      })
    );

    let streak = 0;
    let current = new Date();
    current.setHours(0, 0, 0, 0);
    const todayStr = current.toISOString().slice(0, 10);

    // If today is in the set, we'll add 1 at the end
    const hasToday = activityDays.has(todayStr);

    // Start from yesterday
    current.setDate(current.getDate() - 1);
    while (activityDays.has(current.toISOString().slice(0, 10))) {
        streak++;
      current.setDate(current.getDate() - 1);
    }

    if (hasToday) streak++;
    return streak;
  };

  // Defensive setJournalEntries in fetchJournalAnalytics
  const fetchJournalAnalytics = async () => {
    setAnalyticsLoading(true);
    try {
      if (!user) return;
      const { data, error } = await supabase
        .from('journal_entries')
        .select('id, created_at, mood, tags, content')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setJournalEntries(Array.isArray(data) ? data : []);
      // Mood frequency
      const moodCounts: Record<string, number> = {};
      const moodTimelineArr: { date: string, mood: string }[] = [];
      (Array.isArray(data) ? data : []).forEach((entry: any) => {
        if (entry.mood) {
          moodCounts[entry.mood] = (moodCounts[entry.mood] || 0) + 1;
          moodTimelineArr.push({ date: entry.created_at.slice(0, 10), mood: entry.mood });
        }
      });
      setMoodData(Object.entries(moodCounts).map(([mood, count]) => ({ mood, count })));
      setMoodTimeline(moodTimelineArr);
      // Tag frequency
      const tagCounts: Record<string, number> = {};
      (Array.isArray(data) ? data : []).forEach((entry: any) => {
        if (entry.tags && Array.isArray(entry.tags)) {
          entry.tags.forEach((tag: string) => {
            tagCounts[tag] = (tagCounts[tag] || 0) + 1;
          });
        }
      });
      const tagArr = Object.entries(tagCounts).map(([tag, count]) => ({ tag, count }));
      setTagData(tagArr.sort((a, b) => b.count - a.count).slice(0, 5));
      // Tag cloud data for layout
      setTagCloudArr(Object.entries(tagCounts).map(([text, value]) => ({ text, value })));
    } catch (e) {
      // ignore
    } finally {
      setAnalyticsLoading(false);
    }
  };

  // Recalculate tag cloud layout whenever tagCloudSize or tagCloudArr changes
  useEffect(() => {
    if (!tagCloudArr.length) return;
    const cloudLayout = cloud()
      .size([tagCloudSize.width, tagCloudSize.height])
      .words(tagCloudArr.map((d: any) => ({ text: d.text, size: 16 + d.value * 8 })))
      .padding(8)
      .rotate(() => 0)
      .spiral('rectangular')
      .font('sans-serif')
      .fontSize((d: any) => d.size)
      .on('end', (words: any[]) => {
        // Center words
        const offsetX = tagCloudSize.width / 2;
        const offsetY = tagCloudSize.height / 2;
        setTagCloudWords(words.map(d => ({ ...d, x: d.x + offsetX, y: d.y + offsetY })));
      });
    cloudLayout.start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tagCloudSize, tagCloudArr]);

  // When expanding/collapsing tag cloud, only update size
  useEffect(() => {
    if (expandedCard === 'tag-cloud') {
      setTagCloudSize({ width: 1200, height: 600 });
    } else {
      setTagCloudSize({ width: 400, height: 200 });
    }
  }, [expandedCard]);

  // Usage bar for AI tokens
  const monthlyQuota = 100000;
  const usagePercent = Math.min(100, Math.round((monthlyUsage / monthlyQuota) * 100));

  // Defensive topFriendlyRules
  const topFriendlyRules = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    if (!safeEntries.length) return [];

    const tagMoodCounts: Record<string, Record<string, number>> = {};
    safeEntries.forEach((entry: any) => {
      if (entry.tags && Array.isArray(entry.tags)) {
        entry.tags.forEach((tag: string) => {
          if (!tagMoodCounts[tag]) tagMoodCounts[tag] = {};
          if (entry.mood) {
            tagMoodCounts[tag][entry.mood] = (tagMoodCounts[tag][entry.mood] || 0) + 1;
          }
        });
      }
    });

    const rules: { tag: string; mood: string; confidence: number; support: number }[] = [];

    for (const tag in tagMoodCounts) {
      const tagCounts = tagMoodCounts[tag];
      const totalEntriesForTag = Object.values(tagCounts).reduce((sum, count) => sum + count, 0);

      for (const mood in tagCounts) {
        const moodCount = tagCounts[mood];
        const confidence = totalEntriesForTag > 0 ? moodCount / totalEntriesForTag : 0;
        rules.push({ tag, mood, confidence, support: moodCount });
      }
    }

    return rules
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5);
  }, [journalEntries]);

  // Defensive topFriendlyMoodTagRules
  const topFriendlyMoodTagRules = React.useMemo(() => {
    const safeEntries = Array.isArray(journalEntries) ? journalEntries : [];
    if (!safeEntries.length) return [];

    const moodTagCounts: Record<string, Record<string, number>> = {};
    safeEntries.forEach((entry: any) => {
      if (entry.mood) {
        if (!moodTagCounts[entry.mood]) moodTagCounts[entry.mood] = {};
        if (entry.tags && Array.isArray(entry.tags)) {
          entry.tags.forEach((tag: string) => {
            moodTagCounts[entry.mood][tag] = (moodTagCounts[entry.mood][tag] || 0) + 1;
          });
        }
      }
    });

    const rules: { mood: string; tag: string; confidence: number; support: number }[] = [];

    for (const mood in moodTagCounts) {
      const moodCounts = moodTagCounts[mood];
      const totalEntriesForMood = Object.values(moodCounts).reduce((sum, count) => sum + count, 0);

      for (const tag in moodCounts) {
        const tagCount = moodCounts[tag];
        const confidence = totalEntriesForMood > 0 ? tagCount / totalEntriesForMood : 0;
        rules.push({ mood, tag, confidence, support: tagCount });
      }
    }

    return rules
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5);
  }, [journalEntries]);

  // Defensive tagMoodRules
  const tagMoodRules = React.useMemo(() => {
    const rules: { tag: string; mood: string; confidence: number; support: number }[] = [];
    const tagMoodCounts = topFriendlyRules.reduce((acc, rule) => {
      if (!acc[rule.tag]) acc[rule.tag] = {};
      acc[rule.tag][rule.mood] = rule.confidence;
      return acc;
    }, {} as Record<string, Record<string, number>>);

    for (const tag in tagMoodCounts) {
      const moodCounts = tagMoodCounts[tag];
      const totalEntriesForTag = Object.values(moodCounts).reduce((sum, count) => sum + count, 0);

      for (const mood in moodCounts) {
        const confidence = totalEntriesForTag > 0 ? moodCounts[mood] / totalEntriesForTag : 0;
        rules.push({ tag, mood, confidence, support: moodCounts[mood] });
      }
    }

    return rules
      .sort((a, b) => b.confidence - a.confidence)
      .filter(rule => rule.confidence >= minRuleConfidence && rule.support >= minRuleSupport);
  }, [topFriendlyRules, minRuleConfidence, minRuleSupport]);

  // Defensive moodTagRules
  const moodTagRules = React.useMemo(() => {
    const rules: { mood: string; tag: string; confidence: number; support: number }[] = [];
    const moodTagCounts = topFriendlyMoodTagRules.reduce((acc, rule) => {
      if (!acc[rule.mood]) acc[rule.mood] = {};
      acc[rule.mood][rule.tag] = rule.confidence;
      return acc;
    }, {} as Record<string, Record<string, number>>);

    for (const mood in moodTagCounts) {
      const tagCounts = moodTagCounts[mood];
      const totalEntriesForMood = Object.values(tagCounts).reduce((sum, count) => sum + count, 0);

      for (const tag in tagCounts) {
        const confidence = totalEntriesForMood > 0 ? tagCounts[tag] / totalEntriesForMood : 0;
        rules.push({ mood, tag, confidence, support: tagCounts[tag] });
      }
    }

    return rules
      .sort((a, b) => b.confidence - a.confidence)
      .filter(rule => rule.confidence >= minRuleConfidence && rule.support >= minRuleSupport);
  }, [topFriendlyMoodTagRules, minRuleConfidence, minRuleSupport]);

  // After all hooks and helpers, check for user
  if (!user) {
    return (
      <ErrorBoundary>
        <div className="max-w-6xl mx-auto text-center space-y-8 py-12">
          {/* Hero Section */}
          <motion.div
            className="space-y-6 mb-16 mt-16"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <motion.h1
              className="text-5xl md:text-6xl font-bold tracking-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.7, ease: 'easeOut' }}
            >
              Your AI-Powered{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">Mindfulness</span>{' '}
              Companion
            </motion.h1>
            <motion.p
              className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.7, ease: 'easeOut' }}
            >
              Experience personalized yoga sequences that adapt to your mood, energy, and goals. 
              Track your journey with intelligent journaling and discover patterns in your mindfulness practice.
            </motion.p>
            {/* CTA buttons in hero section */}
            <motion.div
              className="flex flex-col sm:flex-row justify-center gap-6 mt-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.7, ease: 'easeOut' }}
            >
              <Link to="/register">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    variant="primary"
                    size="lg"
                    className="text-lg px-8 py-4 animate-homepageGlowPulse"
                    style={{ animation: 'homepageGlowPulse 1.2s infinite' }}
                  >
                    Start Your Journey
                  </Button>
                </motion.div>
              </Link>
              <Link to="/login">
                <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    variant="outline"
                    size="lg"
                    className="text-lg px-8 py-4 animate-homepageSoftPulse"
                    style={{ animation: 'homepageSoftPulse 2s infinite' }}
                  >
                    Sign In
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </motion.div>

          {/* Core Features Section */}
          <motion.section
            className="mb-20"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.2 } }
            }}
          >
            <motion.h2 
              className="text-3xl md:text-4xl font-bold mb-12"
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
              }}
            >
              Three Pillars of MindfulSphere
            </motion.h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* AI Yoga Generation */}
              <motion.div
                className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-2xl p-8 text-left shadow-xl border border-indigo-100 dark:border-indigo-800"
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { opacity: 1, y: 0 }
                }}
                whileHover={{ scale: 1.02, boxShadow: '0 20px 40px 0 rgba(99,102,241,0.15)' }}
              >
                <div className="bg-indigo-100 dark:bg-indigo-800 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                  <Lotus className="text-indigo-600 dark:text-indigo-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-indigo-900 dark:text-indigo-100">AI Yoga Sequences</h3>
                                 <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                   Get personalized yoga flows that adapt to your mood, energy level, and available time. 
                   From 10-minute stress relief to 60-minute power sessions, or create custom sessions for any intention.
                 </p>
                                  <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>AI-generated sequences tailored to your needs and wants</span>
                   </li>
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>Interactive timer with audiovisual guidance</span>
                   </li>
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>Customizable duration & difficulty levels</span>
                   </li>
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>Breathwork & meditation-only sessions</span>
                   </li>
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>Manual sequence builder for custom flows and yoga teachers</span>
                   </li>
                   <li className="flex items-start">
                     <Check className="text-indigo-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                     <span>Curated knowledge base</span>
                   </li>
                 </ul>
              </motion.div>

              {/* Intelligent Journaling */}
              <motion.div
                className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 rounded-2xl p-8 text-left shadow-xl border border-emerald-100 dark:border-emerald-800"
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { opacity: 1, y: 0 }
                }}
                whileHover={{ scale: 1.02, boxShadow: '0 20px 40px 0 rgba(16,185,129,0.15)' }}
              >
                <div className="bg-emerald-100 dark:bg-emerald-800 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                  <Heart className="text-emerald-600 dark:text-emerald-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-emerald-900 dark:text-emerald-100">Intelligent Journaling</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                  AI-powered journaling that understands your emotions, extracts insights, and helps you 
                  discover patterns in your mindfulness journey.
                </p>
                <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                  <li className="flex items-start">
                    <Check className="text-emerald-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>AI mood detection & automatic tagging</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-emerald-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Dream interpretation & emotional analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-emerald-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Rich markdown editor with auto-save</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-emerald-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Pre & post-practice reflections</span>
                  </li>
                </ul>
              </motion.div>

              {/* Pattern Discovery */}
              <motion.div
                className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-2xl p-8 text-left shadow-xl border border-purple-100 dark:border-purple-800"
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { opacity: 1, y: 0 }
                }}
                whileHover={{ scale: 1.02, boxShadow: '0 20px 40px 0 rgba(139,92,246,0.15)' }}
              >
                <div className="bg-purple-100 dark:bg-purple-800 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                  <TrendingUp className="text-purple-600 dark:text-purple-400" size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-purple-900 dark:text-purple-100">Pattern Discovery</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                  Uncover insights about your practice with interactive analytics, mood tracking, 
                  and AI-generated patterns that reveal your mindfulness journey.
                </p>
                <ul className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                  <li className="flex items-start">
                    <Check className="text-purple-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Interactive mood & tag analytics</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-purple-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>AI pattern recognition & insights</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-purple-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Practice streak tracking</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-purple-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                    <span>Visual journey mapping</span>
                  </li>
                </ul>
              </motion.div>
            </div>
          </motion.section>

          {/* Unique Value Propositions */}
          <motion.section
            className="mb-20"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.15 } }
            }}
          >
            <motion.h2 
              className="text-3xl md:text-4xl font-bold mb-12"
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
              }}
            >
              What Makes MindfulSphere Unique
            </motion.h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <motion.div
                className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-2xl p-8 border border-amber-100 dark:border-amber-800"
                variants={{
                  hidden: { opacity: 0, x: -30 },
                  visible: { opacity: 1, x: 0 }
                }}
              >
                <div className="flex items-center mb-4">
                  <div className="bg-amber-100 dark:bg-amber-800 w-12 h-12 rounded-xl flex items-center justify-center mr-4">
                    <Cpu className="text-amber-600 dark:text-amber-400" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-amber-900 dark:text-amber-100">Complete Yoga Freedom</h3>
                </div>
                                 <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                   Get personalized yoga sequences that consider your mood, journal entries, imagination and preferences. 
                   No pre-made sequences—every flow is uniquely yours.
                 </p>
              </motion.div>

              <motion.div
                className="bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-900/20 dark:to-blue-900/20 rounded-2xl p-8 border border-cyan-100 dark:border-cyan-800"
                variants={{
                  hidden: { opacity: 0, x: 30 },
                  visible: { opacity: 1, x: 0 }
                }}
              >
                <div className="flex items-center mb-4">
                  <div className="bg-cyan-100 dark:bg-cyan-800 w-12 h-12 rounded-xl flex items-center justify-center mr-4">
                    <Sparkles className="text-cyan-600 dark:text-cyan-400" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-cyan-900 dark:text-cyan-100">AI-Powered Insights</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  Discover patterns you never knew existed. Our AI analyzes your journal entries to reveal 
                  connections between your mood, activities, and mindfulness practice.
                </p>
              </motion.div>

              <motion.div
                className="bg-gradient-to-r from-rose-50 to-pink-50 dark:from-rose-900/20 dark:to-pink-900/20 rounded-2xl p-8 border border-rose-100 dark:border-rose-800"
                variants={{
                  hidden: { opacity: 0, x: -30 },
                  visible: { opacity: 1, x: 0 }
                }}
              >
                <div className="flex items-center mb-4">
                  <div className="bg-rose-100 dark:bg-rose-800 w-12 h-12 rounded-xl flex items-center justify-center mr-4">
                    <MessageCircle className="text-rose-600 dark:text-rose-400" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-rose-900 dark:text-rose-100">Exclusive Community</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  Join our private Discord community of mindful practitioners. Share experiences, 
                  get support, and connect with like-minded individuals on their wellness journey.
                </p>
              </motion.div>

              <motion.div
                className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-2xl p-8 border border-green-100 dark:border-green-800"
                variants={{
                  hidden: { opacity: 0, x: 30 },
                  visible: { opacity: 1, x: 0 }
                }}
              >
                <div className="flex items-center mb-4">
                  <div className="bg-green-100 dark:bg-green-800 w-12 h-12 rounded-xl flex items-center justify-center mr-4">
                    <Crown className="text-green-600 dark:text-green-400" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-green-900 dark:text-green-100">Premium Experience</h3>
                </div>
                                 <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                   Enjoy AI generation, audiovisual guidance, advanced analytics, and priority support. 
                   Everything you need for a complete mindfulness transformation.
                 </p>
              </motion.div>
            </div>
          </motion.section>

          {/* Social Proof / Testimonials Section */}
          <motion.section 
            className="py-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-12">What Our Community Says</h2>
            <TestimonialMarquee />
          </motion.section>

          {/* Demo Section */}
          <motion.section 
            className="py-16 border-t border-gray-200 dark:border-gray-800"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-8">See MindfulSphere in Action</h2>
            <div className="relative max-w-4xl mx-auto">
              <ScreenshotCarousel />
            </div>
            <p className="text-gray-600 dark:text-gray-300 mt-8 max-w-3xl mx-auto text-lg">
              Explore how MindfulSphere creates personalized yoga sequences and helps you discover patterns in your mindfulness journey.
            </p>
          </motion.section>

          {/* Final CTA Section */}
          <motion.section 
            className="py-16 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-3xl"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Practice?</h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
                Join practitioners who've discovered the power of AI-powered mindfulness.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-6">
                <Link to="/register">
                                     <Button variant="primary" size="lg" className="text-lg px-8 py-4">
                     Start Your Journey
                   </Button>
                </Link>
                <Link to="/login">
                  <Button variant="outline" size="lg" className="text-lg px-8 py-4">
                    Sign In
                  </Button>
                </Link>
              </div>
                             <p className="text-lg font-semibold text-indigo-700 dark:text-indigo-300 mt-6">
                 Start your mindfulness journey today
               </p>
            </div>
          </motion.section>

          {/* Blog Section - At the very bottom */}
          <motion.section 
            className="py-16 border-t border-gray-200 dark:border-gray-800"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest Wisdom & Insights</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Discover expert insights on yoga, mindfulness, and personal growth from our curated blog.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Featured Blog Post */}
              <Card className="group hover:shadow-xl transition-all duration-300 border-2 border-primary-100 dark:border-primary-900/40">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="px-3 py-1 bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-200 text-sm font-medium rounded-full">
                      Featured
                    </span>
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-sm font-medium rounded-full">
                      AI
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                    How AI is Revolutionizing Your Yoga Practice
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                    Discover how artificial intelligence is transforming the way we approach yoga, from personalized sequences to real-time pose correction.
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                      <Calendar size={14} />
                      Jul 15, 2025
                    </div>
                    <Link
                      to="/blog/ai-revolutionizing-yoga-practice"
                      className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium transition-colors"
                    >
                      Read More →
                    </Link>
                  </div>
                </CardContent>
              </Card>

              {/* Second Blog Post */}
              <Card className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-sm font-medium rounded-full">
                      Journaling
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                    The Science Behind Mindful Journaling
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                    Learn about the psychological benefits of journaling and how it can improve your mental health and emotional well-being.
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                      <Calendar size={14} />
                      Jul 10, 2025
                    </div>
                    <Link
                      to="/blog/science-behind-mindful-journaling"
                      className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium transition-colors"
                    >
                      Read More →
                    </Link>
                  </div>
                </CardContent>
              </Card>

              {/* Third Blog Post */}
              <Card className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-sm font-medium rounded-full">
                      Wellness
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                    Digital Detox: Finding Balance in a Connected World
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                    Explore strategies for maintaining mindfulness and presence in our increasingly digital world.
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                      <Calendar size={14} />
                      Jul 5, 2025
                    </div>
                    <Link
                      to="/blog/digital-detox-finding-balance"
                      className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium transition-colors"
                    >
                      Read More →
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-8">
              <Link to="/blog">
                <Button variant="outline" size="lg" className="text-lg px-8 py-4">
                  Explore All Articles
                </Button>
              </Link>
            </div>
          </motion.section>
        </div>
      </ErrorBoundary>
    );
  }
  // Authenticated homepage
  return (
    <ErrorBoundary>
      <div className="space-y-8">
        <section className="text-center space-y-4 mb-12 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold">
            Welcome to <span className="text-indigo-600 dark:text-indigo-400">MindfulSphere</span>
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Your personal space for mindful yoga practice and reflective journaling.
          </p>
        </section>
        
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Yoga Sessions"
            value={stats.practiceCount.toString()}
            icon={<Lotus className="text-indigo-500 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />}
            description="Total yoga sessions"
          />
          <DashboardCard
            title="Journal Entries"
            value={stats.totalJournalEntries.toString()}
            icon={<Heart className="text-emerald-500 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />}
            description="Total journal entries"
          />
          <DashboardCard
            title="Current Streak"
            value={`${stats.currentStreak} days`}
            icon={<TrendingUp className="text-orange-500 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />}
            description="Keep up the momentum!"
          />
          <DashboardCard
            title="Last Activity"
            value={stats.lastActivity ? format(stats.lastActivity, 'MMM d') : 'No activity'}
            icon={<Calendar className="text-purple-500 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />}
            description="Your last practice"
          />
        </section>

        {/* Feature Cards (Yoga/Journal) */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <Card className="transform transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
            <CardContent className="flex flex-col items-center p-8 text-center space-y-4">
              <div className="bg-indigo-100 dark:bg-indigo-900/30 p-4 rounded-full">
                <Lotus size={40} className="text-indigo-600 dark:text-indigo-400 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />
              </div>
              <h2 className="text-2xl font-bold">Begin Your Yoga Practice</h2>
              <p className="text-gray-600 dark:text-gray-300">
                Generate personalized yoga sequences based on your preferences, goals, and available time.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center pb-8">
              <Link to="/yoga">
                <Button variant="primary" size="lg">
                  Start Yoga Session
                </Button>
              </Link>
            </CardFooter>
          </Card>
          <Card className="transform transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
            <CardContent className="flex flex-col items-center p-8 text-center space-y-4">
              <div className="bg-emerald-100 dark:bg-emerald-900/30 p-4 rounded-full">
                <Heart size={40} className="text-emerald-600 dark:text-emerald-400 animate-homepageIconGlow" style={{ animation: 'homepageIconGlow 2.2s infinite' }} />
              </div>
              <h2 className="text-2xl font-bold">Reflect in Your Journal</h2>
              <p className="text-gray-600 dark:text-gray-300">
                Document your thoughts, feelings, and experiences. Track your mindfulness journey over time.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center pb-8">
              <Link to="/journal">
                <Button variant="secondary" size="lg">
                  Write Journal Entry
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </section>

        {/* Discord Community Banner */}
        <section className="max-w-3xl mx-auto my-12 text-center">
          <h2 className="text-3xl font-bold mb-2">Join Our Exclusive Discord Community</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-4">
            Connect with fellow MindfulSphere subscribers, share your journey, and get direct access to our team and special events!
          </p>
          {isSubscribed ? (
            <a
              href="https://discord.gg/4vZYdggDEQ"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold shadow hover:bg-indigo-700 transition"
            >
              Join our Discord community
            </a>
          ) : (
            <button
              className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold shadow hover:bg-indigo-700 transition"
              onClick={() => setShowPricingModal(true)}
            >
              Join our Discord community
            </button>
          )}
          <Modal open={showPricingModal} onClose={() => setShowPricingModal(false)} title="Subscribe to Access the Discord Community">
            <div className="p-6 text-center">
              <h3 className="text-2xl font-bold mb-4">Subscribe to Access the Discord Community</h3>
              <p className="mb-6">This feature is available to MindfulSphere subscribers. View our plans and unlock access to our exclusive community!</p>
              <a
                href="/pricing"
                className="inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg font-semibold shadow hover:bg-indigo-700 transition mb-2"
                onClick={() => setShowPricingModal(false)}
              >
                View Plans & Pricing
              </a>
              <div>
                <button
                  className="mt-2 text-gray-500 hover:underline"
                  onClick={() => setShowPricingModal(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </Modal>
        </section>

        {/* Inner Mirror Timeline block */}
        <InnerMirrorTimeline journalEntries={journalEntries} session={session} isSubscribed={isSubscribed} />
        {/* Add the Practice Graph section here */}
        <section className="mb-8">
          <PracticeGraph />
        </section>

        {/* Mood & Tag Analytics Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-center">Mood & Tag Analytics</h2>
          {analyticsLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mx-auto mb-2" />
              <span className="text-indigo-600 dark:text-indigo-300">Loading analytics...</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Mood Frequency Bar Chart */}
              <div onClick={() => setExpandedCard('mood-frequency')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Mood Frequency</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={moodData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                      <XAxis dataKey="mood" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#6366f1" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              </div>
              {/* Mood Over Time Stacked Bar Chart */}
              <div onClick={() => setExpandedCard('mood-over-time')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Mood Over Time</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={stackedMoodData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                      <XAxis dataKey="date" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Legend />
                      {moods.map((mood, idx) => (
                        <Bar key={mood} dataKey={mood} stackId="a" fill={moodColors[idx % moodColors.length]} />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              </div>
              {/* Tag Cloud */}
              <div onClick={() => setExpandedCard('tag-cloud')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Tag Cloud</h3>
                  <div className="flex flex-wrap items-center justify-center min-h-[200px]">
                      <svg width={tagCloudSize.width} height={tagCloudSize.height}>
                      {Array.isArray(tagCloudWords) && tagCloudWords.map((d: any, i: number) => (
                        <text
                          key={i}
                            x={d.x}
                            y={d.y}
                          fontSize={d.size}
                          fontFamily="sans-serif"
                            fill="#c7d2fe"
                            style={{ cursor: 'default', userSelect: 'none', opacity: 0.95, textShadow: '0 1px 4px #000' }}
                        >
                          {d.text}
                        </text>
                      ))}
                    </svg>
                  </div>
                </CardContent>
              </Card>
              </div>
              {/* Top 5 Tags Bar Chart */}
              <div onClick={() => setExpandedCard('top-tags')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Top 5 Tags</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={tagData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                        <XAxis dataKey="tag" tick={<AxisTickWithTooltip />} interval={0} />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              </div>
            </div>
          )}
        </section>

        {/* Fullscreen overlays for expanded analytic cards */}
        {expandedCard === 'mood-frequency' && (
          <FullscreenOverlay onClose={() => setExpandedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Mood Frequency</h3>
              <ResponsiveContainer width="90%" height={500}>
                <BarChart data={moodData} margin={{ top: 30, right: 40, left: 0, bottom: 30 }}>
                  <XAxis dataKey="mood" stroke="#fff" />
                  <YAxis allowDecimals={false} stroke="#fff" />
                  <Tooltip />
                  <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </FullscreenOverlay>
        )}
        {expandedCard === 'mood-over-time' && (
          <FullscreenOverlay onClose={() => setExpandedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Mood Over Time</h3>
              <div className="mb-4 flex items-center gap-2">
                <label htmlFor="granularity-select" className="text-white font-medium">Granularity:</label>
                <select
                  id="granularity-select"
                  value={moodGranularity}
                  onChange={e => setMoodGranularity(e.target.value as any)}
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none"
                >
                  <option value="day">Day</option>
                  <option value="week">Week</option>
                  <option value="month">Month</option>
                  <option value="quarter">Quarter</option>
                  <option value="halfyear">Half-Year</option>
                  <option value="year">Year</option>
                </select>
              </div>
              <ResponsiveContainer width="90%" height={500}>
                <BarChart data={aggregatedMoodData} margin={{ top: 30, right: 40, left: 0, bottom: 30 }}>
                  <XAxis dataKey="date" stroke="#fff" />
                  <YAxis allowDecimals={false} stroke="#fff" />
                  <Tooltip />
                  <Legend />
                  {moods.map((mood, idx) => (
                    <Bar key={mood} dataKey={mood} stackId="a" fill={moodColors[idx % moodColors.length]} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </div>
          </FullscreenOverlay>
        )}
        {expandedCard === 'tag-cloud' && (
          <FullscreenOverlay onClose={() => setExpandedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Tag Cloud</h3>
              <div className="flex flex-wrap items-center justify-center min-h-[600px]">
                <svg width={tagCloudSize.width} height={tagCloudSize.height}>
                  {Array.isArray(tagCloudWords) && tagCloudWords.map((d: any, i: number) => (
                    <text
                      key={i}
                      x={d.x}
                      y={d.y}
                      fontSize={d.size}
                      fontFamily="sans-serif"
                      fill="#c7d2fe"
                      style={{ cursor: 'default', userSelect: 'none', opacity: 0.98, textShadow: '0 2px 8px #000' }}
                    >
                      {d.text}
                    </text>
                  ))}
                </svg>
              </div>
            </div>
          </FullscreenOverlay>
        )}
        {expandedCard === 'top-tags' && (
          <FullscreenOverlay onClose={() => setExpandedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Top 5 Tags</h3>
              <div className="mb-4 flex items-center gap-2">
                <label htmlFor="tag-period-select" className="text-white font-medium">Period:</label>
                <select
                  id="tag-period-select"
                  value={tagPeriod}
                  onChange={e => setTagPeriod(e.target.value as any)}
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none"
                >
                  <option value="all">All Time</option>
                  <option value="week">Past Week</option>
                  <option value="month">Past Month</option>
                  <option value="quarter">Past Quarter</option>
                  <option value="halfyear">Past Half-Year</option>
                  <option value="year">Past Year</option>
                </select>
              </div>
              <ResponsiveContainer width="90%" height={500}>
                <BarChart data={topTagsForPeriod} margin={{ top: 30, right: 40, left: 0, bottom: 30 }}>
                  <XAxis dataKey="tag" stroke="#fff" />
                  <YAxis allowDecimals={false} stroke="#fff" />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </FullscreenOverlay>
        )}

        {/* Add new section below combined analytics */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-center">Tag & Mood Combined Analytics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Mood Distribution by Tag */}
            <div onClick={() => setExpandedCombinedCard('mood-by-tag')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Mood Distribution by Tag</h3>
                  <div className="mb-2 flex items-center gap-2 relative" onClick={e => e.stopPropagation()}>
                    <label htmlFor="search-tag" className="font-medium">Tag:</label>
                    <input
                      id="search-tag"
                      type="text"
                      value={tagSearch}
                      onChange={e => {
                        setTagSearch(e.target.value);
                        setTagDropdownOpen(true);
                      }}
                      onFocus={() => setTagDropdownOpen(true)}
                      onBlur={() => setTimeout(() => setTagDropdownOpen(false), 150)}
                      placeholder="Search tags..."
                      className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none min-w-[180px]"
                    />
                    {tagDropdownOpen && filteredTags.length > 0 && (
                      <div className="absolute left-0 top-10 z-10 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded shadow-lg max-h-48 overflow-y-auto w-full min-w-[180px]">
                        {filteredTags.map(tag => (
                          <div
                            key={tag}
                            className={`px-3 py-2 cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900 ${tag === selectedTag ? 'bg-indigo-200 dark:bg-indigo-700' : ''}`}
                            onMouseDown={() => {
                              setSelectedTag(tag);
                              setTagSearch(tag);
                              setTagDropdownOpen(false);
                            }}
                          >
                            {tag}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  {moodDistByTag.length > 0 ? (
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={moodDistByTag} margin={{ top: 10, right: 20, left: 0, bottom: 40 }}>
                        <XAxis dataKey="mood" tick={<AxisTickWithTooltip />} interval={0} />
                        <YAxis allowDecimals={false} />
                        <Tooltip />
                        <Bar dataKey="count" fill="#6366f1" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center text-gray-400 py-8">No data for this tag.</div>
                  )}
                </CardContent>
              </Card>
            </div>
            {/* Tag Distribution by Mood */}
            <div onClick={() => setExpandedCombinedCard('tag-by-mood')} className="cursor-zoom-in">
              <Card>
                <CardContent>
                  <h3 className="font-semibold mb-2">Tag Distribution by Mood</h3>
                  <div className="mb-2 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    <label htmlFor="select-mood" className="font-medium">Mood:</label>
                    <select
                      id="select-mood"
                      value={selectedMood || ''}
                      onChange={e => setSelectedMood(e.target.value)}
                      className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none"
                    >
                      {allMoods.map(mood => (
                        <option key={mood} value={mood}>{mood}</option>
                      ))}
                    </select>
                  </div>
                  {tagDistByMood.length > 0 ? (
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={tagDistByMood} margin={{ top: 10, right: 20, left: 0, bottom: 40 }}>
                        <XAxis dataKey="tag" tick={<AxisTickWithTooltip />} interval={0} />
                        <YAxis allowDecimals={false} />
                        <Tooltip />
                        <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center text-gray-400 py-8">No data for this mood.</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
          </section>

        {/* Fullscreen overlays for expanded combined analytics */}
        {expandedCombinedCard === 'mood-by-tag' && (
          <FullscreenOverlay onClose={() => setExpandedCombinedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Mood Distribution by Tag</h3>
              <div className="mb-4 flex items-center gap-2 relative" onClick={e => e.stopPropagation()}>
                <label htmlFor="search-tag" className="font-medium">Tag:</label>
                <input
                  id="search-tag"
                  type="text"
                  value={tagSearch}
                  onChange={e => {
                    setTagSearch(e.target.value);
                    setTagDropdownOpen(true);
                  }}
                  onFocus={() => setTagDropdownOpen(true)}
                  onBlur={() => setTimeout(() => setTagDropdownOpen(false), 150)}
                  placeholder="Search tags..."
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none min-w-[180px]"
                />
                {tagDropdownOpen && filteredTags.length > 0 && (
                  <div className="absolute left-0 top-10 z-10 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded shadow-lg max-h-48 overflow-y-auto w-full min-w-[180px]">
                    {filteredTags.map(tag => (
                      <div
                        key={tag}
                        className={`px-3 py-2 cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900 ${tag === selectedTag ? 'bg-indigo-200 dark:bg-indigo-700' : ''}`}
                        onMouseDown={() => {
                          setSelectedTag(tag);
                          setTagSearch(tag);
                          setTagDropdownOpen(false);
                        }}
                      >
                        {tag}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              {moodDistByTag.length > 0 ? (
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart data={moodDistByTag} margin={{ top: 30, right: 40, left: 0, bottom: 60 }}>
                    <XAxis dataKey="mood" tick={<AxisTickWithTooltip />} interval={0} />
                    <YAxis allowDecimals={false} stroke="#fff" />
                    <Tooltip />
                    <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center text-gray-400 py-8">No data for this tag.</div>
              )}
            </div>
          </FullscreenOverlay>
        )}
        {expandedCombinedCard === 'tag-by-mood' && (
          <FullscreenOverlay onClose={() => setExpandedCombinedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Tag Distribution by Mood</h3>
              <div className="mb-4 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                <label htmlFor="select-mood" className="font-medium">Mood:</label>
                <select
                  id="select-mood"
                  value={selectedMood || ''}
                  onChange={e => setSelectedMood(e.target.value)}
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none"
                >
                  {allMoods.map(mood => (
                    <option key={mood} value={mood}>{mood}</option>
                  ))}
                </select>
              </div>
              {tagDistByMood.length > 0 ? (
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart data={tagDistByMood} margin={{ top: 30, right: 40, left: 0, bottom: 60 }}>
                    <XAxis dataKey="tag" tick={<AxisTickWithTooltip />} interval={0} />
                    <YAxis allowDecimals={false} stroke="#fff" />
                    <Tooltip />
                    <Bar dataKey="count" fill="#10b981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center text-gray-400 py-8">No data for this mood.</div>
              )}
            </div>
          </FullscreenOverlay>
        )}

        {/* Add new section below combined analytics */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-center">What We've Noticed About Your Practice</h2>
          <div className="flex flex-col md:flex-row gap-8 mb-4">
            {/* Tag→Mood */}
            <div className="flex-1 flex flex-col items-center gap-4 max-h-96 overflow-y-auto w-full">
              <h3 className="text-lg font-bold text-indigo-200 mb-2">When you write about a tag...</h3>
              {topFriendlyRules.length === 0 ? (
                <div className="text-center text-gray-400 py-6">We'll surface interesting patterns here as you add more entries!</div>
              ) : (
                topFriendlyRules.map((rule, i) => (
                  <div key={i} className="bg-indigo-900/80 rounded-lg shadow p-4 max-w-xl w-full flex items-center gap-3">
                    <span className="text-2xl">💡</span>
                    <span className="text-lg text-white">
                      {rule.confidence === 1
                        ? <>Entries tagged <b>{rule.tag}</b> are <b>always</b> associated with the mood <b>{rule.mood}</b>.</>
                        : <>When you write about <b>{rule.tag}</b>, you're most often feeling <b>{rule.mood}</b> ({Math.round(rule.confidence * 100)}% of the time).</>
                      }
                    </span>
                  </div>
                ))
              )}
            </div>
            {/* Mood→Tag */}
            <div className="flex-1 flex flex-col items-center gap-4 max-h-96 overflow-y-auto w-full">
              <h3 className="text-lg font-bold text-indigo-200 mb-2">When you feel a mood...</h3>
              {topFriendlyMoodTagRules.length === 0 ? (
                <div className="text-center text-gray-400 py-6">We'll surface interesting patterns here as you add more entries!</div>
              ) : (
                topFriendlyMoodTagRules.map((rule, i) => (
                  <div key={i} className="bg-indigo-900/80 rounded-lg shadow p-4 max-w-xl w-full flex items-center gap-3">
                    <span className="text-2xl">💡</span>
                    <span className="text-lg text-white">
                      {rule.confidence === 1
                        ? <>When you feel <b>{rule.mood}</b>, you <b>always</b> write about <b>{rule.tag}</b>.</>
                        : <>When you feel <b>{rule.mood}</b>, you most often write about <b>{rule.tag}</b> ({Math.round(rule.confidence * 100)}% of the time).</>
                      }
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
          {tagMoodRules.length > 0 && (
            <button
              className="mt-2 text-indigo-400 hover:underline text-sm"
              onClick={() => setShowRuleTable(v => !v)}
            >
              {showRuleTable ? 'Hide technical details' : 'Show technical details'}
            </button>
          )}
          {showRuleTable && (
            <div className="overflow-x-auto mt-4">
              <h4 className="text-indigo-200 font-bold mb-2">Tag→Mood Rules</h4>
              <table className="min-w-full text-left border border-gray-700 rounded-lg mb-6">
                <thead className="bg-gray-900 text-white">
                  <tr>
                    <th className="px-4 py-2">Tag</th>
                    <th className="px-4 py-2">Mood</th>
                    <th className="px-4 py-2">Confidence</th>
                    <th className="px-4 py-2">Support</th>
                  </tr>
                </thead>
                <tbody>
                  {tagMoodRules.length === 0 ? (
                    <tr><td colSpan={4} className="text-center text-gray-400 py-6">No rules found for current thresholds.</td></tr>
                  ) : (
                    tagMoodRules.map((rule, i) => (
                      <tr key={i} className="border-t border-gray-700">
                        <td className="px-4 py-2">{rule.tag}</td>
                        <td className="px-4 py-2">{rule.mood}</td>
                        <td className="px-4 py-2">{Math.round(rule.confidence * 100)}%</td>
                        <td className="px-4 py-2">{rule.support}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
              <h4 className="text-indigo-200 font-bold mb-2">Mood→Tag Rules</h4>
              <table className="min-w-full text-left border border-gray-700 rounded-lg">
                <thead className="bg-gray-900 text-white">
                  <tr>
                    <th className="px-4 py-2">Mood</th>
                    <th className="px-4 py-2">Tag</th>
                    <th className="px-4 py-2">Confidence</th>
                    <th className="px-4 py-2">Support</th>
                  </tr>
                </thead>
                <tbody>
                  {moodTagRules.length === 0 ? (
                    <tr><td colSpan={4} className="text-center text-gray-400 py-6">No rules found for current thresholds.</td></tr>
                  ) : (
                    moodTagRules.map((rule, i) => (
                      <tr key={i} className="border-t border-gray-700">
                        <td className="px-4 py-2">{rule.mood}</td>
                        <td className="px-4 py-2">{rule.tag}</td>
                        <td className="px-4 py-2">{Math.round(rule.confidence * 100)}%</td>
                        <td className="px-4 py-2">{rule.support}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Fullscreen overlays for expanded combined analytics */}
        {expandedCombinedCard === 'mood-by-tag' && (
          <FullscreenOverlay onClose={() => setExpandedCombinedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Mood Distribution by Tag</h3>
              <div className="mb-4 flex items-center gap-2 relative" onClick={e => e.stopPropagation()}>
                <label htmlFor="search-tag" className="font-medium">Tag:</label>
                <input
                  id="search-tag"
                  type="text"
                  value={tagSearch}
                  onChange={e => {
                    setTagSearch(e.target.value);
                    setTagDropdownOpen(true);
                  }}
                  onFocus={() => setTagDropdownOpen(true)}
                  onBlur={() => setTimeout(() => setTagDropdownOpen(false), 150)}
                  placeholder="Search tags..."
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none min-w-[180px]"
                />
                {tagDropdownOpen && filteredTags.length > 0 && (
                  <div className="absolute left-0 top-10 z-10 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded shadow-lg max-h-48 overflow-y-auto w-full min-w-[180px]">
                    {filteredTags.map(tag => (
                      <div
                        key={tag}
                        className={`px-3 py-2 cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900 ${tag === selectedTag ? 'bg-indigo-200 dark:bg-indigo-700' : ''}`}
                        onMouseDown={() => {
                          setSelectedTag(tag);
                          setTagSearch(tag);
                          setTagDropdownOpen(false);
                        }}
                      >
                        {tag}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              {moodDistByTag.length > 0 ? (
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart data={moodDistByTag} margin={{ top: 30, right: 40, left: 0, bottom: 60 }}>
                    <XAxis dataKey="mood" tick={<AxisTickWithTooltip />} interval={0} />
                    <YAxis allowDecimals={false} stroke="#fff" />
                    <Tooltip />
                    <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center text-gray-400 py-8">No data for this tag.</div>
              )}
            </div>
          </FullscreenOverlay>
        )}
        {expandedCombinedCard === 'tag-by-mood' && (
          <FullscreenOverlay onClose={() => setExpandedCombinedCard(null)}>
            <div className="w-full h-full flex flex-col items-center justify-center">
              <h3 className="font-semibold mb-4 text-2xl text-white">Tag Distribution by Mood</h3>
              <div className="mb-4 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                <label htmlFor="select-mood" className="font-medium">Mood:</label>
                <select
                  id="select-mood"
                  value={selectedMood || ''}
                  onChange={e => setSelectedMood(e.target.value)}
                  className="rounded px-2 py-1 text-base bg-gray-800 text-white border border-gray-600 focus:outline-none"
                >
                  {allMoods.map(mood => (
                    <option key={mood} value={mood}>{mood}</option>
                  ))}
                </select>
              </div>
              {tagDistByMood.length > 0 ? (
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart data={tagDistByMood} margin={{ top: 30, right: 40, left: 0, bottom: 60 }}>
                    <XAxis dataKey="tag" tick={<AxisTickWithTooltip />} interval={0} />
                    <YAxis allowDecimals={false} stroke="#fff" />
                    <Tooltip />
                    <Bar dataKey="count" fill="#10b981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center text-gray-400 py-8">No data for this mood.</div>
              )}
            </div>
          </FullscreenOverlay>
        )}
      </div>
    </ErrorBoundary>
  );
}

const DashboardCard: React.FC<{
  title: string;
  value: string;
  icon: React.ReactNode;
  description: string;
}> = ({ title, value, icon, description }) => {
  return (
    <Card className="transform transition-all duration-300 hover:shadow-md hover:-translate-y-1">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
            <p className="mt-2 text-3xl font-bold">{value}</p>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{description}</p>
          </div>
          <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-full">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
};

// TestimonialCarousel component
const testimonials = [
  {
    quote: 'I love how easy it is to track my progress!',
    author: 'MindfulSphere User',
    color: 'indigo',
  },
  {
    quote: 'The AI yoga flows are so personalized and motivating.',
    author: 'Community Feedback',
    color: 'emerald',
  },
  {
    quote: 'Journaling here has helped me reflect and grow.',
    author: 'MindfulSphere Member',
    color: 'purple',
  },
  {
    quote: 'The personalized sequences keep me coming back every day!',
    author: 'Happy Practitioner',
    color: 'indigo',
  },
  {
    quote: 'This platform makes mindfulness so accessible and fun.',
    author: 'Yoga Enthusiast',
    color: 'emerald',
  },
  {
    quote: 'I feel more balanced and focused since joining MindfulSphere.',
    author: 'Grateful Member',
    color: 'purple',
  },
  {
    quote: 'The journal prompts are thoughtful and inspiring.',
    author: 'Reflective User',
    color: 'indigo',
  },
  {
    quote: 'A wonderful community and excellent support!',
    author: 'Community Member',
    color: 'emerald',
  },
];

// Add marquee animation CSS (in a <style> tag for now)
const testimonialMarqueeStyle = `
@keyframes testimonial-marquee {
  0% { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}

@keyframes carousel-scroll {
  0% { transform: translateX(0); }
  100% { transform: translateX(-${100 / 4}%); }
}

@keyframes dot-pulse {
  0%, 100% { opacity: 0.5; }
  50% { opacity: 1; }
}`;

const TestimonialMarquee: React.FC = () => {
  // Duplicate testimonials for seamless looping
  const marqueeTestimonials = [...testimonials, ...testimonials];
  return (
    <div className="relative overflow-hidden w-full py-6">
      <style>{testimonialMarqueeStyle}</style>
      <div
        className="flex items-center gap-12"
        style={{
          width: 'max-content',
          animation: 'testimonial-marquee 30s linear infinite',
        }}
      >
        {marqueeTestimonials.map((t, i) => {
          const colorClass = t.color === 'indigo' ? 'text-indigo-500' : t.color === 'emerald' ? 'text-emerald-500' : 'text-purple-500';
          return (
            <div
              key={i}
              className="rounded-xl p-6 flex flex-col items-center min-w-[280px] max-w-[400px]"
            >
              <MessageCircle className={`${colorClass} mb-4`} size={32} />
              <p className="italic text-lg mb-2 text-center">"{t.quote}"</p>
              <span className="text-gray-500 text-sm">— {t.author}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Add a prominent link to the teacher directory at the bottom of the landing page
const TeacherDirectoryLink: React.FC = () => (
  <div className="w-full flex justify-center mt-12 mb-8">
    <Link
      to="/teachers"
      className="inline-block px-8 py-4 bg-indigo-600 text-white text-lg font-bold rounded-2xl shadow-lg hover:bg-indigo-700 transition-all border-4 border-indigo-300 dark:border-indigo-700 dark:bg-indigo-800 dark:hover:bg-indigo-900"
    >
      🧘‍♂️ Find a Yoga Teacher: View the MindfulSphere Teacher Directory
    </Link>
  </div>
);

// Render the teacher directory link at the bottom of the landing page
// (Call this just before export default App)

function HomePageWithDirectoryLink() {
  return (
    <>
      <App />
      <TeacherDirectoryLink />
    </>
  );
}

export default HomePageWithDirectoryLink;