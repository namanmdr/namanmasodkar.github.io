import React from 'react';

const PrivacyPolicyPage = () => (
  <div className="max-w-3xl mx-auto py-12 px-4">
    <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
    <p>
      <strong>Effective Date:</strong> July 2025
    </p>
    <p className="mt-4">
      MindfulSphere (“we”, “us”, or “our”) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our website and services.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Information We Collect</h2>
    <ul className="list-disc ml-6">
      <li>Personal Information: Name, email address, and any information you provide when registering or contacting us.</li>
      <li>Usage Data: Information about how you use our site, including IP address, browser type, and device information.</li>
      <li>Cookies: We use cookies to enhance your experience. You can disable cookies in your browser settings.</li>
    </ul>
    <h2 className="text-xl font-semibold mt-6 mb-2">How We Use Your Information</h2>
    <ul className="list-disc ml-6">
      <li>To provide and maintain our services</li>
      <li>To communicate with you</li>
      <li>To improve our website and services</li>
      <li>To comply with legal obligations</li>
    </ul>
    <h2 className="text-xl font-semibold mt-6 mb-2">Sharing Your Information</h2>
    <p>
      We do not sell your personal information. We may share information with trusted third parties who assist us in operating our website, conducting our business, or serving our users, so long as those parties agree to keep this information confidential. We may also release information when required by law.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Your Rights</h2>
    <ul className="list-disc ml-6">
      <li>You may request access to, correction of, or deletion of your personal data.</li>
      <li>EU/EEA residents have additional rights under the GDPR.</li>
      <li>California residents have additional rights under the CCPA.</li>
    </ul>
    <h2 className="text-xl font-semibold mt-6 mb-2">Contact Us</h2>
    <p>
      If you have any questions about this Privacy Policy, please contact us at <a href="mailto:contact@mindful-sphere.com" className="text-indigo-600 underline">contact@mindful-sphere.com</a>.
    </p>
  </div>
);

export default PrivacyPolicyPage; 