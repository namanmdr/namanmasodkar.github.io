import { fnUrl } from '../lib/functions';
import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import Select from '../components/Select';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Save, Tag, X } from 'lucide-react';
import { generateJournalTitleWithAIProxy } from '../lib/ai';
import { isUserSubscribed } from '../lib/supabase';
import { reportStripeUsage } from '../lib/stripe';
import Modal from '../components/Modal';
import { useSubscription } from '../hooks/useSubscription';
import { generateJournalMoodWithAIProxy, generateJournalTagsWithAIProxy } from '../lib/ai';
import { generateReflectionPromptWithAIProxy } from '../lib/ai';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { MentionsInput, Mention } from 'react-mentions';

interface JournalEntry {
  id: string;
  created_at: string;
  title: string;
  content: string;
  user_id: string;
  mood: string | null;
  tags: string[] | null;
}

// Add this at the top of the file for TypeScript
// Declare fbq for Meta Pixel
declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
  }
}

const JournalEditPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isNewEntry = !id || id === 'new';
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState<string>('');
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');
  const [generatingTitle, setGeneratingTitle] = useState(false);
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [generatingMeta, setGeneratingMeta] = useState(false);
  const [customMood, setCustomMood] = useState('');
  const [linkedEntryIds, setLinkedEntryIds] = useState<string[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const { isSubscribed, loading: subLoading } = useSubscription();

  const [reflectionChain, setReflectionChain] = useState<{ prompt: string, answer: string }[]>([]);
  const [generatingPromptIdx, setGeneratingPromptIdx] = useState<number | null>(null);
  const answerInputRef = useRef<HTMLTextAreaElement | null>(null);
  const [allEntryTitles, setAllEntryTitles] = useState<{ id: string, display: string }[]>([]);

  const moodOptions = [
    { value: '', label: 'Select a mood (optional)' },
    { value: 'Happy', label: 'Happy' },
    { value: 'Calm', label: 'Calm' },
    { value: 'Anxious', label: 'Anxious' },
    { value: 'Energetic', label: 'Energetic' },
    { value: 'Tired', label: 'Tired' },
    { value: 'Grateful', label: 'Grateful' },
    { value: 'Reflective', label: 'Reflective' },
    { value: 'Inspired', label: 'Inspired' },
    { value: 'Focused', label: 'Focused' },
    { value: '__other__', label: 'Other (type your own...)' },
  ];

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    if (!isNewEntry && id) {
      fetchEntry();
    }
  }, [user, id, isNewEntry]);

  useEffect(() => {
    if (!user) return;
    // Fetch all journal entry titles for autocomplete
    supabase
      .from('journal_entries')
      .select('id, title')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (data) {
          setAllEntryTitles(data.map((e: any) => ({ id: e.title, display: e.title })));
        }
      });
  }, [user]);

  const fetchEntry = async () => {
    try {
      setLoading(true);
      if (!user || !id) return;

      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();

      if (error) {
        throw error;
      }

      if (data) {
        setTitle(data.title);
        setContent(data.content);
        setMood(data.mood || '');
        setTags(data.tags || []);
        setLinkedEntryIds(data.linked_entry_ids || []);
      } else {
        setError('Entry not found');
      }
    } catch (error) {
      console.error('Error fetching journal entry:', error);
      setError('Error loading journal entry');
    } finally {
      setLoading(false);
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && currentTag.trim() !== '') {
      e.preventDefault();
      if (!tags.includes(currentTag.trim())) {
        setTags([...tags, currentTag.trim()]);
      }
      setCurrentTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleGeneratePrompt = async () => {
    if (!isSubscribed) {
      setShowSubscribeModal(true);
      return;
    }
    setGeneratingPromptIdx(0);
    try {
      const session = await supabase.auth.getSession();
      const accessToken = session.data.session?.access_token;
      if (!accessToken) throw new Error('No access token');
      const prompt = await generateReflectionPromptWithAIProxy(content, accessToken);
      setReflectionChain([{ prompt, answer: '' }]);
    } catch (e) {
      setReflectionChain([{ prompt: 'Could not generate a reflection prompt. Try again!', answer: '' }]);
    } finally {
      setGeneratingPromptIdx(null);
    }
  };

  const handleRerollPrompt = async (idx: number) => {
    setGeneratingPromptIdx(idx);
    try {
      const session = await supabase.auth.getSession();
      const accessToken = session.data.session?.access_token;
      if (!accessToken) throw new Error('No access token');
      const base = idx === 0 ? content : reflectionChain[idx - 1].answer;
      const prompt = await generateReflectionPromptWithAIProxy(base, accessToken, idx > 0);
      setReflectionChain(chain => chain.map((qa, i) => i === idx ? { ...qa, prompt } : qa));
    } catch (e) {
      setReflectionChain(chain => chain.map((qa, i) => i === idx ? { ...qa, prompt: 'Could not reroll prompt. Try again!' } : qa));
    } finally {
      setGeneratingPromptIdx(null);
    }
  };

  const handleAddFollowUp = async () => {
    const last = reflectionChain[reflectionChain.length - 1];
    if (!last.answer.trim()) return;
    setGeneratingPromptIdx(reflectionChain.length);
    try {
      const session = await supabase.auth.getSession();
      const accessToken = session.data.session?.access_token;
      if (!accessToken) throw new Error('No access token');
      const prompt = await generateReflectionPromptWithAIProxy(last.answer, accessToken, true);
      setReflectionChain(chain => [...chain, { prompt, answer: '' }]);
      setTimeout(() => answerInputRef.current?.focus(), 0);
    } catch (e) {
      setReflectionChain(chain => [...chain, { prompt: 'Could not generate follow-up. Try again!', answer: '' }]);
    } finally {
      setGeneratingPromptIdx(null);
    }
  };

  const handleDeletePrompt = (idx: number) => {
    setReflectionChain(chain => chain.filter((_, i) => i !== idx));
  };

  const handleAnswerChange = (idx: number, value: string) => {
    setReflectionChain(chain => chain.map((qa, i) => i === idx ? { ...qa, answer: value } : qa));
  };

  const extractLinkedTitles = (text: string): string[] => {
    const matches = text.match(/\[\[(.+?)\]\]/g);
    if (!matches) return [];
    return matches.map(m => m.slice(2, -2).trim()).filter(Boolean);
  };

  const resolveTitlesToIds = async (titles: string[]): Promise<string[]> => {
    if (!titles.length) return [];
    const { data, error } = await supabase
      .from('journal_entries')
      .select('id, title')
      .in('title', titles);
    if (error || !data) return [];
    return data.map((entry: any) => entry.id);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    // Only include Q&A pairs with non-blank answers
    const answeredChain = reflectionChain.filter(qa => qa.answer && qa.answer.trim());
    let finalContent = content;
    answeredChain.forEach((qa, i) => {
      finalContent += `\n\n---\n\n### ${i === 0 ? 'Reflection Prompt' : 'Follow-up Prompt'}\n${qa.prompt}\n\n${qa.answer}\n`;
    });

    // Extract linked entry titles and resolve to IDs
    const linkedTitles = extractLinkedTitles(finalContent);
    const linkedIds = await resolveTitlesToIds(linkedTitles);

    if (isNewEntry) {
      if (!finalContent.trim()) {
        setError('Content is required');
        return;
      }
      try {
        setLoading(true);
        setError(null);
        // Save entry with blank title, mood, tags if not provided
        const { data: entry, error } = await supabase
          .from('journal_entries')
          .insert([{ title: '', content: finalContent, mood: null, tags: null, user_id: user.id, linked_entry_ids: linkedIds.length ? linkedIds : null }])
          .select()
          .single();
        if (error || !entry) throw error || new Error('Failed to create entry');
        // Dispatch event to signal journal list should refresh
        window.dispatchEvent(new Event('journal-updated'));
        // Meta Pixel: Track CreateJournalEntry event
        if (window.fbq) window.fbq('track', 'CreateJournalEntry');
        // Fire-and-wait: generate title, mood, tags with AI in the background (only if subscribed)
        if (await isUserSubscribed(user.id)) {
          const session = await supabase.auth.getSession();
          const accessToken = session.data.session?.access_token;
          let aiTitle = '';
          let aiMood = '';
          let aiTags: string[] = [];
          let tokensUsed = 0;
          if (accessToken) {
            // Title
            const aiResponse = await fetch(fnUrl('ai_proxy'), {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`,
              },
              body: JSON.stringify({
                messages: [{ role: 'user', content: `Generate a short, descriptive title (max 8 words) for this journal entry:\n${content.slice(0, 300)}` }],
                model: 'gpt-4.1',
                max_tokens: 16,
                temperature: 0.5,
              }),
            });
            const data = await aiResponse.json();
            aiTitle = data.choices?.[0]?.message?.content?.trim() || '';
            aiTitle = aiTitle.replace(/^['"]+|['"]+$/g, '');
            tokensUsed = data.usage?.total_tokens || 0;
            if (tokensUsed > 0) {
              await reportStripeUsage(user.id, tokensUsed);
            }
            // Mood and tags
            aiMood = await generateJournalMoodWithAIProxy(content, accessToken);
            aiTags = await generateJournalTagsWithAIProxy(content, accessToken);
          }
          // Update entry with AI results
          const updateFields: any = {};
          if (aiTitle) updateFields.title = aiTitle;
          if (aiMood) updateFields.mood = aiMood;
          if (aiTags.length) updateFields.tags = aiTags;
          if (Object.keys(updateFields).length > 0) {
            await supabase.from('journal_entries').update(updateFields).eq('id', entry.id);
          }
        }
        setSaveSuccess(true);
        setTimeout(() => {
          navigate('/journal');
        }, 500);
      } catch (error) {
        console.error('Error saving journal entry:', error);
        setError('Error saving journal entry');
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!title.trim()) {
      setError('Title is required');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const entryData = {
        title,
        content: finalContent,
        mood: (mood === '__other__' || (mood === '' && customMood)) ? customMood : mood || null,
        tags: tags.length > 0 ? tags : null,
        user_id: user.id,
        linked_entry_ids: linkedIds.length ? linkedIds : null
      };
      let result;
      result = await supabase
        .from('journal_entries')
        .update(entryData)
        .eq('id', id)
        .eq('user_id', user.id);
      const { error } = result;
      if (error) {
        throw error;
      }
      setSaveSuccess(true);
      // Redirect after successful save (edit mode): go to reading mode for this entry
      setTimeout(() => {
        navigate(`/journal/${id}`);
      }, 800);
    } catch (error) {
      console.error('Error saving journal entry:', error);
      setError('Error saving journal entry');
    } finally {
      setLoading(false);
    }
  };

  if (loading && !isNewEntry) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-300">Loading journal entry...</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <Link to="/journal" className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
          <ArrowLeft size={16} className="mr-1" />
          Back to Journal
        </Link>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>{isNewEntry ? 'New Journal Entry' : 'Edit Journal Entry'}</CardTitle>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            {error && (
              <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-3 rounded-md">
                {error}
              </div>
            )}
            
            {saveSuccess && (
              <div className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 p-3 rounded-md">
                Journal entry saved successfully!
              </div>
            )}
            
            {/* Show title, mood, and tags fields for non-subscribers or when editing */}
            {(!isSubscribed || !isNewEntry) && (
              <>
                <Input
                  label="Title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Give your entry a title"
                  required
                />
                {!isSubscribed && isNewEntry && (
                  <div className="text-xs text-indigo-500 mt-1">
                    Unlock effortless journaling: Subscribers can skip the title, mood, and tags fields and let AI generate them for every entry.
                  </div>
                )}
                <Select
                  label="Mood (Optional)"
                  options={moodOptions}
                  value={mood === '' || moodOptions.some(opt => opt.value === mood) ? mood : '__other__'}
                  onChange={(val) => {
                    if (val === '__other__') {
                      setMood('');
                    } else {
                      setMood(val);
                      setCustomMood('');
                    }
                  }}
                />
                {(!isSubscribed && isNewEntry) && (
                  <div className="text-xs text-indigo-500 mt-1">
                    Unlock effortless journaling: Subscribers can skip the mood field and let AI generate it for every entry.
                  </div>
                )}
                {((mood === '' && customMood === '') || mood === '__other__' || customMood !== '') && (
                  <Input
                    label="Custom Mood"
                    value={customMood}
                    onChange={e => setCustomMood(e.target.value)}
                    placeholder="Type your mood..."
                    className="mt-2"
                  />
                )}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tags (Optional)
                  </label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {tags.map((tag, index) => (
                      <div 
                        key={index}
                        className="inline-flex items-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300 px-3 py-1 rounded-full text-sm"
                      >
                        {tag}
                        <button 
                          type="button" 
                          onClick={() => handleRemoveTag(tag)}
                          className="ml-1 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex">
                    <Input
                      value={currentTag}
                      onChange={(e) => setCurrentTag(e.target.value)}
                      placeholder="Add a tag (press Enter)"
                      onKeyDown={handleAddTag}
                      helperText="Press Enter to add a tag"
                    />
                  </div>
                  {(!isSubscribed && isNewEntry) && (
                    <div className="text-xs text-indigo-500 mt-1">
                      Unlock effortless journaling: Subscribers can skip the tags field and let AI generate them for every entry.
                    </div>
                  )}
                </div>
              </>
            )}
            
            <MentionsInput
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Write your thoughts, reflections, or experiences..."
              className="block w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-indigo-500 focus:border-indigo-500 text-base min-h-[180px] p-3"
              style={{ minHeight: 180, fontSize: 16, fontFamily: 'inherit' }}
              allowSuggestionsAboveCursor={true}
              markup="[[__display__]]"
              forceSuggestionsAboveCursor={true}
            >
              <Mention
                trigger="[["
                data={allEntryTitles}
                markup="[[__display__]]"
                displayTransform={(_id, display) => display}
                appendSpaceOnAdd={false}
                style={{ backgroundColor: '#c7d2fe', color: '#3730a3', borderRadius: 4, padding: '0 2px' }}
              />
            </MentionsInput>
            <div className="text-xs text-indigo-500 mt-1">
              💡 Type <span className="font-mono bg-gray-100 px-1 rounded">[[</span> to link to another journal entry!
            </div>
            
            {/* Unlimited Reflection Prompt Chain */}
            <div className="mt-6">
              <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-2xl p-5 shadow-inner flex flex-col gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-xl">💡</span>
                  <span className="font-semibold text-indigo-700 dark:text-indigo-200">Need inspiration? Generate a Reflection Prompt</span>
                  <Button type="button" size="sm" variant="outline" onClick={handleGeneratePrompt} isLoading={generatingPromptIdx === 0} disabled={generatingPromptIdx === 0 || !content.trim()} className="ml-auto">Generate</Button>
                </div>
                {reflectionChain.map((qa, idx) => (
                  <div key={idx} className="mt-2 p-4 bg-white dark:bg-gray-950 rounded-xl border border-indigo-200 dark:border-indigo-800 shadow">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="text-indigo-800 dark:text-indigo-200 font-medium">
                        <ReactMarkdown className="prose prose-indigo dark:prose-invert max-w-none prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700" remarkPlugins={[remarkGfm]}>{qa.prompt}</ReactMarkdown>
                      </div>
                      <Button type="button" size="sm" variant="outline" onClick={() => handleRerollPrompt(idx)} isLoading={generatingPromptIdx === idx} disabled={generatingPromptIdx === idx} className="ml-2">Reroll</Button>
                      {idx > 0 && (
                        <Button type="button" size="sm" variant="danger" onClick={() => handleDeletePrompt(idx)} disabled={generatingPromptIdx !== null} className="ml-2">Delete</Button>
                      )}
                    </div>
                    <TextArea
                      label={idx === 0 ? 'Your Answer' : 'Your Deeper Reflection'}
                      value={qa.answer}
                      onChange={e => handleAnswerChange(idx, e.target.value)}
                      placeholder={idx === 0 ? 'Write your reflection...' : 'Write your deeper reflection...'}
                      rows={3}
                      ref={idx === reflectionChain.length - 1 ? answerInputRef : undefined}
                    />
                    {qa.answer && (
                      <div className="mt-2">
                        <ReactMarkdown className="prose prose-indigo dark:prose-invert max-w-none prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700" remarkPlugins={[remarkGfm]}>{qa.answer}</ReactMarkdown>
                      </div>
                    )}
                    {/* Only show Go Deeper after the last Q&A pair, and only if its answer is non-blank */}
                    {idx === reflectionChain.length - 1 && qa.answer && qa.answer.trim() && (
                      <div className="flex gap-2 mt-2">
                        <Button type="button" size="sm" variant="outline" onClick={handleAddFollowUp} isLoading={generatingPromptIdx === reflectionChain.length} disabled={generatingPromptIdx === reflectionChain.length}>
                          Go Deeper
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {generatingTitle && isSubscribed && (
              <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-300 mt-4">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-indigo-500" />
                <span>Generating title...</span>
              </div>
            )}
            {generatingMeta && isSubscribed && (
              <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-300 mt-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-500" />
                <span>Analyzing mood and tags...</span>
              </div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-end space-x-4">
            <Link to="/journal">
              <Button type="button" variant="outline">
                Cancel
              </Button>
            </Link>
            <Button 
              type="submit" 
              variant="primary"
              leftIcon={<Save size={16} />}
              isLoading={loading}
              disabled={loading}
            >
              Save Entry
            </Button>
          </CardFooter>
        </form>
      </Card>
      <Modal
        open={showSubscribeModal}
        onClose={() => setShowSubscribeModal(false)}
        title="Subscribe to Unlock AI Features"
        actions={<Button variant="primary" onClick={() => navigate('/pricing')}>View Plans</Button>}
      >
        You need an active subscription to use AI-powered features.
      </Modal>
    </div>
  );
};

export default JournalEditPage;