import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../hooks/useSubscription';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import Button from '../components/Button';
import { Check, Sparkles, Key, Crown, AlertCircle } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';

// Add this at the top of the file for TypeScript
// Declare fbq for Meta Pixel
declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
  }
}

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

const SUBSCRIPTION_PRICE_ID = 'price_1RlJ7OJjMH6y0evJnHHvzNfR'; // $4.99/month
const OVERAGE_PRICE_ID = 'price_1RiuKbJjMH6y0evJEAdfQ7Ym'; // $0.75 per 50K tokens

const PricingPage: React.FC = () => {
  const { user } = useAuth();
  const { isSubscribed, loading, error } = useSubscription();
  const [subscribeError, setSubscribeError] = useState<string | null>(null);
  
  const handleSubscribe = async (priceId: string) => {
    setSubscribeError(null);
    if (!user) {
      setSubscribeError('You must be logged in to subscribe.');
      return;
    }
    try {
      console.log('Stripe key:', import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);
      const stripe = await stripePromise;
      console.log('Stripe loaded:', !!stripe);
      if (!stripe) throw new Error('Stripe not loaded');

      console.log('Calling stripe function...');
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          priceId,
          userId: user.id,
        }),
      });
      const data = await response.json();
      console.log('Stripe function response:', data);
      const { sessionId, error } = data;
      if (error || !sessionId) throw new Error(error || 'No sessionId returned from Stripe');
      // Meta Pixel: Track InitiateCheckout event
      if (window.fbq) window.fbq('track', 'InitiateCheckout');
      await stripe.redirectToCheckout({ sessionId });
    } catch (error: any) {
      setSubscribeError(error.message || 'Subscription failed.');
      console.error('Subscribe error:', error);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-300">Loading subscription status...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12 text-red-600">
        {error}
      </div>
    );
  }

  if (isSubscribed) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">Thank you for subscribing!</h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
          You have access to all premium features. Manage your subscription below.
        </p>
        <Button
          variant="outline"
          onClick={() => window.location.href = '/account'}
        >
          Manage Subscription
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-center items-center px-4 py-12
      bg-gradient-to-br from-indigo-100 via-blue-50 to-teal-100
      dark:from-indigo-950 dark:via-blue-900 dark:to-teal-900
      transition-colors duration-500">
      <div className="w-full max-w-lg mx-auto text-center mb-10">
        <h1
          className="text-4xl font-extrabold mb-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400 bg-clip-text text-transparent
            animate-fadein-up"
          style={{ WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}
        >
          Unlock MindfulSphere AI
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-200 mb-2 animate-fadein-up delay-100">
          All your yoga and journaling, powered by AI. Simple, fair pricing.
        </p>
        <p className="text-base text-gray-500 dark:text-gray-400 animate-fadein-up delay-200">
          Pay for what you use, with generous included tokens.
        </p>
      </div>
      <div className="w-full max-w-md mx-auto rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300
        bg-white/80 dark:bg-gray-900/80 border border-indigo-200 dark:border-indigo-800
        p-8 mb-8 animate-fadein-scale">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xl font-semibold text-indigo-800 dark:text-indigo-100 flex items-center gap-2">
            <Sparkles className="text-indigo-400 transition-colors duration-300 group-hover:text-pink-400" size={22} />
            All-Access Membership
          </span>
          <span className="text-2xl font-bold text-indigo-700 dark:text-indigo-200 animate-pulse-soft">
            $4.99
            <span className="text-base font-medium text-gray-500 dark:text-gray-400">/month</span>
          </span>
        </div>
        <ul className="space-y-3 mb-6 text-base text-left">
          <li className="flex items-center text-gray-800 dark:text-gray-100">
            <Sparkles className="text-indigo-400 mr-2 transition-colors duration-300 group-hover:text-pink-400" size={20} />
            All AI-powered features included (yoga, journaling, TTS)
          </li>
          <li className="flex items-center text-gray-800 dark:text-gray-100">
            <Check className="text-green-500 mr-2 transition-colors duration-300 group-hover:text-indigo-400" size={20} />
            100,000 AI tokens/month included (used for all AI features)
          </li>
          <li className="flex items-center text-gray-800 dark:text-gray-100">
            <Check className="text-green-500 mr-2 transition-colors duration-300 group-hover:text-indigo-400" size={20} />
            Overage: $0.75 per 50,000 extra tokens (billed automatically)
          </li>
          <li className="flex items-center text-gray-800 dark:text-gray-100">
            <Crown className="text-yellow-400 mr-2 transition-colors duration-300 group-hover:text-pink-400" size={20} />
            Exclusive Discord community
          </li>
          <li className="flex items-center text-gray-800 dark:text-gray-100">
            <Key className="text-indigo-300 mr-2 transition-colors duration-300 group-hover:text-pink-400" size={20} />
            Cancel anytime, no commitment
          </li>
        </ul>
        <Button
          variant="primary"
          className="w-full text-lg py-3 rounded-full font-semibold
            bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400
            shadow-lg text-white transition transform
            animate-btn-pop-loop focus:outline-none
            hover:scale-105 focus:scale-105
            hover:shadow-xl focus:shadow-xl
            ring-2 ring-indigo-300/30 focus:ring-4 focus:ring-pink-300/40"
          onClick={() => handleSubscribe(SUBSCRIPTION_PRICE_ID)}
          disabled={!user}
        >
          {user ? 'Start My Practice' : 'Sign up or log in to get started'}
        </Button>
        {subscribeError && (
          <div className="text-red-600 text-center mb-4">{subscribeError}</div>
        )}
        <p className="text-sm text-center text-gray-500 dark:text-gray-400 mt-4 animate-fadein-up delay-400">
          No hidden fees. Most members never pay extra. All AI features share the same token pool. Overage is $0.75 per 50,000 tokens.
        </p>
      </div>
      <div className="text-center text-gray-500 dark:text-gray-400 animate-fadein-up delay-500">
        <p>Questions? <a href="mailto:contact@mindful-sphere.com" className="text-indigo-600 dark:text-indigo-300 underline">Contact support</a></p>
      </div>
      {/* Custom animation keyframes (add to your global CSS if not already present) */}
      <style>{`
        @keyframes fadein-up {
          0% { opacity: 0; transform: translateY(24px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-fadein-up {
          animation: fadein-up 0.7s cubic-bezier(0.4,0,0.2,1) both;
        }
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-400 { animation-delay: 0.4s; }
        .delay-500 { animation-delay: 0.5s; }
        @keyframes fadein-scale {
          0% { opacity: 0; transform: scale(0.96); }
          100% { opacity: 1; transform: scale(1); }
        }
        .animate-fadein-scale {
          animation: fadein-scale 0.7s cubic-bezier(0.4,0,0.2,1) both;
        }
        @keyframes pulse-soft {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.92; transform: scale(1.06); }
        }
        .animate-pulse-soft {
          animation: pulse-soft 1.8s ease-in-out infinite;
        }
        @keyframes btn-pop {
          0% { transform: scale(0.98); box-shadow: 0 0 0 0 rgba(168,85,247,0.18); }
          60% { transform: scale(1.06); box-shadow: 0 4px 24px 0 rgba(168,85,247,0.22); }
          100% { transform: scale(1); box-shadow: 0 2px 12px 0 rgba(168,85,247,0.18); }
        }
        .animate-btn-pop-loop {
          animation: btn-pop 1.4s cubic-bezier(0.4,0,0.2,1) infinite;
        }
      `}</style>
    </div>
  );
};

export default PricingPage;