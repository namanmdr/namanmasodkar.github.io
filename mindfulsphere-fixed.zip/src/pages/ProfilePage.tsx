import { fnUrl } from '../lib/functions';
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import Select from '../components/Select';
import TextArea from '../components/TextArea';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { UserCircle, Mail, Key, LogOut, Globe, Calendar, MapPin, Target, Clock, Link as LinkIcon, Github as BrandGithub, Twitter as BrandTwitter, Linkedin as BrandLinkedin, Settings, Save, X } from 'lucide-react';
import { useSubscription } from '../hooks/useSubscription';
import { useNavigate } from 'react-router-dom';

interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  gender: string | null;
  birth_date: string | null;
  location: string | null;
  experience_level: string | null;
  preferred_practice_time: string | null;
  goals: string[] | null;
  bio: string | null;
  website: string | null;
  social_links: {
    github?: string;
    twitter?: string;
    linkedin?: string;
  } | null;
  preferences: {
    email_notifications: boolean;
    practice_reminders: boolean;
    journal_reminders: boolean;
    theme: 'light' | 'dark' | 'system';
    language: string;
  } | null;
  account_type: 'student' | 'teacher';
  is_teacher_listed?: boolean;
  teacher_bio?: string | null;
  teaching_styles?: string[] | null;
  years_experience?: number | null;
  certifications?: string | null;
  studio_location?: string | null;
  public_contact?: string | null;
}

const ProfilePage: React.FC = () => {
  const { user, signOut, session } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [portalLoading, setPortalLoading] = useState(false);

  // Form fields
  const [fullName, setFullName] = useState('');
  const [gender, setGender] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [location, setLocation] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('');
  const [preferredPracticeTime, setPreferredPracticeTime] = useState('');
  const [bio, setBio] = useState('');
  const [website, setWebsite] = useState('');
  const [goals, setGoals] = useState<string[]>([]);
  const [currentGoal, setCurrentGoal] = useState('');
  const [socialLinks, setSocialLinks] = useState({
    github: '',
    twitter: '',
    linkedin: ''
  });
  const [preferences, setPreferences] = useState({
    email_notifications: true,
    practice_reminders: true,
    journal_reminders: true,
    theme: 'system' as 'light' | 'dark' | 'system',
    language: 'en'
  });
  
  // Password change fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);

  // Add new state for teacher fields
  const [accountType, setAccountType] = useState<'student' | 'teacher'>('student');
  const [isTeacherListed, setIsTeacherListed] = useState(false);
  const [teacherBio, setTeacherBio] = useState('');
  const [teachingStyles, setTeachingStyles] = useState<string[]>([]);
  const [currentTeachingStyle, setCurrentTeachingStyle] = useState('');
  const [yearsExperience, setYearsExperience] = useState<number | ''>('');
  const [certifications, setCertifications] = useState('');
  const [studioLocation, setStudioLocation] = useState('');
  const [publicContact, setPublicContact] = useState('');

  const { monthlyUsage, isSubscribed } = useSubscription();
  const monthlyQuota = 100000;
  const usagePercent = Math.min(100, Math.round((monthlyUsage / monthlyQuota) * 100));

  useEffect(() => {
    if (user) {
      fetchProfile();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      if (!user) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
        setFullName(data.full_name || '');
        setGender(data.gender || '');
        setBirthDate(data.birth_date || '');
        setLocation(data.location || '');
        setExperienceLevel(data.experience_level || '');
        setPreferredPracticeTime(data.preferred_practice_time || '');
        setBio(data.bio || '');
        setWebsite(data.website || '');
        setGoals(data.goals || []);
        setSocialLinks(data.social_links || { github: '', twitter: '', linkedin: '' });
        setPreferences(data.preferences || {
          email_notifications: true,
          practice_reminders: true,
          journal_reminders: true,
          theme: 'system',
          language: 'en'
        });
        setAccountType(data.account_type || 'student');
        setIsTeacherListed(!!data.is_teacher_listed);
        setTeacherBio(data.teacher_bio || '');
        console.log('Fetched teaching_styles:', data.teaching_styles);
        setTeachingStyles(Array.isArray(data.teaching_styles) ? data.teaching_styles : (typeof data.teaching_styles === 'string' && data.teaching_styles.length > 0 ? [data.teaching_styles] : []));
        setYearsExperience(data.years_experience ?? '');
        setCertifications(data.certifications || '');
        setStudioLocation(data.studio_location || '');
        setPublicContact(data.public_contact || '');
      } else {
        // Create a new profile if one doesn't exist
        const newProfile = {
          id: user.id,
          email: user.email || '',
          full_name: '',
          avatar_url: null,
          gender: null,
          birth_date: null,
          location: null,
          experience_level: null,
          preferred_practice_time: null,
          goals: [],
          bio: null,
          website: null,
          social_links: { github: '', twitter: '', linkedin: '' },
          preferences: {
            email_notifications: true,
            practice_reminders: true,
            journal_reminders: true,
            theme: 'system' as 'light' | 'dark' | 'system',
            language: 'en'
          },
          account_type: 'student',
          is_teacher_listed: false,
          teacher_bio: '',
          teaching_styles: [],
          years_experience: null,
          certifications: '',
          studio_location: '',
          public_contact: '',
        };
        
        const { error: insertError } = await supabase
          .from('profiles')
          .insert([newProfile]);
          
        if (insertError) throw insertError;
        
        setProfile(newProfile);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddGoal = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && currentGoal.trim()) {
      e.preventDefault();
      const newGoal = currentGoal.trim();
      if (!goals.includes(newGoal)) {
        setGoals([...goals, newGoal]);
      }
      setCurrentGoal('');
    }
  };

  const handleRemoveGoal = (goalToRemove: string) => {
    setGoals(goals.filter(goal => goal !== goalToRemove));
  };

  const updateProfile = async (section?: string) => {
    try {
      setUpdating(true);
      setError(null);
      setSuccess(null);
      
      if (!user) return;

      // Debug logs for state
      console.log('teachingStyles at save:', teachingStyles);
      console.log('goals at save:', goals);
      console.log('preferences at save:', preferences);
      console.log('socialLinks at save:', socialLinks);

      const updates = {
        id: user.id,
        email: user.email,
        full_name: fullName,
        gender,
        birth_date: birthDate || null,
        location,
        experience_level: experienceLevel,
        preferred_practice_time: preferredPracticeTime,
        goals: Array.isArray(goals) ? goals : [],
        bio,
        website,
        social_links: typeof socialLinks === 'object' && socialLinks !== null ? socialLinks : { github: '', twitter: '', linkedin: '' },
        preferences: typeof preferences === 'object' && preferences !== null ? preferences : {
          email_notifications: true,
          practice_reminders: true,
          journal_reminders: true,
          theme: 'system',
          language: 'en'
        },
        account_type: accountType,
        is_teacher_listed: accountType === 'teacher' ? isTeacherListed : false,
        teacher_bio: accountType === 'teacher' ? teacherBio : '',
        teaching_styles: accountType === 'teacher' ? (Array.isArray(teachingStyles) ? teachingStyles : []) : [],
        years_experience: accountType === 'teacher' ? (yearsExperience === '' ? null : yearsExperience) : null,
        certifications: accountType === 'teacher' ? certifications : '',
        studio_location: accountType === 'teacher' ? studioLocation : '',
        public_contact: accountType === 'teacher' ? publicContact : '',
        updated_at: new Date().toISOString()
      };
      console.log('Profile update payload:', updates);

      const { error } = await supabase
        .from('profiles')
        .upsert(updates);

      if (error) {
        console.error('Supabase upsert error:', error);
        throw error;
      }

      setSuccess(`${section || 'Profile'} updated successfully!`);
      await fetchProfile();
    } catch (error) {
      console.error('Error updating profile:', error);
      setError('Error updating profile');
    } finally {
      setUpdating(false);
    }
  };

  const handleUpdatePassword = async () => {
    try {
      setPasswordError(null);
      setPasswordSuccess(null);
      
      if (!currentPassword || !newPassword || !confirmPassword) {
        setPasswordError('All password fields are required');
        return;
      }
      
      if (newPassword !== confirmPassword) {
        setPasswordError('New passwords do not match');
        return;
      }
      
      if (newPassword.length < 8) {
        setPasswordError('New password must be at least 8 characters');
        return;
      }
      
      setChangingPassword(true);
      
      // First verify the current password
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user?.email || '',
        password: currentPassword
      });
      
      if (signInError) {
        setPasswordError('Current password is incorrect');
        setChangingPassword(false);
        return;
      }
      
      // Update to the new password
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      
      if (error) {
        throw error;
      }
      
      setPasswordSuccess('Password updated successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error) {
      console.error('Error updating password:', error);
      setPasswordError('Error updating password');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleManageSubscription = async () => {
    setPortalLoading(true);
    try {
      const res = await fetch(fnUrl('customer_portal'), {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`
        }
      });
      if (!res.ok) throw new Error('Failed to open customer portal');
      const { url } = await res.json();
      window.location.href = url;
    } catch (err) {
      alert('Could not open Stripe customer portal. Please try again later.');
    } finally {
      setPortalLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-300">Loading profile...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Please Log In to View Your Profile</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          You need to be logged in to access your profile.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <section>
        <h1 className="text-3xl font-bold mb-4">Your Profile</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Manage your account settings and preferences
        </p>
      </section>
      
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-3 rounded-md">
              {error}
            </div>
          )}
          
          {success && (
            <div className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 p-3 rounded-md">
              {success}
            </div>
          )}
          
          <div className="flex items-center space-x-4">
            <div className="bg-indigo-100 dark:bg-indigo-900/30 p-4 rounded-full">
              <UserCircle size={40} className="text-indigo-600 dark:text-indigo-400" />
            </div>
            <div>
              <h3 className="font-medium">{fullName || 'Your Name'}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
            </div>
          </div>
          
          <Input
            label="Full Name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Enter your full name"
          />
          
          <Input
            label="Email Address"
            value={user.email || ''}
            disabled
            helperText="Email cannot be changed"
          />

          <Select
            label="Gender"
            value={gender}
            onChange={setGender}
            options={[
              { value: '', label: 'Prefer not to say' },
              { value: 'male', label: 'Male' },
              { value: 'female', label: 'Female' },
              { value: 'non-binary', label: 'Non-binary' },
              { value: 'other', label: 'Other' }
            ]}
          />

          <Input
            label="Birth Date"
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
          />

          <Input
            label="Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="City, Country"
          />
        </CardContent>
        <CardFooter>
          <Button
            variant="primary"
            onClick={() => updateProfile('Basic Information')}
            isLoading={updating}
            disabled={updating}
            leftIcon={<Save size={16} />}
          >
            Save Basic Information
          </Button>
        </CardFooter>
      </Card>

      {/* Subscription Status */}
      <Card>
        <CardHeader>
          <CardTitle>Subscription</CardTitle>
        </CardHeader>
        <CardContent>
          {isSubscribed ? (
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <span className="text-green-700 dark:text-green-400 font-semibold">You are subscribed to MindfulSphere AI.</span>
              <Button
                variant="outline"
                onClick={handleManageSubscription}
                isLoading={portalLoading}
              >
                Manage Subscription
              </Button>
            </div>
          ) : (
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <span className="text-indigo-700 dark:text-indigo-400 font-semibold">Unlock all AI-powered features with a MindfulSphere subscription.</span>
              <Button
                variant="primary"
                onClick={() => window.location.href = '/pricing'}
              >
                View Pricing & Upgrade
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      {/* AI Usage Bar */}
      <Card>
        <CardHeader>
          <CardTitle>AI Usage</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-1">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Monthly AI Usage</span>
            <span className="text-sm text-gray-500 dark:text-gray-400">{monthlyUsage.toLocaleString()} / {monthlyQuota.toLocaleString()} tokens</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 mb-2">
            <div
              className="bg-indigo-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${usagePercent}%` }}
            ></div>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 mb-2">
            <span>Included in the subscription: 100,000 tokens/month. Overage: $0.75 per 50,000 extra tokens. Overage is billed automatically by Stripe at the end of your billing period.</span>
          </div>
          {monthlyUsage >= monthlyQuota && (
            <div className="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 p-2 rounded mb-2 text-xs font-medium">
              You have exceeded your included quota. Extra usage will be billed as overage at the end of your billing period.
            </div>
          )}
          {monthlyUsage >= 0.8 * monthlyQuota && monthlyUsage < monthlyQuota && (
            <div className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200 p-2 rounded mb-2 text-xs font-medium">
              You are approaching your included quota. Extra usage will be billed as overage.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Practice Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Practice Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Select
            label="Experience Level"
            value={experienceLevel}
            onChange={setExperienceLevel}
            options={[
              { value: '', label: 'Select your experience level' },
              { value: 'beginner', label: 'Beginner' },
              { value: 'intermediate', label: 'Intermediate' },
              { value: 'advanced', label: 'Advanced' }
            ]}
          />

          <Select
            label="Preferred Practice Time"
            value={preferredPracticeTime}
            onChange={setPreferredPracticeTime}
            options={[
              { value: '', label: 'Select preferred time' },
              { value: 'morning', label: 'Morning' },
              { value: 'afternoon', label: 'Afternoon' },
              { value: 'evening', label: 'Evening' },
              { value: 'night', label: 'Night' }
            ]}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Practice Goals
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {Array.isArray(goals) && goals.map((goal, index) => (
                <div 
                  key={index}
                  className="inline-flex items-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300 px-3 py-1 rounded-full text-sm"
                >
                  {goal}
                  <button 
                    type="button"
                    onClick={() => handleRemoveGoal(goal)}
                    className="ml-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
            <Input
              value={currentGoal}
              onChange={(e) => setCurrentGoal(e.target.value)}
              placeholder="Add a goal (press Enter)"
              onKeyDown={handleAddGoal}
              helperText="Examples: Improve flexibility, Reduce stress, Build strength"
            />
          </div>

          <TextArea
            label="Bio"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Tell us about yourself and your mindfulness journey..."
            rows={4}
          />
        </CardContent>
        <CardFooter>
          <Button
            variant="primary"
            onClick={() => updateProfile('Practice Preferences')}
            isLoading={updating}
            disabled={updating}
            leftIcon={<Save size={16} />}
          >
            Save Practice Preferences
          </Button>
        </CardFooter>
      </Card>

      {/* Online Presence */}
      <Card>
        <CardHeader>
          <CardTitle>Online Presence</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Input
            label="Website"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            placeholder="https://your-website.com"
          />

          <Input
            label="GitHub"
            value={socialLinks.github}
            onChange={(e) => setSocialLinks({ ...socialLinks, github: e.target.value })}
            placeholder="Your GitHub username"
          />

          <Input
            label="Twitter"
            value={socialLinks.twitter}
            onChange={(e) => setSocialLinks({ ...socialLinks, twitter: e.target.value })}
            placeholder="Your Twitter username"
          />

          <Input
            label="LinkedIn"
            value={socialLinks.linkedin}
            onChange={(e) => setSocialLinks({ ...socialLinks, linkedin: e.target.value })}
            placeholder="Your LinkedIn profile URL"
          />
        </CardContent>
        <CardFooter>
          <Button
            variant="primary"
            onClick={() => updateProfile('Online Presence')}
            isLoading={updating}
            disabled={updating}
            leftIcon={<Save size={16} />}
          >
            Save Online Presence
          </Button>
        </CardFooter>
      </Card>
      
      {/* Password Change */}
      <Card>
        <CardHeader>
          <CardTitle>Change Password</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {passwordError && (
            <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-3 rounded-md">
              {passwordError}
            </div>
          )}
          
          {passwordSuccess && (
            <div className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 p-3 rounded-md">
              {passwordSuccess}
            </div>
          )}
          
          <Input
            label="Current Password"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Enter current password"
          />
          
          <Input
            label="New Password"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter new password"
            helperText="Must be at least 8 characters"
          />
          
          <Input
            label="Confirm New Password"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm new password"
          />
        </CardContent>
        <CardFooter>
          <Button
            variant="primary"
            onClick={handleUpdatePassword}
            isLoading={changingPassword}
            disabled={changingPassword}
          >
            Update Password
          </Button>
        </CardFooter>
      </Card>
      
      {/* Account Type */}
      <Card>
        <CardHeader>
          <CardTitle>Account Type</CardTitle>
        </CardHeader>
        <CardContent>
          <Select
            label="Account Type"
            value={accountType}
            onChange={setAccountType}
            options={[
              { value: 'student', label: 'Student' },
              { value: 'teacher', label: 'Teacher' }
            ]}
          />
        </CardContent>
      </Card>

      {/* Conditionally render teacher fields if accountType === 'teacher' */}
      {accountType === 'teacher' && (
        <Card>
          <CardHeader>
            <CardTitle>Teacher Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={isTeacherListed}
                onChange={e => setIsTeacherListed(e.target.checked)}
              />
              List me in the public directory of yoga teachers
            </label>
            <TextArea
              label="Teacher Bio"
              value={teacherBio}
              onChange={e => setTeacherBio(e.target.value)}
              placeholder="Short bio for your public teacher profile"
              rows={3}
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Yoga Styles Taught
              </label>
              <div className="flex flex-wrap gap-2 mb-2">
                {teachingStyles.map((style, idx) => (
                  <div key={idx} className="inline-flex items-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300 px-3 py-1 rounded-full text-sm">
                    {style}
                    <button
                      type="button"
                      onClick={() => setTeachingStyles(teachingStyles.filter(s => s !== style))}
                      className="ml-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
              <Input
                value={currentTeachingStyle}
                onChange={e => setCurrentTeachingStyle(e.target.value)}
                placeholder="Add a style (press Enter)"
                onKeyDown={async e => {
                  if (e.key === 'Enter' && currentTeachingStyle.trim()) {
                    e.preventDefault();
                    const newStyle = currentTeachingStyle.trim();
                    if (!teachingStyles.includes(newStyle)) {
                      setTeachingStyles(prev => {
                        const updated = [...prev, newStyle];
                        // Auto-save after adding
                        setTimeout(() => updateProfile('Teacher Settings'), 0);
                        return updated;
                      });
                    }
                    setCurrentTeachingStyle('');
                  }
                }}
                helperText="Examples: Hatha, Vinyasa, Yin, Ashtanga, etc."
              />
            </div>
            <Input
              label="Years of Teaching Experience"
              type="number"
              min={0}
              value={yearsExperience}
              onChange={e => setYearsExperience(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 5"
            />
            <Input
              label="Certifications"
              value={certifications}
              onChange={e => setCertifications(e.target.value)}
              placeholder="e.g. RYT-200, RYT-500, etc."
            />
            <Input
              label="Studio/Location"
              value={studioLocation}
              onChange={e => setStudioLocation(e.target.value)}
              placeholder="e.g. Yoga Studio, City, Country"
            />
            <Input
              label="Public Contact Info"
              value={publicContact}
              onChange={e => setPublicContact(e.target.value)}
              placeholder="Email, phone, or website for public directory"
            />
          </CardContent>
          <CardFooter>
            <Button
              variant="primary"
              onClick={() => updateProfile('Teacher Settings')}
              isLoading={updating}
              disabled={updating}
              leftIcon={<Save size={16} />}
            >
              Save Teacher Settings
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Account Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Account Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Sign out of your account on this device.
          </p>
          <Button
            variant="outline"
            leftIcon={<LogOut size={16} />}
            onClick={handleSignOut}
            className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30"
          >
            Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;