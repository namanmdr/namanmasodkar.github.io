import React from 'react';

const TermsOfServicePage = () => (
  <div className="max-w-3xl mx-auto py-12 px-4">
    <h1 className="text-3xl font-bold mb-4">Terms of Service</h1>
    <p>
      <strong>Effective Date:</strong> July 2025
    </p>
    <p className="mt-4">
      By accessing or using MindfulSphere, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our website or services.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Use of Service</h2>
    <ul className="list-disc ml-6">
      <li>You must be at least 16 years old to use MindfulSphere.</li>
      <li>You agree not to misuse the service or help anyone else do so.</li>
      <li>All content is for informational purposes only and is not a substitute for professional advice.</li>
    </ul>
    <h2 className="text-xl font-semibold mt-6 mb-2">Intellectual Property</h2>
    <p>
      All content on MindfulSphere is the property of MindfulSphere or its licensors. You may not copy, reproduce, or distribute any content without permission.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Limitation of Liability</h2>
    <p>
      MindfulSphere is provided “as is” without warranties of any kind. We are not liable for any damages arising from your use of the site.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Changes to Terms</h2>
    <p>
      We may update these Terms of Service from time to time. Continued use of the site constitutes acceptance of the new terms.
    </p>
    <h2 className="text-xl font-semibold mt-6 mb-2">Contact</h2>
    <p>
      For questions about these Terms, contact us at <a href="mailto:contact@mindful-sphere.com" className="text-indigo-600 underline">contact@mindful-sphere.com</a>.
    </p>
  </div>
);

export default TermsOfServicePage; 