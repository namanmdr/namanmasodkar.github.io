import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Edit, Trash2, Calendar, Tag, Download, Share2, Bot as Lotus } from 'lucide-react';
import { format } from 'date-fns';
import { exportToMarkdown, downloadAsFile } from '../lib/export';
import IntentGenerator from '../components/IntentGenerator';
import Modal from '../components/Modal';
import { generateJournalAnalysisWithAIProxy } from '../lib/ai';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { useSubscription } from '../hooks/useSubscription';

interface JournalEntry {
  id: string;
  created_at: string;
  title: string;
  content: string;
  user_id: string;
  mood: string | null;
  tags: string[] | null;
}

// Add type for persistent analysis
interface JournalEntryAnalysis {
  id: string;
  journal_entry_id: string;
  user_id: string;
  type: string;
  prompt: string | null;
  result: string;
  created_at: string;
}

const JournalEntryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [entry, setEntry] = useState<JournalEntry | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showIntentGenerator, setShowIntentGenerator] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showDeleteErrorModal, setShowDeleteErrorModal] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [showCopyToast, setShowCopyToast] = useState(false);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [analysisType, setAnalysisType] = useState('dream');
  const [customAnalysisPrompt, setCustomAnalysisPrompt] = useState('');
  const [analysisResult, setAnalysisResult] = useState('');
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisHistory, setAnalysisHistory] = useState<JournalEntryAnalysis[]>([]);
  // Add expandedAnalysis state to track which analysis is expanded
  const [expandedAnalysis, setExpandedAnalysis] = useState<number | null>(null);
  const { isSubscribed } = useSubscription();
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [linkedTitleToId, setLinkedTitleToId] = useState<Record<string, string>>({});

  // Fetch persistent analyses on entry load
  useEffect(() => {
    const fetchAnalyses = async () => {
      if (!user || !id) return;
      const { data, error } = await supabase
        .from('journal_entry_analyses')
        .select('*')
        .eq('journal_entry_id', id)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (!error && data) setAnalysisHistory(data);
    };
    if (user && id) fetchAnalyses();
  }, [user, id]);

  useEffect(() => {
    if (user && id) {
      fetchEntry();
    }
  }, [user, id]);

  const fetchEntry = async () => {
    if (!user || !id) {
      // Don't fetch if user or id is not ready
      return;
    }
    try {
      setLoading(true);
      console.log('Fetching entry for id:', id, 'user:', user.id);
      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();
      console.log('Supabase fetch result:', { data, error });
      if (error) {
        throw error;
      }
      if (data) {
        setEntry(data);
      } else {
        setError('Entry not found');
      }
    } catch (error) {
      console.error('Error fetching journal entry:', error);
      setError('Error loading journal entry');
    } finally {
      setLoading(false);
    }
  };

  // After fetching entry, also fetch all titles for link resolution
  useEffect(() => {
    if (entry && entry.content) {
      console.log('Entry content:', entry.content);
      const titles = extractLinkedTitles(entry.content);
      console.log('Extracted titles:', titles);
      if (titles.length) {
        supabase
          .from('journal_entries')
          .select('id, title')
          .in('title', titles)
          .then(({ data }) => {
            console.log('Supabase title lookup result:', data);
            if (data) {
              const map: Record<string, string> = {};
              data.forEach((e: any) => {
                // Normalize to lower case and trim for matching
                map[e.title.toLowerCase().trim()] = e.id;
              });
              setLinkedTitleToId(map);
            }
          });
      }
    }
  }, [entry]);

  const extractLinkedTitles = (text: string): string[] => {
    const matches = text.match(/\[\[(.+?)\]\]/g);
    if (!matches) return [];
    return matches.map(m => m.slice(2, -2).trim()).filter(Boolean);
  };

  // Custom renderer for markdown to handle [[Entry Title]]
  const renderWithEntryLinks = (text: string) => {
    // Replace [[Title]] with links
    let out = text.replace(/\[\[(.+?)\]\]/g, (match, p1) => {
      const norm = p1.trim().toLowerCase();
      const id = linkedTitleToId[norm];
      if (id) {
        return `<a href="/journal/${id}" class="text-indigo-600 underline">[[${p1}]]</a>`;
      }
      return `<span class="text-gray-400">[[${p1}]]</span>`;
    });
    // Replace @[]() with links (legacy)
    out = out.replace(/@\[(.+?)\]\(\1\)/g, (match, p1) => {
      const norm = p1.trim().toLowerCase();
      const id = linkedTitleToId[norm];
      if (id) {
        return `<a href="/journal/${id}" class="text-indigo-600 underline">[[${p1}]]</a>`;
      }
      return `<span class="text-gray-400">[[${p1}]]</span>`;
    });
    return out;
  };

  const handleDeleteEntry = async () => {
    setShowDeleteModal(true);
  };

  const confirmDeleteEntry = async () => {
    try {
      if (!user || !id) return;
      const { error } = await supabase
        .from('journal_entries')
        .delete()
        .eq('id', id);
      if (error) {
        throw error;
      }
      navigate('/journal');
    } catch (error) {
      setDeleteError('Error deleting journal entry');
      setShowDeleteErrorModal(true);
      console.error('Error deleting journal entry:', error);
    } finally {
      setShowDeleteModal(false);
    }
  };

  const handleExport = () => {
    if (!entry) return;

    const markdown = `# ${entry.title}
Date: ${format(new Date(entry.created_at), 'MMMM d, yyyy')}
${entry.mood ? `Mood: ${entry.mood}` : ''}
${entry.tags?.length ? `Tags: ${entry.tags.join(', ')}` : ''}

${entry.content}`;

    downloadAsFile(markdown, `journal-${format(new Date(entry.created_at), 'yyyy-MM-dd')}`);
  };

  const handleShare = async () => {
    if (!entry) return;
    try {
      const markdown = `# ${entry.title}\n${entry.content}`;
      await navigator.clipboard.writeText(markdown);
      setShowCopyToast(true);
      setTimeout(() => setShowCopyToast(false), 2000);
    } catch (error) {
      setDeleteError('Failed to copy journal entry to clipboard');
      setShowDeleteErrorModal(true);
      console.error('Error sharing journal entry:', error);
    }
  };

  const handleAnalyze = async () => {
    if (!isSubscribed) {
      setShowSubscribeModal(true);
      return;
    }
    setAnalysisLoading(true);
    setAnalysisResult('');
    try {
      const session = await supabase.auth.getSession();
      const accessToken = session.data.session?.access_token;
      if (!accessToken) throw new Error('No access token');
      const result = await generateJournalAnalysisWithAIProxy(entry.content, accessToken, analysisType, customAnalysisPrompt);
      setAnalysisResult(result);
    } catch (e) {
      setAnalysisResult('Could not generate analysis. Try again!');
    } finally {
      setAnalysisLoading(false);
    }
  };
  const handleSaveAnalysis = async () => {
    if (!user || !id) return;
    const newAnalysis = {
      journal_entry_id: id,
      user_id: user.id,
      type: analysisType,
      prompt: analysisType === 'custom' ? customAnalysisPrompt : analysisType,
      result: analysisResult,
      created_at: new Date().toISOString(),
    };
    // Insert into DB
    const { data, error } = await supabase
      .from('journal_entry_analyses')
      .insert([newAnalysis])
      .select()
      .single();
    if (!error && data) {
      setAnalysisHistory([data, ...analysisHistory]);
      setShowAnalysisModal(false);
    }
  };
  const handleCopyAnalysis = async () => {
    await navigator.clipboard.writeText(analysisResult);
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-300">Loading journal entry...</p>
      </div>
    );
  }

  if (error || !entry) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Error</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">{error || 'Entry not found'}</p>
        <Link to="/journal">
          <Button variant="primary" leftIcon={<ArrowLeft size={16} />}>
            Back to Journal
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <Link to="/journal" className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
          <ArrowLeft size={16} className="mr-1" />
          Back to Journal
        </Link>
      </div>
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-2 md:gap-0 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="text-3xl font-bold mb-1 leading-tight">{entry.title && entry.title.trim() ? entry.title : 'Untitled Entry'}</CardTitle>
              <div className="flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400 gap-2">
                <Calendar size={14} className="mr-1" />
                <span>{format(new Date(entry.created_at), 'MMMM d, yyyy • h:mm a')}</span>
                {entry.mood && (
                  <span className="ml-3 px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/40 text-indigo-800 dark:text-indigo-200 font-medium text-xs flex items-center">
                    {entry.mood}
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-wrap gap-2 md:justify-end mt-4 md:mt-0">
              <Button variant="outline" leftIcon={<Lotus size={16} />} size="sm" onClick={() => setShowIntentGenerator(true)}>
                Create Sequence
              </Button>
              <Link to={`/journal/edit/${entry.id}`}>
                <Button variant="outline" leftIcon={<Edit size={16} />} size="sm">Edit</Button>
              </Link>
              <Button variant="outline" leftIcon={<Download size={16} />} size="sm" onClick={handleExport}>Export</Button>
              <Button variant="outline" leftIcon={<Share2 size={16} />} size="sm" onClick={handleShare}>Share</Button>
              <Button variant="outline" leftIcon={<Trash2 size={16} />} size="sm" className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30" onClick={handleDeleteEntry}>Delete</Button>
            </div>
          </div>
        </CardHeader>
        <hr className="border-t border-gray-200 dark:border-gray-700 mx-6" />
        <CardContent className="py-8">
          <div className="prose prose-lg prose-indigo dark:prose-invert max-w-none mb-8 prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700">
            <ReactMarkdown
              className="prose prose-indigo dark:prose-invert max-w-none whitespace-pre-line prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700"
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeRaw]}
              components={{
                a: ({ href, children }) => (
                  <a href={href} target="_blank" rel="noopener noreferrer" className="text-indigo-600 underline">
                    {children}
                  </a>
                ),
              }}
              // Use children as HTML with entry links
              children={renderWithEntryLinks(entry.content)}
              skipHtml={false}
              // allowDangerousHtml is deprecated, but we want HTML rendering
            />
          </div>
          {entry.tags && entry.tags.length > 0 && (
            <div className="pt-6 mt-8 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center mb-2">
                <Tag size={18} className="mr-2 text-gray-500 dark:text-gray-400" />
                <span className="font-medium text-gray-700 dark:text-gray-300">Tags:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {entry.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="inline-block bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-sm shadow-sm border border-gray-200 dark:border-gray-600"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
          {/* Chat-style Analysis History */}
          <div className="mt-10">
            <div className="flex items-center gap-3 mb-4">
              <h3 className="text-xl font-bold">AI Analyses</h3>
              <Button variant="outline" onClick={() => setShowAnalysisModal(true)} size="sm">Analyze My Entry</Button>
            </div>
            {analysisHistory.length === 0 ? (
              <div className="text-gray-500 italic mb-4">No analyses yet. Click "Analyze My Entry" to get started!</div>
            ) : (
              <ul className="flex flex-col gap-4">
                {analysisHistory.map((a, i) => {
                  const isExpanded = expandedAnalysis === i;
                  const summary = a.result.split('\n')[0].slice(0, 120) + (a.result.length > 120 ? '...' : '');
                  return (
                    <li key={i} className={`relative group transition-all ${isExpanded ? 'shadow-lg scale-[1.02]' : 'shadow'} bg-white dark:bg-gray-900 rounded-2xl border border-indigo-100 dark:border-indigo-800 p-4 cursor-pointer`}>
                      <div className="flex items-center gap-2" onClick={() => setExpandedAnalysis(isExpanded ? null : i)}>
                        <span className="inline-block w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-800 flex items-center justify-center text-lg font-bold mr-2">
                          {a.type === 'dream' ? '💤' : a.type === 'emotional' ? '💖' : a.type === 'cognitive' ? '🧠' : a.type === 'spiritual' ? '✨' : a.type === 'advice' ? '📝' : a.type === 'relationship' ? '🤝' : '🤔'}
                        </span>
                        <div className="flex-1">
                          <div className="font-semibold text-indigo-700 dark:text-indigo-200">{a.type === 'custom' ? a.prompt : a.type.charAt(0).toUpperCase() + a.type.slice(1) + ' Analysis'}</div>
                          <div className="text-xs text-gray-500">{a.created_at && new Date(a.created_at).toLocaleString()}</div>
                        </div>
                        <button type="button" className="ml-2 text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-200" aria-label="Expand/collapse">
                          {isExpanded ? '▲' : '▼'}
                        </button>
                        <button
                          type="button"
                          className="ml-2 text-red-400 hover:text-red-600 dark:hover:text-red-300"
                          aria-label="Delete analysis"
                          onClick={async e => {
                            e.stopPropagation();
                            const analysis = analysisHistory[i];
                            if (analysis && analysis.id) {
                              await supabase.from('journal_entry_analyses').delete().eq('id', analysis.id);
                              setAnalysisHistory(analysisHistory.filter((_, idx) => idx !== i));
                              if (expandedAnalysis === i) setExpandedAnalysis(null);
                            }
                          }}
                        >
                          🗑️
                        </button>
                      </div>
                      <div className={`transition-all overflow-hidden ${isExpanded ? 'max-h-none mt-4' : 'max-h-0'} duration-300`}> {/* Collapsible content */}
                        <ReactMarkdown className="prose prose-indigo dark:prose-invert max-w-none whitespace-pre-line prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700" remarkPlugins={[remarkGfm]}>{a.result}</ReactMarkdown>
                      </div>
                      {!isExpanded && (
                        <div className="text-gray-600 dark:text-gray-300 mt-2 text-sm italic select-none">{summary}</div>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>
      {showIntentGenerator && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-2xl overflow-y-auto max-h-[90vh] scrollbar-none md:overflow-visible md:max-h-none">
            <IntentGenerator
              content={entry.content}
              journalId={entry.id}
              onClose={() => setShowIntentGenerator(false)}
            />
          </div>
        </div>
      )}
      <Modal open={showAnalysisModal} onClose={() => setShowAnalysisModal(false)} title="Journal Entry Analysis" maxWidth="max-w-2xl"
        actions={analysisResult && <>
          <Button variant="primary" onClick={handleSaveAnalysis} disabled={!analysisResult}>Save to History</Button>
          <Button variant="outline" onClick={handleCopyAnalysis} disabled={!analysisResult}>Copy</Button>
          <Button variant="outline" onClick={handleAnalyze} isLoading={analysisLoading}>Reroll</Button>
        </>}
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-2 items-center w-full">
            <label className="font-semibold">Analysis Type:</label>
            <select
              value={analysisType}
              onChange={e => setAnalysisType(e.target.value)}
              className="rounded px-2 py-1 border flex-1 min-w-0 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100"
            >
              <option value="dream">Dream Analysis</option>
              <option value="emotional">Emotional Analysis</option>
              <option value="cognitive">Cognitive Patterns</option>
              <option value="spiritual">Spiritual/Archetypal</option>
              <option value="advice">Actionable Advice</option>
              <option value="relationship">Relationship Dynamics</option>
              <option value="custom">Custom...</option>
            </select>
            {analysisType === 'custom' && (
              <input
                type="text"
                value={customAnalysisPrompt}
                onChange={e => setCustomAnalysisPrompt(e.target.value)}
                placeholder="Enter your custom analysis prompt..."
                className="px-2 py-1 border rounded flex-1 min-w-0 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100"
              />
            )}
            <Button
              type="button"
              variant="primary"
              onClick={handleAnalyze}
              isLoading={analysisLoading}
              disabled={analysisLoading || !entry.content.trim()}
              className="flex-shrink-0"
            >
              Analyze
            </Button>
          </div>
          {analysisResult && (
            <div className="bg-white dark:bg-gray-950 rounded-xl border border-indigo-200 dark:border-indigo-800 shadow p-4 text-left">
              <div className="font-semibold mb-2">AI Analysis:</div>
              <ReactMarkdown className="prose prose-indigo dark:prose-invert max-w-none prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700" remarkPlugins={[remarkGfm]}>{analysisResult}</ReactMarkdown>
            </div>
          )}
        </div>
      </Modal>
      <Modal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Journal Entry"
        actions={
          <>
            <Button variant="danger" onClick={confirmDeleteEntry}>Delete</Button>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
          </>
        }
      >
        Are you sure you want to delete this journal entry?
      </Modal>
      <Modal
        open={showDeleteErrorModal}
        onClose={() => setShowDeleteErrorModal(false)}
        title="Error"
        actions={<Button variant="primary" onClick={() => setShowDeleteErrorModal(false)}>OK</Button>}
      >
        {deleteError}
      </Modal>
      {showCopyToast && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-primary-600 text-white px-6 py-3 rounded-full shadow-lg z-50 animate-fade-in">
          Journal entry copied to clipboard!
        </div>
      )}
      <Modal
        open={showSubscribeModal}
        onClose={() => setShowSubscribeModal(false)}
        title="Subscribe to Unlock AI Analysis"
        actions={<Button variant="primary" onClick={() => { setShowSubscribeModal(false); navigate('/pricing'); }}>View Plans & Pricing</Button>}
      >
        <div className="text-lg mb-2">AI-powered journal analysis is available for subscribers only.</div>
        <div className="text-gray-500">Upgrade your plan to unlock deep insights and personalized analysis for your journal entries.</div>
      </Modal>
    </div>
  );
};

export default JournalEntryPage;