import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { Plus, BookOpen, Edit, Trash2, Calendar, Search } from 'lucide-react';
import Input from '../components/Input';
import Modal from '../components/Modal';
import { useSubscription } from '../hooks/useSubscription';

interface JournalEntry {
  id: string;
  created_at: string;
  title: string;
  content: string;
  user_id: string;
  mood: string | null;
  tags: string[] | null;
}

const JournalPage: React.FC = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<JournalEntry[]>([]);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [entryToDelete, setEntryToDelete] = useState<string | null>(null);
  const { isSubscribed } = useSubscription();

  useEffect(() => {
    if (user) {
      fetchEntries();
    } else {
      setLoading(false);
    }
    // Listen for journal-updated event
    const handleJournalUpdated = () => {
      fetchEntries();
    };
    window.addEventListener('journal-updated', handleJournalUpdated);
    return () => {
      window.removeEventListener('journal-updated', handleJournalUpdated);
    };
  }, [user]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setSearchResults(entries);
    } else {
      const filtered = entries.filter(
        entry =>
          entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (entry.mood && entry.mood.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (entry.tags && entry.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
      );
      setSearchResults(filtered);
    }
  }, [searchQuery, entries]);

  // Polling: re-fetch entries if any are missing AI fields
  useEffect(() => {
    if (!user || !isSubscribed) return;
    const hasIncomplete = entries.some(entry => !entry.title || !entry.mood || !entry.tags || entry.tags.length === 0);
    if (!hasIncomplete) return;
    const interval = setInterval(() => {
      fetchEntries();
    }, 5000);
    return () => clearInterval(interval);
  }, [user, isSubscribed, entries]);

  const fetchEntries = async () => {
    try {
      setLoading(true);
      if (!user) return;

      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      if (data) {
        setEntries(data);
        setSearchResults(data);
      }
    } catch (error) {
      console.error('Error fetching journal entries:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEntry = async (id: string) => {
    setEntryToDelete(id);
    setShowDeleteModal(true);
  };

  const confirmDeleteEntry = async () => {
    if (!entryToDelete) return;
    try {
      const { error } = await supabase
        .from('journal_entries')
        .delete()
        .eq('id', entryToDelete);
      if (error) {
        throw error;
      }
      setEntries(entries.filter(entry => entry.id !== entryToDelete));
      setSearchResults(searchResults.filter(entry => entry.id !== entryToDelete));
    } catch (error) {
      console.error('Error deleting journal entry:', error);
    } finally {
      setShowDeleteModal(false);
      setEntryToDelete(null);
    }
  };

  // Function to truncate content for preview
  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  // Show all entries, even if the title is blank
  const visibleEntries = searchResults;

  if (!user) {
    return (
      <div className="text-center py-12">
        <BookOpen size={64} className="mx-auto text-gray-400 mb-6" />
        <h2 className="text-2xl font-bold mb-4">Please Log In to Access Your Journal</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
          Your journal entries are private and require an account for secure access.
        </p>
        <div className="flex justify-center space-x-4">
          <Link to="/login">
            <Button variant="primary">Log In</Button>
          </Link>
          <Link to="/register">
            <Button variant="outline">Create Account</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Your Journal</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            Reflect, remember, and track your mindfulness journey
          </p>
        </div>
        <div className="flex space-x-4">
          <Link to="/journal/new">
            <Button variant="primary" leftIcon={<Plus size={16} />}>
              New Entry
            </Button>
          </Link>
        </div>
      </div>

      <div className="mb-6">
        <Input
          placeholder="Search journal entries..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-lg"
          icon={<Search size={18} />}
        />
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading your journal entries...</p>
        </div>
      ) : searchResults.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <BookOpen size={64} className="mx-auto text-gray-400 mb-6" />
            {entries.length === 0 ? (
              <>
                <h2 className="text-2xl font-bold mb-4">Your Journal Is Empty</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
                  Start documenting your thoughts, feelings, and experiences today.
                </p>
              </>
            ) : (
              <>
                <h2 className="text-2xl font-bold mb-4">No Results Found</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
                  We couldn't find any entries matching your search.
                </p>
              </>
            )}
            <Link to="/journal/new">
              <Button variant="primary" leftIcon={<Plus size={16} />}>
                Create Your First Entry
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {visibleEntries.map((entry) => {
            const aiGenerating = isSubscribed && (!entry.title || !entry.mood || !entry.tags || entry.tags.length === 0);
            return (
              <Card
                key={entry.id}
                className={`transition-all duration-300 hover:shadow-md hover:-translate-y-1 ${aiGenerating ? 'opacity-60 pointer-events-none' : ''}`}
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    {(!entry.title || !entry.title.trim()) ? (
                      aiGenerating ? (
                        <div className="flex items-center space-x-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-500" />
                          <span className="text-indigo-600 dark:text-indigo-300 text-base font-medium">AI is generating title...</span>
                        </div>
                      ) : (
                        <CardTitle className="text-xl text-gray-400">Untitled Entry</CardTitle>
                      )
                    ) : (
                      <CardTitle className="text-xl">{entry.title}</CardTitle>
                    )}
                  </div>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <Calendar size={14} className="mr-1" />
                    <span>{format(new Date(entry.created_at), 'MMM d, yyyy')}</span>
                  </div>
                </CardHeader>
                <CardContent className="py-4">
                  {aiGenerating ? (
                    <div className="flex flex-col items-center justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mb-2" />
                      <span className="text-indigo-600 dark:text-indigo-300 text-sm">AI is generating details...</span>
                    </div>
                  ) : (
                    <>
                      <div className="prose prose-sm dark:prose-invert max-w-none">
                        <p className="text-gray-600 dark:text-gray-300">
                          {truncateContent(entry.content)}
                        </p>
                      </div>
                      {entry.tags && entry.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-4">
                          {entry.tags.map((tag, i) => (
                            <span
                              key={i}
                              className="inline-block bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 text-xs px-2 py-1 rounded-md"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                      {entry.mood && (
                        <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                          <div className="flex items-center">
                            <span className="text-sm font-medium text-gray-500 dark:text-gray-400 mr-2">
                              Mood:
                            </span>
                            <span className="text-sm">{entry.mood}</span>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
                <CardFooter className="pt-0 flex justify-between">
                  {!aiGenerating && (
                    <>
                      <Link to={`/journal/${entry.id}`}>
                        <Button variant="outline" leftIcon={<BookOpen size={16} />} size="sm">
                          Read
                        </Button>
                      </Link>
                      <div className="flex space-x-2">
                        <Link to={`/journal/edit/${entry.id}`}>
                          <Button variant="ghost" leftIcon={<Edit size={16} />} size="sm">
                            Edit
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          leftIcon={<Trash2 size={16} />}
                          size="sm"
                          className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30"
                          onClick={() => handleDeleteEntry(entry.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
      <Modal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Journal Entry"
        actions={
          <>
            <Button variant="danger" onClick={confirmDeleteEntry}>Delete</Button>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
          </>
        }
      >
        Are you sure you want to delete this journal entry?
      </Modal>
    </div>
  );
};

export default JournalPage;