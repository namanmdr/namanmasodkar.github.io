import { fnUrl } from '../lib/functions';
import React, { useState, useEffect, useRef, forwardRef } from 'react';
import { Link, useLocation, useParams, useNavigate } from 'react-router-dom'; // Add useParams here
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import Select from '../components/Select';
import TextArea from '../components/TextArea';
import { Clock, BarChart2, Check, ArrowRight, ArrowLeft, Play, Pause, AlertCircle, History, Trash2, Info, Edit2, Save, X, Download, Share2, Menu as MenuIcon, ChevronDown, ChevronUp } from 'lucide-react';
import { generateYogaSequence, type YogaSequence, type YogaPose, validateYogaSequence, sanitizeYogaSequence, createFallbackSequence, yogaSequenceJsonToMarkdown } from '../lib/yoga';
import { parseYogaSequence } from '../lib/yoga';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../hooks/useSubscription';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { exportToMarkdown, downloadAsFile } from '../lib/export';
import ReflectionPrompt from '../components/ReflectionPrompt';
import Modal from '../components/Modal';
import SequenceBuilder, { generateUniqueId } from '../components/SequenceBuilder';
import { YogaAIGenerator } from '../components/YogaAIGenerator';
import { YogaSequenceHistory } from '../components/YogaSequenceHistory';
import chimeSound from '../assets/chime.mp3'; // Place a gentle chime sound in src/assets/chime.mp3
import { poseDatabase } from '../lib/poses';
import { reportStripeUsage } from '../lib/stripe';
import parseDuration from '../utils/parseDuration'; // (You will create this util)

// Add this near the top of the file
const poseImages = import.meta.glob('../assets/poses/*.png', { eager: true, query: '?url', import: 'default' });

interface SavedSequence {
  id: string;
  created_at: string;
  title: string;
  duration: number;
  level: string;
  intent: string;
  sequence: YogaSequence;
  completed: boolean;
}

function normalizePoseName(name: string) {
  return name
    .toLowerCase()
    .replace(/[-_ ]+/g, '')
    .replace(/[^a-z0-9]/g, '');
}

// Add this at the top of the file for TypeScript
// Declare fbq for Meta Pixel
declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
  }
}

const YogaPage: React.FC = () => {
  // All useState/useEffect hooks must be at the top, before any logic or style injection
  const { user } = useAuth();
  const { id } = useParams(); // Add this
  const { isSubscribed, loading: subLoading } = useSubscription();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'ai' | 'manual'>('ai');
  const [loading, setLoading] = useState(false);
  const [sequence, setSequence] = useState<YogaSequence | null>(null);
  const [sequenceDbTitle, setSequenceDbTitle] = useState<string>('');
  const [currentSequenceId, setCurrentSequenceId] = useState<string | null>(null);
  const [duration, setDuration] = useState('20');
  const [level, setLevel] = useState('intermediate');
  const [intent, setIntent] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [savedSequences, setSavedSequences] = useState<SavedSequence[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showReflection, setShowReflection] = useState(false);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [currentPoseIndex, setCurrentPoseIndex] = useState(0);
  const [remainingTime, setRemainingTime] = useState(0);
  const [timerRunning, setTimerRunning] = useState(false);
  const [editingTitleId, setEditingTitleId] = useState<string | null>(null);
  const [editedTitle, setEditedTitle] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [sequenceToDelete, setSequenceToDelete] = useState<string | null>(null);
  const [showDeleteErrorModal, setShowDeleteErrorModal] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [showCopyToast, setShowCopyToast] = useState(false);
  const [showCustomIntent, setShowCustomIntent] = useState(false);
  const [freeYogaUsed, setFreeYogaUsedState] = useState<boolean | null>(null);
  const [freeYogaLoading, setFreeYogaLoading] = useState<boolean>(false);
  const [surpriseIntent, setSurpriseIntent] = useState<string>('');
  const [isSurprising, setIsSurprising] = useState(false);
  const [showSurpriseModal, setShowSurpriseModal] = useState(false);
  const [autoplayEnabled, setAutoplayEnabled] = useState(false);
  const [inTransition, setInTransition] = useState(false);
  const [transitionTimeLeft, setTransitionTimeLeft] = useState(20);
  const [timerEndedVisual, setTimerEndedVisual] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null); // Will become ttsRef
  const chimeRef = useRef<HTMLAudioElement | null>(null);
  const [poseSidebarOpen, setPoseSidebarOpen] = useState(false);
  // Ref for practice card height
  const practiceCardRef = useRef<HTMLDivElement>(null);
  const [practiceCardHeight, setPracticeCardHeight] = useState<number | undefined>(undefined);
  // For auto-scroll to active pose
  const poseButtonRefs = useRef<(HTMLButtonElement | null)[][]>([]);
  // Ref and state for sidebar header height
  const sidebarHeaderRef = useRef<HTMLDivElement>(null);
  const [sidebarHeaderHeight, setSidebarHeaderHeight] = useState<number>(0);
  // In YogaPage component, add state for toggling full sequence details
  const [showFullSequenceDetails, setShowFullSequenceDetails] = useState(true);
  const generatorRef = useRef<any>(null);
  // Replace the Web Speech API state variables with OpenAI TTS
  const [audioLoading, setAudioLoading] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [playAudio, setPlayAudio] = useState(false);
  const [ttsVoices, setTtsVoices] = useState<string[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('nova'); // Default to female voice
  const [audioGeneratedMsg, setAudioGeneratedMsg] = useState(false);
  // Track if audio has been generated for the current sequence
  const [audioGenerated, setAudioGenerated] = useState(false);
  const [pendingAutoStart, setPendingAutoStart] = useState(false);
  // Add a flag to track if the last pose timer was running
  const [lastPoseTimerWasRunning, setLastPoseTimerWasRunning] = useState(false);
  // Add state for pricing modal
  const [showPricingModal, setShowPricingModal] = useState(false);
  const hasGeneratedIntent = useRef(false);
  // Store the journalId from the data param if present
  const [linkedJournalId, setLinkedJournalId] = useState<string | null>(null);
  const [manualEditSequence, setManualEditSequence] = useState<SavedSequence | null>(null);
  // In the AI generator area, replace the Select for duration with an Input that allows free text, but also shows suggestions
  const [durationText, setDurationText] = useState(duration);
  const parsedDuration = parseDuration(durationText);

  // Initialize TTS voices
  useEffect(() => {
    // OpenAI TTS voices - focusing on female voices for yoga instruction
    const voices = [
      'nova',      // Female voice - bright and friendly (recommended)
      'shimmer',   // Female voice - clear and articulate
    ];
    setTtsVoices(voices);
  }, []);

  // Generate entry/instructions script for a pose using AI-proxy
  async function generatePoseEntryScript(pose: YogaPose): Promise<string> {
    const prompt = `You are a gentle, experienced yoga teacher. Give a warm, spoken instruction for guiding a student into and through ${pose.name} (${pose.sanskritName}), including entry and breath cues. Do NOT mention how the student arrived in this pose, do NOT reference any previous pose, and do NOT mention transitioning out or moving to the next pose. Keep it under 20 seconds. Use a calm, nurturing tone.`;
    const { data: { session } } = await supabase.auth.getSession();
    const accessToken = session?.access_token;
    if (!accessToken) throw new Error('No access token');
    const response = await fetch(fnUrl('ai_proxy'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        messages: [{ role: 'user', content: prompt }],
        model: 'gpt-4.1',
        max_tokens: 300,
        temperature: 0.5,
      }),
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Failed to generate entry script');
    }
    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || '';
  }

  // Utility to get the next pose object (or null if at the end)
  function getNextPose(currentSectionIndex: number, currentPoseIndex: number, sequence: YogaSequence): YogaPose | null {
    if (!sequence) return null;
    const sections = sequence.sections;
    if (!sections?.length) return null;
    let sIdx = currentSectionIndex;
    let pIdx = currentPoseIndex + 1;
    if (pIdx < sections[sIdx].poses.length) {
      return sections[sIdx].poses[pIdx];
    } else if (sIdx + 1 < sections.length) {
      return sections[sIdx + 1].poses[0] || null;
    }
    return null;
  }

  // Generate transition script for a pose using AI-proxy, aware of next pose
  async function generatePoseTransitionScript(pose: YogaPose, nextPose: YogaPose | null): Promise<string> {
    const prompt = `You are a gentle, experienced yoga teacher. Give a short, spoken instruction for transitioning out of ${pose.name} (${pose.sanskritName}) and preparing to move to the next pose. Do NOT give instructions for the next pose itself, only guide the student out of the current pose. Keep it under 10 seconds. Use a gentle, encouraging tone.`;
    const { data: { session } } = await supabase.auth.getSession();
    const accessToken = session?.access_token;
    if (!accessToken) throw new Error('No access token');
    const response = await fetch(fnUrl('ai_proxy'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        messages: [{ role: 'user', content: prompt }],
        model: 'gpt-4.1',
        max_tokens: 100,
        temperature: 0.5,
      }),
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Failed to generate transition script');
    }
    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || '';
  }

  // Generate TTS audio using OpenAI's TTS through ai-proxy (unchanged)
  async function generateTTSAudio(text: string, voice: string): Promise<string> {
    // Debug: log character count and estimated tokens
    const charCount = text.length;
    const tokensUsed = charCount * 4; // CHANGED from 13 to 4
    console.log(`[TTS DEBUG] Generating TTS for text (${charCount} chars, ~${tokensUsed} tokens):`, text);
    const { data: { session } } = await supabase.auth.getSession();
    const accessToken = session?.access_token;
    if (!accessToken) throw new Error('No access token');
    const requestBody = {
      messages: [{ role: 'user', content: 'Generate TTS audio' }],
      tts: {
        text: text,
        voice: voice,
        model: 'tts-1',
        response_format: 'mp3',
        speed: 1.0
      }
    };
    const response = await fetch(fnUrl('ai_proxy'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Failed to generate TTS audio');
    }
    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);
    return audioUrl;
  }

  // Generate audio for all poses using OpenAI TTS (entry and transition)
  async function handleGenerateAudio() {
    if (!sequence) {
      console.error('Sequence not available');
      return;
    }
    setAudioLoading(true);
    setAudioProgress(0);
    let totalPoses = sequence.sections.reduce((sum, s) => sum + s.poses.length, 0);
    let done = 0;
    let totalChars = 0;
    let totalTokens = 0;
    try {
      for (let sIdx = 0; sIdx < sequence.sections.length; sIdx++) {
        const section = sequence.sections[sIdx];
        for (let pIdx = 0; pIdx < section.poses.length; pIdx++) {
          const pose = section.poses[pIdx] as YogaPose;
          try {
            // 1. Generate entry script
            const entryScript = await generatePoseEntryScript(pose);
            totalChars += entryScript.length;
            totalTokens += entryScript.length * 4; // CHANGED from 13 to 4
            // 2. Generate entry TTS audio
            const entryAudioUrl = await generateTTSAudio(entryScript, selectedVoice);
            pose.audioEntryUrl = entryAudioUrl;
            // 3. Generate transition script (aware of next pose)
            const nextPose = getNextPose(sIdx, pIdx, sequence);
            if (nextPose) {
              const transitionScript = await generatePoseTransitionScript(pose, nextPose);
              totalChars += transitionScript.length;
              totalTokens += transitionScript.length * 4; // CHANGED from 13 to 4
              // 4. Generate transition TTS audio
              const transitionAudioUrl = await generateTTSAudio(transitionScript, selectedVoice);
              pose.audioTransitionUrl = transitionAudioUrl;
            } else {
              pose.audioTransitionUrl = undefined;
            }
            done++;
            setAudioProgress(Math.round((done / totalPoses) * 100));
          } catch (error: any) {
            console.error(`Error generating audio for ${pose.name}:`, error);
            done++;
            setAudioProgress(Math.round((done / totalPoses) * 100));
          }
        }
      }
      setSequence({ ...sequence });
      setAudioGenerated(true);
      // Debug: log total chars and tokens for the sequence
      console.log(`[TTS DEBUG] Total TTS chars for sequence: ${totalChars}, estimated tokens: ${totalTokens}`);
      // REPORT TTS USAGE TO STRIPE
      // (Removed: usage reporting is now only in the backend ai-proxy)
    } catch (error: any) {
      console.error('Error in handleGenerateAudio:', error);
    } finally {
      setAudioLoading(false);
      setAudioProgress(100);
    }
  }

  // Cleanup audio URLs to prevent memory leaks
  const cleanupAudioUrls = () => {
    if (sequence) {
      for (const section of sequence.sections) {
        for (const pose of section.poses as YogaPose[]) {
          if (pose.audioEntryUrl) {
            URL.revokeObjectURL(pose.audioEntryUrl);
            pose.audioEntryUrl = undefined;
          }
          if (pose.audioTransitionUrl) {
            URL.revokeObjectURL(pose.audioTransitionUrl);
            pose.audioTransitionUrl = undefined;
          }
        }
      }
    }
  };

  // Cleanup audio URLs when component unmounts
  useEffect(() => {
    return () => {
      cleanupAudioUrls();
    };
  }, []);

  // Helper to play entry audio for the current pose
  function playEntryAudio() {
    if (playAudio && sequence) {
      const pose = sequence.sections?.[currentSectionIndex]?.poses?.[currentPoseIndex];
      if (pose?.audioEntryUrl && audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        audioRef.current.src = pose.audioEntryUrl;
        audioRef.current.play();
      }
    }
  }

  // Play transition audio after chime ends, if in transition and autoplay is enabled and playAudio is true
  useEffect(() => {
    // Handler for chime end
    const handleChimeEnded = () => {
      if (autoplayEnabled && inTransition && playAudio && sequence) {
        const pose = sequence.sections?.[currentSectionIndex]?.poses?.[currentPoseIndex];
        if (pose?.audioTransitionUrl && audioRef.current) {
          audioRef.current.pause();
          audioRef.current.currentTime = 0;
          audioRef.current.src = pose.audioTransitionUrl;
          audioRef.current.play();
        }
      }
    };
    const chime = chimeRef.current;
    if (chime) {
      chime.addEventListener('ended', handleChimeEnded);
    }
    return () => {
      if (chime) {
        chime.removeEventListener('ended', handleChimeEnded);
      }
    };
  }, [autoplayEnabled, inTransition, playAudio, currentSectionIndex, currentPoseIndex, sequence]);

  useEffect(() => {
    function updateHeight() {
      if (practiceCardRef.current) {
        setPracticeCardHeight(practiceCardRef.current.offsetHeight);
      }
    }
    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, [sequence, currentSectionIndex, currentPoseIndex, inTransition, timerRunning, remainingTime]);

  useEffect(() => {
    if (sidebarHeaderRef.current) {
      setSidebarHeaderHeight(sidebarHeaderRef.current.offsetHeight);
    }
  }, [poseSidebarOpen]);

  // Add preset intents
  const PRESET_INTENTS = [
    'Release Stress',
    'Boost Energy',
    'Find Calm',
    'Sleep Better',
    'Improve Flexibility',
  ];

  // Add this useEffect to load the sequence when an ID is provided
  useEffect(() => {
    if (id && user) {
      loadSequenceById(id);
    }
  }, [id, user]);

  // --- RESTORED OLD FLOW: Auto-generate sequence from journal entry if data param is present ---
  // This useEffect triggers only when the user lands on the Yoga page with a ?data=... param (from a journal entry).
  // It uses ai-proxy for both intent extraction (from journal content and intent type) and yoga sequence generation.
  // The flow is seamless: user lands on the page and the sequence is generated and saved automatically, with linkage to the originating journal entry.
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const encodedData = params.get('data');
    const durationParam = params.get('duration');
    const levelParam = params.get('level');

    if (encodedData && durationParam && levelParam && !hasGeneratedIntent.current) {
      try {
        const data = JSON.parse(atob(encodedData));
        // If intentType, intentLabel, and content are present, generate the intention using ai-proxy
        if (data.intentType && data.intentLabel && data.content) {
          setDuration(durationParam);
          setLevel(levelParam);
          setIntent(''); // Clear intent while loading
          setLoading(true);
          setShowCustomIntent(true); // Ensure custom intent field is visible
          hasGeneratedIntent.current = true;
          if (data.journalId) setLinkedJournalId(data.journalId);
          (async () => {
            try {
              const { data: sessionData } = await supabase.auth.getSession();
              const accessToken = sessionData.session?.access_token;
              if (!accessToken) throw new Error('No access token');
              const prompt = `Based on this journal entry:\n\n"${data.content}"\n\nAnd considering the intention type "${data.intentLabel}",\n\nCreate a focused, specific yoga intention (2-3 sentences) that addresses the themes and emotions in the entry while aligning with the chosen intention type.\n\nONLY return the intent text, no explanations or other text.`;
              const response = await fetch(fnUrl('ai_proxy'), {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${accessToken}`,
                },
                body: JSON.stringify({
                  messages: [{ role: 'user', content: prompt }],
                  model: 'gpt-4.1',
                  max_tokens: 128,
                  temperature: 0.7,
                }),
              });
              const aiData = await response.json();
              let generated = aiData.choices?.[0]?.message?.content?.trim() || '';
              generated = generated.replace(/^['"]+|['"]+$/g, '');
              setIntent(generated);
              setShowCustomIntent(true); // Ensure custom intent is selected
            } catch (e) {
              setIntent('');
            } finally {
              setLoading(false);
            }
          })();
          return;
        }
      } catch (e) {
        // ignore
      }
    }
    // ... keep any other logic for other cases ...
    // eslint-disable-next-line
  }, [location.search]);

  useEffect(() => {
    const loadFreeYogaUsed = async () => {
      if (!user) {
        setFreeYogaUsedState(null);
        setFreeYogaLoading(false);
        return;
      }
      
      // If subscribed, set to false (no free usage tracking needed)
      if (isSubscribed) {
        setFreeYogaUsedState(false);
        setFreeYogaLoading(false);
        return;
      }
      
      setFreeYogaLoading(true);
      try {
        let used = false;
        try {
          const { data, error } = await supabase
            .from('user_settings')
            .select('free_yoga_used')
            .eq('user_id', user.id)
            .single();
          if (error) throw error;
          used = data?.free_yoga_used || false;
        } catch (err) {
          // If row missing, create it
          console.error('getFreeYogaUsed failed, attempting to create user_settings row:', err);
          const { error: insertError } = await supabase.from('user_settings').insert({
            user_id: user.id,
            free_yoga_used: false,
          });
          if (insertError) {
            console.error('Failed to create user_settings row:', insertError);
          }
          used = false;
        }
        setFreeYogaUsedState(!!used);
      } catch (err) {
        setFreeYogaUsedState(false); // fallback: allow free use
        console.error('Error loading freeYogaUsed:', err);
      } finally {
        setFreeYogaLoading(false);
      }
    };
    loadFreeYogaUsed();
  }, [user, isSubscribed]);

  const loadSequenceById = async (sequenceId: string) => {
    try {
      const { data, error } = await supabase
        .from('yoga_sessions')
        .select('*')
        .eq('id', sequenceId)
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;
      if (data) {
        let loadedSequence = data.sequence;
        
        // Validate the loaded sequence
        const validation = validateYogaSequence(loadedSequence);
        if (!validation.isValid) {
          console.warn('Loaded sequence has validation errors:', validation.errors);
          
          // Try to re-parse if we have raw markdown
          if (loadedSequence && loadedSequence.rawMarkdown) {
            const reparsedSections = parseYogaSequence(loadedSequence.rawMarkdown);
            if (reparsedSections.length && reparsedSections.some((s: any) => s.poses.length)) {
              loadedSequence = {
                ...loadedSequence,
                sections: reparsedSections
              };
              
              // Re-validate after re-parsing
              const revalidation = validateYogaSequence(loadedSequence);
              if (revalidation.isValid) {
                await supabase
                  .from('yoga_sessions')
                  .update({ sequence: loadedSequence })
                  .eq('id', data.id);
              } else {
                console.error('Sequence still invalid after re-parsing:', revalidation.errors);
                // Create a fallback sequence
                loadedSequence = createFallbackSequence(data.duration, data.level, data.intent || '');
              }
            } else {
              console.error('parseYogaSequence: No poses after re-parse. Raw markdown:', loadedSequence.rawMarkdown);
              // Create a fallback sequence
              loadedSequence = createFallbackSequence(data.duration, data.level, data.intent || '');
            }
          } else {
            // Create a fallback sequence if no raw markdown
            loadedSequence = createFallbackSequence(data.duration, data.level, data.intent || '');
          }
        } else {
          // Sanitize the sequence to ensure all fields are properly set
          loadedSequence = sanitizeYogaSequence(loadedSequence);
        }
        
        setSequence(loadedSequence);
        setSequenceDbTitle(data.title || '');
        setCurrentSequenceId(data.id);
        setCurrentSectionIndex(0);
        setCurrentPoseIndex(0);
      }
    } catch (error) {
      console.error('Error loading sequence:', error);
    }
  };

  useEffect(() => {
    if (subLoading) return; // Wait for subscription status to load
    const params = new URLSearchParams(location.search);
    const encodedData = params.get('data');
    const durationParam = params.get('duration');
    const levelParam = params.get('level');

    if (encodedData && durationParam && levelParam) {
      try {
        const data = JSON.parse(atob(encodedData));
        // setDuration(durationParam);
        //setLevel(levelParam);
        // handleGenerateSequence(data, durationParam, levelParam); // This function is removed
      } catch (error) {
        console.error('Error parsing URL data:', error);
      }
    }
  }, [location.search, subLoading]);

  useEffect(() => {
    if (user) {
      fetchSavedSequences();
    }
  }, [user]);

  // Helper: are we on the last pose?
  function isLastPose() {
    if (!sequence) return false;
    const lastSectionIdx = sequence.sections.length - 1;
    const lastPoseIdx = sequence.sections[lastSectionIdx].poses.length - 1;
    return currentSectionIndex === lastSectionIdx && currentPoseIndex === lastPoseIdx;
  }

  // Timer/transition logic
  useEffect(() => {
    let interval: number | undefined;
    let transitionInterval: number | undefined;

    if (timerRunning && remainingTime > 0) {
      interval = window.setInterval(() => {
        setRemainingTime(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            setTimerRunning(false);
            // Accessibility: Play chime, vibrate, visual
            if (chimeRef.current) {
              chimeRef.current.pause();
              chimeRef.current.currentTime = 0;
              chimeRef.current.play();
            }
            if (navigator.vibrate) {
              navigator.vibrate(300);
            }
            setTimerEndedVisual(true);
            setTimeout(() => setTimerEndedVisual(false), 1200);
            // Autoplay logic
            if (autoplayEnabled && !isLastPose()) {
              // Start transition, but do NOT move to next pose yet
              setInTransition(true);
              setTransitionTimeLeft(20);
            }
            // If last pose, do nothing (session complete)
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    // Autoplay transition countdown
    if (inTransition) {
      transitionInterval = window.setInterval(() => {
        setTransitionTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(transitionInterval);
            setInTransition(false);
            // Now move to next pose and set pendingAutoStart
            moveToNextPose();
            setPendingAutoStart(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
      if (transitionInterval) clearInterval(transitionInterval);
    };
  }, [timerRunning, remainingTime, inTransition, autoplayEnabled, currentSectionIndex, currentPoseIndex, sequence]);

  // useEffect to auto-start timer and play entry audio after pose index changes (autoplay)
  useEffect(() => {
    if (pendingAutoStart) {
      setPendingAutoStart(false);
      startPoseTimer();
    }
  }, [currentSectionIndex, currentPoseIndex]);

  const fetchSavedSequences = async () => {
    try {
      const { data, error } = await supabase
        .from('yoga_sessions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSavedSequences(data || []);
    } catch (error) {
      console.error('Error fetching saved sequences:', error);
    }
  };

  const durationOptions = [
    { value: '5', label: '5 minutes' },
    { value: '10', label: '10 minutes' },
    { value: '15', label: '15 minutes' },
    { value: '20', label: '20 minutes' },
    { value: '30', label: '30 minutes' },
    { value: '45', label: '45 minutes' },
    { value: '60', label: '60 minutes' }
  ];

  const levelOptions = [
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  const [streamingContent, setStreamingContent] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const streamingContentRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new streaming content
  useEffect(() => {
    if (isStreaming && streamingContentRef.current) {
      streamingContentRef.current.scrollTop = streamingContentRef.current.scrollHeight;
    }
  }, [streamingContent, isStreaming]);

  const handleStopStreaming = () => {
    setIsStreaming(false);
    // Optionally, you can add logic to abort the fetch if you use AbortController
  };

  // Handler to update a sequence title
  const handleEditTitle = async (id: string, newTitle: string) => {
    try {
      const { error } = await supabase
        .from('yoga_sessions')
        .update({ title: newTitle })
        .eq('id', id);
      if (error) throw error;
      setSavedSequences(sequences =>
        sequences.map(seq =>
          seq.id === id ? { ...seq, title: newTitle } : seq
        )
      );
    } catch (error) {
      console.error('Error updating sequence title:', error);
    }
  };

  // Handler to delete a sequence
  const handleDeleteSequence = async (id: string) => {
    try {
      const { error } = await supabase
        .from('yoga_sessions')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setSavedSequences(prev => prev.filter(seq => seq.id !== id));
    } catch (error) {
      setDeleteError('Error deleting sequence');
      setShowDeleteErrorModal(true);
      console.error('Error deleting sequence:', error);
    }
  };

  // Handler to export a sequence
  const handleExport = (sequence: any) => {
    const markdown = yogaSequenceJsonToMarkdown(sequence.sequence);
    downloadAsFile(markdown, `yoga-sequence-${format(new Date(sequence.created_at), 'yyyy-MM-dd')}`);
  };

  // Handler to share a sequence
  const handleShare = async (sequence: any) => {
    try {
      const markdown = yogaSequenceJsonToMarkdown(sequence.sequence);
      await navigator.clipboard.writeText(markdown);
      setShowCopyToast(true);
      setTimeout(() => setShowCopyToast(false), 2000);
    } catch (error) {
      setDeleteError('Failed to copy sequence to clipboard');
      setShowDeleteErrorModal(true);
      console.error('Error sharing sequence:', error);
    }
  };

  // Handler to load a saved sequence
  const handleLoadSequence = (savedSequence: any) => {
    setSequence(savedSequence.sequence);
    setSequenceDbTitle(savedSequence.title || '');
    setCurrentSequenceId(savedSequence.id);
    setCurrentSectionIndex(0);
    setCurrentPoseIndex(0);
    setShowHistory(false);
  };

  // Handler for when a new sequence is generated
  const handleSequenceGenerated = async (sequence: any) => {
    setSequence(sequence);
    setCurrentSectionIndex(0);
    setCurrentPoseIndex(0);
    setCurrentSequenceId(null);
    setSequenceDbTitle(sequence.title || '');
    // Link to journal entry if present
    if (linkedJournalId && user) {
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const accessToken = sessionData.session?.access_token;
        if (!accessToken) throw new Error('No access token');
        // Find the most recent yoga session for this user (just created)
        const { data: yogaSessions, error } = await supabase
          .from('yoga_sessions')
          .select('id')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1);
        if (error) throw error;
        const yogaSessionId = yogaSessions?.[0]?.id;
        if (yogaSessionId) {
          await supabase.from('practice_cycles').insert({
            pre_journal_id: linkedJournalId,
            yoga_session_id: yogaSessionId,
            user_id: user.id
          });
        }
      } catch (e) {
        console.error('Error linking yoga session to journal entry:', e);
      }
    }
  };

  const getCurrentPose = (): YogaPose | null => {
    if (!sequence || !sequence.sections[currentSectionIndex]) return null;
    return sequence.sections[currentSectionIndex].poses[currentPoseIndex] || null;
  };

  // In startPoseTimer, if on last pose, set lastPoseTimerWasRunning to true
  const startPoseTimer = () => {
    const pose = getCurrentPose();
    if (pose) {
      setRemainingTime(pose.durationInSeconds);
      setTimerRunning(true);
      if (isLastPose()) setLastPoseTimerWasRunning(true);
      if (playAudio) playEntryAudio();
      // Meta Pixel: Track StartYogaSession event
      if (window.fbq) window.fbq('track', 'StartYogaSession');
    }
  };

  const toggleTimer = () => {
    setTimerRunning(!timerRunning);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Update moveToNextPose and moveToPreviousPose to scroll the sidebar pose into view after navigation
  const moveToNextPose = () => {
    if (!sequence) return;
    let nextSectionIndex = currentSectionIndex;
    let nextPoseIndex = currentPoseIndex;
    const currentSection = sequence.sections[currentSectionIndex];
    if (currentPoseIndex < currentSection.poses.length - 1) {
      nextPoseIndex = currentPoseIndex + 1;
    } else if (currentSectionIndex < sequence.sections.length - 1) {
      nextSectionIndex = currentSectionIndex + 1;
      nextPoseIndex = 0;
    }
    setCurrentSectionIndex(nextSectionIndex);
    setCurrentPoseIndex(nextPoseIndex);
    setTimerRunning(false);
    setRemainingTime(0);
    // Scroll the selected pose into view
    setTimeout(() => {
      poseButtonRefs.current[nextSectionIndex]?.[nextPoseIndex]?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 0);
  };

  const moveToPreviousPose = () => {
    let prevSectionIndex = currentSectionIndex;
    let prevPoseIndex = currentPoseIndex;
    if (currentPoseIndex > 0) {
      prevPoseIndex = currentPoseIndex - 1;
    } else if (currentSectionIndex > 0) {
      prevSectionIndex = currentSectionIndex - 1;
      const prevSection = sequence?.sections[prevSectionIndex];
      if (prevSection) {
        prevPoseIndex = prevSection.poses.length - 1;
      }
    }
    setCurrentSectionIndex(prevSectionIndex);
    setCurrentPoseIndex(prevPoseIndex);
    setTimerRunning(false);
    setRemainingTime(0);
    // Scroll the selected pose into view
    setTimeout(() => {
      poseButtonRefs.current[prevSectionIndex]?.[prevPoseIndex]?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 0);
  };

  const getTotalPoses = () => {
    if (!sequence) return 0;
    return sequence.sections.reduce((total, section) => total + section.poses.length, 0);
  };

  const getCurrentPoseNumber = () => {
    if (!sequence) return 0;
    let total = 0;
    for (let i = 0; i < currentSectionIndex; i++) {
      total += sequence.sections[i].poses.length;
    }
    return total + currentPoseIndex + 1;
  };

  const markSequenceComplete = async () => {
    if (!currentSequenceId) return;
    
    try {
      const { error } = await supabase
        .from('yoga_sessions')
        .update({ completed: true })
        .eq('id', currentSequenceId);

      if (error) throw error;
      await fetchSavedSequences();
      setShowReflection(true);
    } catch (error) {
      console.error('Error marking sequence as complete:', error);
    }
  };

  const handlePoseSidebarJump = (sectionIdx: number, poseIdx: number) => {
    setCurrentSectionIndex(sectionIdx);
    setCurrentPoseIndex(poseIdx);
    setPoseSidebarOpen(false);
    setTimerRunning(false);
    setRemainingTime(0);
  };

  // --- PoseListSidebar component ---
  const PoseListSidebar: React.FC<{
    sections: any[];
    currentSectionIndex: number;
    currentPoseIndex: number;
    onJump: (sectionIdx: number, poseIdx: number) => void;
    sidebarHeight?: string | number;
    poseButtonRefs: React.MutableRefObject<(HTMLButtonElement | null)[][]>;
  }> = ({ sections, currentSectionIndex, currentPoseIndex, onJump, sidebarHeight = '80vh', poseButtonRefs }) => (
    <aside
      className="w-72 bg-indigo-50 dark:bg-indigo-900/20 rounded-l-2xl border-r border-indigo-100 dark:border-indigo-900 flex flex-col h-full min-h-0 overflow-hidden"
      style={{ height: sidebarHeight, minHeight: 0 }}
    >
      <div className="pt-4 pb-2 px-4 flex items-center justify-between border-b border-gray-200 dark:border-indigo-900 bg-indigo-50 dark:bg-indigo-900">
        <span className="font-bold text-lg text-indigo-700 dark:text-indigo-200">Pose List</span>
      </div>
      <div
        className="flex-1 overflow-y-auto min-h-0 p-2 pb-14 pose-list-scrollbar"
        style={{ direction: 'rtl', background: 'inherit' }}
      >
        <div style={{ direction: 'ltr' }}>
          {sections.map((section, sIdx) => (
            <div key={sIdx} className="mb-4">
              <div className="font-semibold text-indigo-600 dark:text-indigo-300 mb-2 text-sm uppercase tracking-wide">{section.title}</div>
              <ul className="space-y-1">
                {section.poses.map((pose: any, pIdx: number) => {
                  const isCurrent = sIdx === currentSectionIndex && pIdx === currentPoseIndex;
                  return (
                    <li key={pIdx}>
                      <button
                        ref={el => {
                          if (!poseButtonRefs.current[sIdx]) poseButtonRefs.current[sIdx] = [];
                          poseButtonRefs.current[sIdx][pIdx] = el;
                        }}
                        className={`w-full text-left px-3 py-2 rounded-lg transition-colors duration-200 ${isCurrent ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400 text-white font-bold shadow-lg' : 'hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-gray-800 dark:text-gray-200'}`}
                        onClick={() => onJump(sIdx, pIdx)}
                        disabled={isCurrent}
                      >
                        <span className="block truncate">{pose.name}</span>
                        <span className="block text-xs opacity-70">{pose.sanskritName}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );

  // --- PracticeCard component ---
  const PracticeCard = forwardRef<HTMLDivElement, {
    sequence: any;
    currentSectionIndex: number;
    currentPoseIndex: number;
    remainingTime: number;
    timerRunning: boolean;
    inTransition: boolean;
    transitionTimeLeft: number;
    timerEndedVisual: boolean;
    autoplayEnabled: boolean;
    onToggleAutoplay: () => void;
    onMoveToPreviousPose: () => void;
    onMoveToNextPose: () => void;
    onToggleTimer: () => void;
    onStartPoseTimer: () => void;
    formatTime: (seconds: number) => string;
    getCurrentPose: () => any;
    getTotalPoses: () => number;
    getCurrentPoseNumber: () => number;
    onMarkSequenceComplete: () => void;
    practiceCardHeight?: string | number;
    disabled?: boolean;
  }>(({
    sequence,
    currentSectionIndex,
    currentPoseIndex,
    remainingTime,
    timerRunning,
    inTransition,
    transitionTimeLeft,
    timerEndedVisual,
    autoplayEnabled,
    onToggleAutoplay,
    onMoveToPreviousPose,
    onMoveToNextPose,
    onToggleTimer,
    onStartPoseTimer,
    formatTime,
    getCurrentPose,
    getTotalPoses,
    getCurrentPoseNumber,
    onMarkSequenceComplete,
    practiceCardHeight = 'auto',
    disabled = false,
  }, ref) => {
    const totalPoses = getTotalPoses();
    const currentPoseNum = getCurrentPoseNumber();
    const pose = getCurrentPose();
    // Replace previous/next image state logic with a preload/crossfade strategy
    // Remove:
    //   - useState for displayedPose, nextPose, isFading, fadeDuration
    //   - useEffect for image transitions
    //   - logic for nextImageUrl, displayedImageUrl
    //   - rendering of two stacked images
    // Instead, just render the current pose image directly:

    // Helper to get the image URL for a pose
    function getPoseImageUrl(pose: any): string | undefined {
      let imageName = pose?.image;
      if (!imageName && pose) {
        const normalizedPoseName = normalizePoseName(pose.name || '');
        let foundPose;
        for (const category of poseDatabase) {
          foundPose = category.poses.find(p => normalizePoseName(p.name) === normalizedPoseName);
          if (foundPose && foundPose.image) {
            imageName = foundPose.image;
            break;
          }
        }
        if (!imageName && pose.sanskritName) {
          const normalizedSanskrit = normalizePoseName(pose.sanskritName);
          for (const category of poseDatabase) {
            foundPose = category.poses.find(p => normalizePoseName(p.sanskritName) === normalizedSanskrit);
            if (foundPose && foundPose.image) {
              imageName = foundPose.image;
              break;
            }
          }
        }
      }
      return imageName ? (poseImages[`../assets/poses/${imageName}`] as string | undefined) : undefined;
    }

    // Preload the next pose image as soon as pose changes
    // This useEffect is no longer needed as we are not crossfading
    // React.useEffect(() => {
    //   if (pose !== displayedPose) {
    //     setNextPose(pose);
    //     setIsFading(true);
    //     const timeout = setTimeout(() => {
    //       setDisplayedPose(pose);
    //       setIsFading(false);
    //     }, fadeDuration);
    //     return () => clearTimeout(timeout);
    //   }
    //   // eslint-disable-next-line
    // }, [pose]);

    // const displayedImageUrl = getPoseImageUrl(displayedPose);
    // const nextImageUrl = getPoseImageUrl(nextPose);

    return (
      <div
        ref={ref}
        className="w-full bg-indigo-50 dark:bg-indigo-900/20 md:rounded-r-2xl p-6 flex flex-col relative"
        style={{ height: practiceCardHeight, minHeight: 0 }}
      >
        <div className="text-center mb-6">
          <h3 className="text-xl font-bold mb-2">
            {sequence.sections[currentSectionIndex].title || ''}
          </h3>
        </div>
        {pose && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 w-full">
            {/* Main central area: pose name, image, timer, controls */}
            <div className="md:col-span-7 flex flex-col items-center justify-center">
              <div className="flex flex-col items-center flex-1 w-full">
                {/* Pose name, sanskrit, duration */}
                <h4 className="text-3xl font-bold mb-2">{pose.name || ''}</h4>
                <p className="text-indigo-600 dark:text-indigo-400 italic text-lg mb-2">
                  {pose.sanskritName || ''}
                </p>
                <p className="text-gray-600 dark:text-gray-300 mb-4 text-base">
                  {pose.duration || ''}
                </p>
                {/* Pose image fills available space */}
                <div className="flex-1 w-full flex items-center justify-center mb-4 relative" style={{ minHeight: 350 }}>
                  {(() => {
                    const imageUrl = getPoseImageUrl(pose);
                    return imageUrl ? (
                        <img
                          src={imageUrl}
                          alt={pose.name}
                          className="object-cover w-full h-[350px] aspect-square rounded-xl"
                        draggable={false}
                        />
                    ) : (
                      <div className="w-full h-[350px] aspect-square rounded-xl flex flex-col items-center justify-center text-gray-400 text-lg" style={{ background: 'none', border: 'none', padding: 0, margin: 0 }}>
                        <span className="text-base text-gray-500 dark:text-gray-300">Pose image will be added soon</span>
                      </div>
                    );
                  })()}
                </div>
                {/* Autoplay toggle button */}
                <div className="flex justify-center mb-4">
                  <Button
                    variant={autoplayEnabled ? 'primary' : 'outline'}
                    onClick={onToggleAutoplay}
                    size="sm"
                  >
                    {autoplayEnabled ? 'Autoplay: On' : 'Autoplay: Off'}
                  </Button>
                </div>
              </div>
              <div className={`bg-white dark:bg-gray-800 rounded-lg p-8 text-center transition-all duration-300 w-full relative ${timerEndedVisual ? 'timer-flash' : ''}`} style={{ minWidth: '360px', maxWidth: '520px', margin: '0 auto' }}>
                {/* Transition overlay */}
                {inTransition && (
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black bg-opacity-60 rounded-lg">
                    <div className="text-4xl md:text-5xl font-extrabold text-pink-300 animate-pulse mb-2 drop-shadow-lg">
                      Next pose in {transitionTimeLeft}s
                    </div>
                    <div className="text-lg text-white font-semibold">Get ready!</div>
                  </div>
                )}
                <div className={inTransition ? 'opacity-40 pointer-events-none select-none' : ''}>
                  <div className="text-5xl font-bold mb-6">
                    {remainingTime > 0 ? formatTime(remainingTime) : formatTime(pose.durationInSeconds ?? 0)}
                  </div>
                  <div className="flex justify-center space-x-3 mt-4">
                    <Button
                      variant="secondary"
                      className="w-28 h-12 rounded-full font-semibold flex items-center justify-center"
                      onClick={onMoveToPreviousPose}
                      disabled={disabled || inTransition}
                      leftIcon={<ArrowLeft size={18} />}
                    >
                      Previous
                    </Button>
                    <Button
                      variant={timerRunning ? "danger" : "primary"}
                      className="w-36 h-12 rounded-full font-semibold flex items-center justify-center shadow-lg"
                      leftIcon={timerRunning ? <Pause size={18} /> : <Play size={18} />}
                      onClick={remainingTime > 0 ? onToggleTimer : onStartPoseTimer}
                      disabled={disabled || inTransition}
                    >
                      {timerRunning ? "Pause" : remainingTime > 0 ? "Resume" : "Start Timer"}
                    </Button>
                    <Button
                      variant="secondary"
                      className="w-28 h-12 rounded-full font-semibold flex items-center justify-center"
                      onClick={onMoveToNextPose}
                      disabled={disabled || inTransition}
                      rightIcon={<ArrowRight size={18} />}
                    >
                      Next
                    </Button>
                  </div>
                  <div className="mt-6 text-sm text-gray-500 dark:text-gray-400">
                    Pose {currentPoseNum} of {totalPoses}
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-2">
                    <div
                      className="h-2.5 rounded-full transition-all duration-300 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400"
                      style={{ width: `${(currentPoseNum / totalPoses) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            {/* Instructions/benefits area */}
            <div className="md:col-span-5 space-y-6 flex flex-col justify-start">
              <div>
                <h5 className="font-medium text-gray-900 dark:text-gray-100 mb-3 flex items-center">
                  <Info size={18} className="mr-2" />
                  Instructions
                </h5>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  {(pose.instructions || []).map((instruction: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2 font-medium">{index + 1}.</span>
                      <span>{instruction}</span>
                    </li>
                  ))}
                </ul>
              </div>
              {pose.benefits && (
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <h5 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Benefits</h5>
                  <p className="text-gray-600 dark:text-gray-300">
                    {pose.benefits || ''}
                  </p>
                </div>
              )}
              {pose.intentRelation && (
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <h5 className="font-medium text-gray-900 dark:text-gray-100 mb-3">
                    Connection to Intent
                  </h5>
                  <p className="text-gray-600 dark:text-gray-300">
                    {pose.intentRelation || ''}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
        <div className="flex justify-center mt-8">
          <Button
            variant="primary"
            leftIcon={<Check size={16} />}
            onClick={onMarkSequenceComplete}
            disabled={disabled || inTransition}
          >
            Complete Practice
          </Button>
        </div>
      </div>
    );
  });

  // In renderSequence, update the layout for mobile/desktop sidebar behavior
  const renderSequence = () => {
    if (!sequence) return null;
    return (
      <div className="space-y-8 relative">
        {/* Top bar with title, intent, meta, and action buttons */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h2 className="text-3xl font-bold mb-1">{sequenceDbTitle || 'Untitled Sequence'}</h2>
            {sequence.intent && (
              <div className="text-indigo-600 dark:text-indigo-400 font-semibold mb-1">{sequence.intent}</div>
            )}
            <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
              <span className="flex items-center">
                <Clock size={16} className="mr-1" />
                {sequence.duration} minutes
              </span>
              <span className="flex items-center">
                <BarChart2 size={16} className="mr-1" />
                {sequence.level}
              </span>
            </div>
          </div>
          <div className="flex gap-2 mt-4 md:mt-0">
            <Button variant="outline" onClick={() => { generatorRef.current?.reset?.(); setSequence(null); }}>
              Create New Sequence
            </Button>
            <Button variant="outline" onClick={() => { setShowHistory(true); setSequence(null); }}>
              View History
            </Button>
            {/* Edit button for viewing mode */}
            <Button
              variant="outline"
              leftIcon={<Edit2 size={16} />}
              onClick={() => {
                // Find completed status from savedSequences if possible
                let completed = false;
                if (currentSequenceId) {
                  const found = savedSequences.find(seq => seq.id === currentSequenceId);
                  if (found && typeof found.completed === 'boolean') completed = found.completed;
                }
                setManualEditSequence({
                  ...sequence,
                  title: sequenceDbTitle || '', // Always use the DB title for editing
                  intent: sequence.intent || '',
                  level: sequence.level || '',
                  sequence: sequence,
                  created_at: new Date().toISOString(),
                  id: String(currentSequenceId ?? ''),
                  completed
                });
                setActiveTab('manual');
              }}
            >
              Edit
            </Button>
          </div>
        </div>
                {/* Add above the pose navigation/details area: */}
        <div className="flex flex-wrap gap-4 items-center mb-4">
          <Button 
            variant="primary"
            onClick={() => {
              if (!isSubscribed) {
                setShowPricingModal(true);
                return;
              }
              handleGenerateAudio();
            }}
            disabled={audioLoading || !sequence || audioGenerated}
          >
            {audioLoading ? `Generating Audio... (${audioProgress}%)` :
              audioGenerated ? 'Audio generated for all poses!' :
              sequence ? 'Generate Audio for All Poses' :
              'TTS Loading...'}
          </Button>
          
          {/* Voice Selector */}
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Voice:</label>
            <select 
              value={selectedVoice} 
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-sm"
              disabled={audioLoading}
            >
              <option value="nova">Nova (Bright & Friendly)</option>
              <option value="shimmer">Shimmer (Clear & Articulate)</option>
            </select>
          </div>
          
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={playAudio} onChange={e => setPlayAudio(e.target.checked)} />
            Play Audio at Each Pose
          </label>
          
          {audioLoading && <div className="w-40 h-2 bg-gray-200 rounded-full overflow-hidden"><div className="h-2 bg-indigo-500" style={{ width: `${audioProgress}%` }} /></div>}
        </div>
        {/* Pose navigation and details */}
        {sequence.sections.some(s => s.poses.length > 0) && (
          <div className="w-full flex justify-center">
            <div className="flex max-w-[1300px] w-full mx-auto items-start">
              {/* Desktop sidebar */}
              <div className="hidden md:block">
                <PoseListSidebar
                  sections={sequence.sections}
                  currentSectionIndex={currentSectionIndex}
                  currentPoseIndex={currentPoseIndex}
                  onJump={handlePoseSidebarJump}
                  sidebarHeight={practiceCardHeight ? `${practiceCardHeight}px` : 'auto'}
                  poseButtonRefs={poseButtonRefs}
                />
              </div>
              {/* Main practice card: full width on mobile, right of sidebar on desktop */}
              <div className="flex-1 relative">
                {/* Mobile sidebar toggle button (inside practice card area, top-left) */}
                <button
                  className="md:hidden absolute top-4 left-4 z-10 bg-indigo-600 text-white rounded-full p-3 shadow-lg focus:outline-none"
                  onClick={() => setPoseSidebarOpen(true)}
                  aria-label="Show Pose List"
                  style={{ display: poseSidebarOpen ? 'none' : undefined }}
                >
                  <MenuIcon size={28} />
                </button>
                <PracticeCard
                  ref={practiceCardRef}
                  sequence={sequence}
                  currentSectionIndex={currentSectionIndex}
                  currentPoseIndex={currentPoseIndex}
                  remainingTime={remainingTime}
                  timerRunning={timerRunning}
                  inTransition={inTransition}
                  transitionTimeLeft={transitionTimeLeft}
                  timerEndedVisual={timerEndedVisual}
                  autoplayEnabled={autoplayEnabled}
                  onToggleAutoplay={() => setAutoplayEnabled(a => !a)}
                  onMoveToPreviousPose={moveToPreviousPose}
                  onMoveToNextPose={moveToNextPose}
                  onToggleTimer={toggleTimer}
                  onStartPoseTimer={startPoseTimer}
                  formatTime={formatTime}
                  getCurrentPose={getCurrentPose}
                  getTotalPoses={getTotalPoses}
                  getCurrentPoseNumber={getCurrentPoseNumber}
                  onMarkSequenceComplete={markSequenceComplete}
                  practiceCardHeight="auto"
                  disabled={false}
                />
              </div>
            </div>
          </div>
        )}
        {/* Mobile sidebar overlay (rendered at top level, not inside .flex-1.relative) */}
        {poseSidebarOpen && (
          <div className="fixed left-0 right-0 top-16 bottom-0 z-40 flex md:hidden">
            <div className="w-72 max-w-full h-full bg-white dark:bg-indigo-950/95 shadow-2xl rounded-r-2xl border-r border-indigo-100 dark:border-indigo-900 flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-indigo-900">
                <span className="font-bold text-lg text-indigo-700 dark:text-indigo-200">Pose List</span>
                <button onClick={() => setPoseSidebarOpen(false)} className="text-gray-400 hover:text-indigo-500 text-2xl font-bold">&times;</button>
              </div>
              <div className="flex-1 overflow-y-auto p-2 pose-list-scrollbar" style={{ direction: 'rtl', background: 'inherit' }}>
                <div style={{ direction: 'ltr' }}>
                  {sequence?.sections.map((section, sIdx) => (
                    <div key={sIdx} className="mb-4">
                      <div className="font-semibold text-indigo-600 dark:text-indigo-300 mb-2 text-sm uppercase tracking-wide">{section.title}</div>
                      <ul className="space-y-1">
                        {section.poses.map((pose, pIdx) => {
                          const isCurrent = sIdx === currentSectionIndex && pIdx === currentPoseIndex;
                          return (
                            <li key={pIdx}>
                              <button
                                className={`w-full text-left px-3 py-2 rounded-lg transition-colors duration-200 ${isCurrent ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400 text-white font-bold shadow-lg' : 'hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-gray-800 dark:text-gray-200'}`}
                                onClick={() => { handlePoseSidebarJump(sIdx, pIdx); setPoseSidebarOpen(false); }}
                                disabled={isCurrent}
                              >
                                <span className="block truncate">{pose.name}</span>
                                <span className="block text-xs opacity-70">{pose.sanskritName}</span>
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            {/* Overlay to close sidebar */}
            <div className="flex-1 bg-black bg-opacity-30" onClick={() => setPoseSidebarOpen(false)} />
          </div>
        )}
        {sequence.rawMarkdown && (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mt-8">
            <button
              className="flex items-center text-gray-600 dark:text-gray-300 font-semibold text-base mb-4 focus:outline-none"
              onClick={() => setShowFullSequenceDetails(v => !v)}
              aria-expanded={showFullSequenceDetails}
              aria-controls="full-sequence-details-content"
            >
              <Info size={18} className="mr-2" />
              <span>Full Sequence Details</span>
              {showFullSequenceDetails ? (
                <ChevronUp size={20} className="ml-2" />
              ) : (
                <ChevronDown size={20} className="ml-2" />
              )}
            </button>
            <div
              id="full-sequence-details-content"
              className={`transition-opacity duration-300 ease-in-out overflow-hidden ${showFullSequenceDetails ? 'max-h-none opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}
            >
              <div className="prose prose-indigo dark:prose-invert max-w-none prose-headings:font-sora prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-h4:text-lg prose-blockquote:border-l-4 prose-blockquote:border-indigo-400 prose-blockquote:bg-indigo-50 dark:prose-blockquote:bg-indigo-900/20 prose-blockquote:italic prose-blockquote:text-gray-700 dark:prose-blockquote:text-gray-200 prose-li:marker:text-indigo-400 prose-table:border prose-table:border-indigo-200 dark:prose-table:border-indigo-700 prose-th:bg-indigo-50 dark:prose-th:bg-indigo-900/30 prose-code:bg-gray-100 dark:prose-code:bg-gray-800 prose-code:px-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-white prose-pre:rounded-xl prose-pre:p-4 prose-pre:p-4 prose-img:rounded-xl prose-img:shadow-lg prose-a:text-indigo-600 dark:prose-a:text-indigo-300 prose-a:underline prose-a:decoration-dotted prose-hr:my-8 prose-hr:border-indigo-200 dark:prose-hr:border-indigo-700">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{yogaSequenceJsonToMarkdown(sequence)}</ReactMarkdown>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderPoseSidebar = () => (
    <div className={`fixed top-0 left-0 h-full z-40 transition-transform duration-300 ${poseSidebarOpen ? 'translate-x-0' : '-translate-x-full'} bg-white dark:bg-indigo-950/95 shadow-2xl w-72 max-w-full flex flex-col`}>
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-indigo-900">
        <span className="font-bold text-lg text-indigo-700 dark:text-indigo-200">Pose List</span>
        <button onClick={() => setPoseSidebarOpen(false)} className="text-gray-400 hover:text-indigo-500 text-2xl font-bold">&times;</button>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {sequence?.sections.map((section, sIdx) => (
          <div key={sIdx} className="mb-4">
            <div className="font-semibold text-indigo-600 dark:text-indigo-300 mb-2 text-sm uppercase tracking-wide">{section.title}</div>
            <ul className="space-y-1">
              {section.poses.map((pose, pIdx) => {
                const isCurrent = sIdx === currentSectionIndex && pIdx === currentPoseIndex;
                return (
                  <li key={pIdx}>
                    <button
                      className={`w-full text-left px-3 py-2 rounded-lg transition-colors duration-200 ${isCurrent ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-400 text-white font-bold shadow-lg' : 'hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-gray-800 dark:text-gray-200'}`}
                      onClick={() => handlePoseSidebarJump(sIdx, pIdx)}
                      disabled={isCurrent}
                    >
                      <span className="block truncate">{pose.name}</span>
                      <span className="block text-xs opacity-70">{pose.sanskritName}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );

  // Auto-scroll active pose into view, always centered
  useEffect(() => {
    if (
      poseButtonRefs.current[currentSectionIndex] &&
      poseButtonRefs.current[currentSectionIndex][currentPoseIndex]
    ) {
      setTimeout(() => {
        poseButtonRefs.current[currentSectionIndex][currentPoseIndex]?.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
        });
      }, 0);
    }
  }, [currentSectionIndex, currentPoseIndex, sequence]);

  // Only trigger markSequenceComplete when last pose timer finishes and it was running
  useEffect(() => {
    if (!timerRunning && remainingTime === 0 && isLastPose() && !inTransition && lastPoseTimerWasRunning) {
      setLastPoseTimerWasRunning(false);
      markSequenceComplete();
    }
    // eslint-disable-next-line
  }, [timerRunning, remainingTime, inTransition, currentSectionIndex, currentPoseIndex, sequence]);

  // Only reset audioGenerated when a new sequence is loaded/generated (not on every render)
  useEffect(() => {
    setAudioGenerated(false);
  }, [sequence?.title, sequence?.duration, sequence?.level, sequence?.intent]);

  if (!user) {
    return (
      <Card className="text-center py-12">
        <CardContent>
          <AlertCircle size={64} className="mx-auto text-gray-400 mb-6" />
          <h2 className="text-2xl font-bold mb-4">Please Log In</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
            You need to be logged in to generate yoga sequences.
          </p>
          <Link to="/login">
            <Button variant="primary">Log In</Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  if (subLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[40vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mb-4"></div>
        <p className="text-gray-600 dark:text-gray-300 text-lg">Checking subscription...</p>
      </div>
    );
  }

  if (sequence && (
    !sequence.sections.length ||
    !sequence.sections[currentSectionIndex] ||
    !sequence.sections[currentSectionIndex].poses.length
  )) {
    return (
      <div className="max-w-2xl mx-auto my-12 text-center">
        <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-4 rounded mb-4 font-semibold">
          Could not generate a valid yoga sequence. Please try again or adjust your input.
        </div>
        <Button variant="primary" onClick={() => window.location.href = '/yoga'}>
          Try Again
        </Button>
      </div>
    );
  }

  // Helper to split content into lines for animation
  const streamingLines = streamingContent.split(/\n+/).filter(Boolean);

  const visibleSequences = savedSequences.filter(seq => seq.title && seq.title.trim() !== '');

  // Add this at the top of the file (or in a <style> tag if using CSS-in-JS)
  const customGlowStyle = `
@keyframes customGlowPulse {
  0% { box-shadow: 0 0 0 0 rgba(99,102,241,0.25), 0 0 0 0 #a5b4fc; }
  40% { box-shadow: 0 0 24px 8px rgba(99,102,241,0.45), 0 0 8px 2px #818cf8; }
  60% { box-shadow: 0 0 32px 12px #6366f1, 0 0 16px 4px #818cf8; }
  100% { box-shadow: 0 0 0 0 rgba(99,102,241,0.25), 0 0 0 0 #a5b4fc; }
}
`;
  if (typeof document !== 'undefined' && !document.getElementById('custom-glow-style')) {
    const style = document.createElement('style');
    style.id = 'custom-glow-style';
    style.innerHTML = customGlowStyle;
    document.head.appendChild(style);
  }

  // Add this CSS for subtle glow animation (at the top of the file, after imports)
  const freeBannerGlowStyle = `
@keyframes subtleGlow {
  0%, 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.3); }
  50% { box-shadow: 0 0 16px 4px rgba(34,197,94,0.5); }
}`;
  if (typeof document !== 'undefined' && !document.getElementById('free-banner-glow-style')) {
    const style = document.createElement('style');
    style.id = 'free-banner-glow-style';
    style.innerHTML = freeBannerGlowStyle;
    document.head.appendChild(style);
  }

  // Add a custom flash animation style at the top of the file if not already present
  if (typeof document !== 'undefined' && !document.getElementById('timer-flash-style')) {
    const style = document.createElement('style');
    style.id = 'timer-flash-style';
    style.innerHTML = `
    @keyframes timerFlash {
      0% { box-shadow: 0 0 0 0 #f472b6; }
      50% { box-shadow: 0 0 32px 8px #f472b6; }
      100% { box-shadow: 0 0 0 0 #f472b6; }
    }
    .timer-flash {
      animation: timerFlash 1.2s ease-in-out;
    }
  `;
    document.head.appendChild(style);
  }

  // Inject custom scrollbar CSS for pose list at the top of the file
  if (typeof document !== 'undefined' && !document.getElementById('pose-list-scrollbar-style')) {
    const style = document.createElement('style');
    style.id = 'pose-list-scrollbar-style';
    style.innerHTML = `
    .pose-list-scrollbar {
      scrollbar-color: #6366f1 #1e1b4b;
      scrollbar-width: thin;
    }
    .pose-list-scrollbar::-webkit-scrollbar {
      width: 10px;
      background: #20124d;
    }
    .pose-list-scrollbar::-webkit-scrollbar-thumb {
      background: linear-gradient(to bottom, #6366f1, #a21caf);
      border-radius: 8px;
    }
    .pose-list-scrollbar::-webkit-scrollbar-track {
      background: #1e1b4b;
    }
  `;
    document.head.appendChild(style);
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8 flex gap-4 border-b border-gray-200 dark:border-gray-700">
        <button
          className={`px-4 py-2 font-semibold border-b-2 transition-colors duration-200 ${activeTab === 'ai' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-indigo-500'}`}
          onClick={() => setActiveTab('ai')}
        >
          AI-Generated Sequence
        </button>
        <button
          className={`px-4 py-2 font-semibold border-b-2 transition-colors duration-200 ${activeTab === 'manual' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-indigo-500'}`}
          onClick={() => setActiveTab('manual')}
        >
          Manual Builder
        </button>
      </div>
      {/* Free yoga used banner */}
      {typeof activeTab === 'string' && activeTab === 'ai' && !isSubscribed && freeYogaUsed === true && (
        <div className="mb-6">
          <div className="rounded-2xl bg-gradient-to-r from-pink-200 via-indigo-100 to-purple-100 dark:from-pink-900/40 dark:via-indigo-900/40 dark:to-purple-900/40 border-2 border-pink-300 dark:border-pink-800 shadow-lg p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4 animate-pulse">
            <div className="flex-1">
              <div className="text-lg font-bold text-pink-700 dark:text-pink-200 mb-1">You have used your free AI yoga sequence.</div>
              <div className="text-gray-700 dark:text-gray-200">Subscribe to unlock unlimited AI-powered yoga sequence generation.</div>
            </div>
            <Button variant="primary" onClick={() => navigate('/pricing')} className="mt-4 md:mt-0">View Plans</Button>
          </div>
        </div>
      )}
      {activeTab === 'ai' ? (
        sequence ? (
          <>
            {renderSequence()}
          </>
        ) : (
          <>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">Sacred Practice</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Generate personalized yoga sequences for your practice
              </p>
            </div>
            <Button
              variant="outline"
              leftIcon={<History size={16} />}
              onClick={() => setShowHistory(!showHistory)}
            >
              {showHistory ? 'Hide History' : 'View History'}
            </Button>
          </div>
          {showHistory ? (
              <YogaSequenceHistory
                user={user}
                savedSequences={savedSequences}
                onEditTitle={handleEditTitle}
                onDeleteSequence={handleDeleteSequence}
                onExport={handleExport}
                onShare={handleShare}
                onLoadSequence={handleLoadSequence}
                onEditSequence={(seq: SavedSequence) => {
                  setManualEditSequence(seq);
                  setActiveTab('manual');
                  setShowHistory(false);
                }}
              />
            ) : (
              <YogaAIGenerator
                ref={generatorRef}
                user={user}
                isSubscribed={isSubscribed}
                freeYogaUsed={freeYogaUsed}
                onSequenceGenerated={handleSequenceGenerated}
                onSequenceSaved={fetchSavedSequences}
                intent={intent}
                setIntent={setIntent}
                showCustomIntent={showCustomIntent}
                setShowCustomIntent={setShowCustomIntent}
                duration={duration}
                setDuration={setDuration}
                level={level}
                setLevel={setLevel}
                intentLoading={loading}
              />
              )}
            </>
        )
      ) : (
        manualEditSequence && manualEditSequence.sequence && Array.isArray(manualEditSequence.sequence.sections) ? (
          <SequenceBuilder
            initialSections={manualEditSequence.sequence.sections.map((section: any) => ({
              id: section.title || generateUniqueId(),
              name: section.title,
              poses: section.poses.map((pose: any) => {
                // Try to find the pose in poseDatabase by name or sanskritName
                let foundPose = null;
                for (const cat of poseDatabase) {
                  foundPose = cat.poses.find(p =>
                    (p.name && pose.name && p.name.toLowerCase() === pose.name.toLowerCase()) ||
                    (p.sanskritName && pose.sanskritName && p.sanskritName.toLowerCase() === pose.sanskritName.toLowerCase())
                  );
                  if (foundPose) break;
                }
                return {
                  ...foundPose,
                  ...pose,
                  id: pose.id || generateUniqueId(),
                  image: foundPose?.image || pose.image || undefined,
                };
              })
            }))}
            initialSequenceName={manualEditSequence.title}
            initialIntention={manualEditSequence.intent}
            initialLevel={manualEditSequence.level}
            onDone={() => {
              setManualEditSequence(null);
              setActiveTab('ai');
              setShowHistory(true);
              fetchSavedSequences();
            }}
          />
        ) : (
          <SequenceBuilder />
        )
      )}
      {showReflection && sequence && (
        <ReflectionPrompt
          sequenceTitle={sequenceDbTitle}
          sequenceIntent={sequence?.intent || ''}
          yogaSessionId={currentSequenceId!}
          onClose={() => setShowReflection(false)}
        />
      )}
      <Modal
        open={showDeleteErrorModal}
        onClose={() => setShowDeleteErrorModal(false)}
        title="Error"
        actions={<Button variant="primary" onClick={() => setShowDeleteErrorModal(false)}>OK</Button>}
      >
        {deleteError}
      </Modal>
      <Modal
        open={showPricingModal}
        onClose={() => setShowPricingModal(false)}
        title="Subscribe to Access Audio Features"
        actions={
          <Button variant="primary" onClick={() => { setShowPricingModal(false); navigate('/pricing'); }}>
            View Plans & Pricing
          </Button>
        }
      >
        <div className="text-lg mb-2">Audio instructions and TTS features are available for subscribers only.</div>
        <div className="text-gray-500">Upgrade your plan to unlock AI-powered audio for all yoga poses.</div>
      </Modal>
      <audio ref={audioRef} preload="auto" />
      <audio ref={chimeRef} src={chimeSound} preload="auto" />
    </div>
  );
};

export default YogaPage;