import React from 'react';

const ContactPage = () => (
  <div className="max-w-3xl mx-auto py-12 px-4">
    <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
    <p>
      Have questions, feedback, or need support? Reach out to us!
    </p>
    <ul className="mt-4 space-y-2">
      <li>Email: <a href="mailto:contact@mindful-sphere.com" className="text-indigo-600 underline">contact@mindful-sphere.com</a></li>
      <li>Discord: <span className="text-indigo-600">otiumabscondita</span></li>
    </ul>
    <p className="mt-4">
      We aim to respond to all inquiries within 2 business days.
    </p>
  </div>
);

export default ContactPage; 