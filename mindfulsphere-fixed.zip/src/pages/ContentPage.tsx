import React, { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { Search, BookOpen, Flower, Brain, Lightbulb, History, Users, Heart, ExternalLink, FlaskConical } from 'lucide-react';
import Input from '../components/Input';

interface Resource {
  title: string;
  description: string;
  url: string;
  type: 'book' | 'academic' | 'reference' | 'classic' | 'manual';
  author?: string;
  featured?: boolean;
}

interface Category {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
  resources: Resource[];
}

const categories: Category[] = [
  {
    id: 'poses',
    title: 'Yoga Poses & Alignment',
    description: 'Essential texts and references for understanding asanas',
    icon: <Flower className="text-indigo-500" size={24} />,
    path: '/content/poses',
    resources: [
      {
        title: 'Light on Yoga',
        author: 'B.K.S. Iyengar',
        description: 'The definitive guide to yoga poses with detailed instructions and 600+ photographs',
        url: 'https://archive.org/details/LightOnYoga_201404',
        type: 'classic',
        featured: true
      },
      {
        title: 'Yoga Body & Mind Handbook',
        author: 'Jasmine Tarkeshi',
        description: 'Comprehensive pose manual with anatomical insights and modifications',
        url: 'https://www.gutenberg.org/files/25581/25581-h/25581-h.htm',
        type: 'manual'
      },
      {
        title: 'The Science of Enlightenment',
        author: 'Shinzen Young',
        description: 'Technical approach to meditation postures and alignment principles',
        url: 'https://www.shinzen.org/wp-content/uploads/2016/12/art_science_of_enlightenment.pdf',
        type: 'reference'
      },
      {
        title: 'Hatha Yoga Pradipika',
        author: 'Swami Muktibodhananda',
        description: 'Classical text on traditional hatha yoga practices and poses',
        url: 'https://www.sacred-texts.com/hin/hyp/index.htm',
        type: 'classic',
        featured: true
      },
      {
        title: 'Full Catastrophe Living',
        author: 'Jon Kabat-Zinn',
        description: 'Mindful yoga poses and body awareness techniques',
        url: 'https://palousemindfulness.com/docs/manualMBSReng.pdf',
        type: 'manual'
      }
    ]
  },
  {
    id: 'philosophy',
    title: 'Philosophy & Sacred Texts',
    description: 'Foundational works on yogic philosophy and wisdom',
    icon: <Brain className="text-purple-500" size={24} />,
    path: '/content/philosophy',
    resources: [
      {
        title: 'The Yoga Sutras of Patanjali',
        author: 'Patanjali (Various Translations)',
        description: 'The foundational text of classical yoga philosophy',
        url: 'https://www.sacred-texts.com/hin/yogasutr.htm',
        type: 'classic',
        featured: true
      },
      {
        title: 'The Bhagavad Gita',
        author: 'Vyasa (Various Translations)',
        description: 'Essential Hindu scripture on duty, righteousness, and spiritual practice',
        url: 'https://www.sacred-texts.com/hin/gita/index.htm',
        type: 'classic',
        featured: true
      },
      {
        title: 'The Upanishads',
        author: 'Various Sages',
        description: 'Ancient philosophical texts exploring the nature of reality and consciousness',
        url: 'https://www.sacred-texts.com/hin/sbe01/index.htm',
        type: 'classic'
      },
      {
        title: 'Autobiography of a Yogi',
        author: 'Paramahansa Yogananda',
        description: 'Modern spiritual classic bridging Eastern and Western thought',
        url: 'https://www.ananda.org/free-inspiration/books/autobiography-of-a-yogi/',
        type: 'book'
      },
      {
        title: 'The Perennial Philosophy',
        author: 'Aldous Huxley',
        description: 'Comparative analysis of mystical traditions including yoga',
        url: 'https://archive.org/details/in.ernet.dli.2015.499847',
        type: 'academic'
      }
    ]
  },
  {
    id: 'techniques',
    title: 'Meditation & Breathwork',
    description: 'Practical guides to pranayama and meditation techniques',
    icon: <Lightbulb className="text-amber-500" size={24} />,
    path: '/content/techniques',
    resources: [
      {
        title: 'Light on Pranayama',
        author: 'B.K.S. Iyengar',
        description: 'Comprehensive guide to yogic breathing techniques and practices',
        url: 'https://archive.org/details/LightOnPranayama',
        type: 'classic',
        featured: true
      },
      {
        title: 'The Complete Guide to Yin Yoga',
        author: 'Bernie Clark',
        description: 'Philosophy and practice of meditative yoga postures',
        url: 'https://www.yinyoga.com/newsletters/march2008_bernie_clark.pdf',
        type: 'manual'
      },
      {
        title: 'Wherever You Go, There You Are',
        author: 'Jon Kabat-Zinn',
        description: 'Mindfulness meditation in everyday life',
        url: 'https://palousemindfulness.com/docs/JonKabatZinn.pdf',
        type: 'book'
      },
      {
        title: 'The Relaxation Response',
        author: 'Herbert Benson',
        description: 'Scientific approach to meditation and stress reduction',
        url: 'https://www.bensonhenryinstitute.org/uploads/RelaxationResponse.pdf',
        type: 'academic'
      },
      {
        title: 'Mindfulness in Plain English',
        author: 'Bhante Henepola Gunaratana',
        description: 'Clear instructions for vipassana meditation practice',
        url: 'http://www.urbandharma.org/udharma4/mpe.html',
        type: 'manual'
      }
    ]
  },
  {
    id: 'science',
    title: 'Scientific Research',
    description: 'Academic studies and research on yoga and meditation',
    icon: <FlaskConical className="text-teal-500" size={24} />,
    path: '/content/science',
    resources: [
      {
        title: 'The Science of Enlightenment',
        author: 'Shinzen Young',
        description: 'Systematic approach to meditation with scientific methodology',
        url: 'https://www.shinzen.org/wp-content/uploads/2016/12/art_science_of_enlightenment.pdf',
        type: 'academic',
        featured: true
      },
      {
        title: 'Altered Traits',
        author: 'Daniel Goleman & Richard Davidson',
        description: 'Neuroscience research on meditation and brain changes',
        url: 'https://www.contemplativemind.org/admin/wp-content/uploads/2017/09/Altered-Traits-Excerpt.pdf',
        type: 'academic'
      },
      {
        title: 'The Embodied Mind',
        author: 'Francisco Varela, Evan Thompson, Eleanor Rosch',
        description: 'Cognitive science meets Buddhist philosophy',
        url: 'https://archive.org/details/embodiedmindcogn00vare',
        type: 'academic'
      },
      {
        title: 'Waking Up',
        author: 'Sam Harris',
        description: 'Neuroscientist explores spirituality without religion',
        url: 'https://www.samharris.org/podcast/item/waking-up-daily-reflections',
        type: 'book'
      },
      {
        title: 'The Wise Heart',
        author: 'Jack Kornfield',
        description: 'Psychology and meditation from Buddhist perspective',
        url: 'https://jackkornfield.com/meditation-for-beginners/',
        type: 'academic'
      }
    ]
  },
  {
    id: 'wellness',
    title: 'Holistic Health',
    description: 'Integrative approaches to wellness and healing',
    icon: <Heart className="text-rose-500" size={24} />,
    path: '/content/wellness',
    resources: [
      {
        title: 'Yoga and the Path of the Urban Mystic',
        author: 'Darren Main',
        description: 'Practical spirituality for modern life',
        url: 'https://www.dharmaspirit.com/book-excerpts/',
        type: 'book',
        featured: true
      },
      {
        title: 'The Healing Power of Yoga',
        author: 'Loren Fishman & Eric Small',
        description: 'Medical doctor\'s guide to therapeutic yoga',
        url: 'https://www.sciatica.org/yoga/healing-power-of-yoga.pdf',
        type: 'manual'
      },
      {
        title: 'Eastern Body, Western Mind',
        author: 'Anodea Judith',
        description: 'Chakra system and psychological healing',
        url: 'https://www.sacredcenters.com/free-resources/',
        type: 'book'
      },
      {
        title: 'The Mindful Body',
        author: 'Ellen Langer',
        description: 'Mind-body connection and conscious awareness',
        url: 'https://www.langermindfulnessinstitute.org/mindful-body-excerpts',
        type: 'academic'
      },
      {
        title: 'Ayurveda: The Science of Self-Healing',
        author: 'Vasant Lad',
        description: 'Traditional Indian medicine and lifestyle practices',
        url: 'https://www.ayurveda.com/pdf/ayurveda_sci_self_healing.pdf',
        type: 'reference'
      }
    ]
  },
  {
    id: 'history',
    title: 'History & Tradition',
    description: 'Historical development and cultural context of yoga',
    icon: <History className="text-green-500" size={24} />,
    path: '/content/history',
    resources: [
      {
        title: 'The Yoga Tradition',
        author: 'Georg Feuerstein',
        description: 'Comprehensive history of yoga philosophy and practice',
        url: 'https://archive.org/details/yogatraditionits00feue',
        type: 'academic',
        featured: true
      },
      {
        title: 'Yoga: Immortality and Freedom',
        author: 'Mircea Eliade',
        description: 'Scholarly examination of yogic traditions and techniques',
        url: 'https://archive.org/details/yogaimmortalityf00elia',
        type: 'academic'
      },
      {
        title: 'The Hindu Way',
        author: 'Shashi Tharoor',
        description: 'Introduction to Hindu philosophy and spiritual practices',
        url: 'https://archive.org/details/hinduway00thar',
        type: 'book'
      },
      {
        title: 'Tantra: The Path of Ecstasy',
        author: 'Georg Feuerstein',
        description: 'Scholarly exploration of tantric yoga traditions',
        url: 'https://archive.org/details/tantrapathofecst00feue',
        type: 'academic'
      },
      {
        title: 'The Cultural Heritage of India',
        author: 'Ramakrishna Mission Institute',
        description: 'Comprehensive study of Indian philosophical traditions',
        url: 'https://archive.org/details/culturalheritag00rama',
        type: 'reference'
      }
    ]
  }
];

const ContentPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();

  const filteredCategories = categories.map(category => ({
    ...category,
    resources: category.resources.filter(resource =>
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.author?.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.resources.length > 0 || !searchQuery);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'classic': return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200';
      case 'academic': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'manual': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'reference': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'book': return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const CategoryContent: React.FC<{ category: Category }> = ({ category }) => {
    const filteredResources = category.resources.filter(resource =>
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.author?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-8">
          {category.icon}
          <div>
            <h1 className="text-3xl font-bold">{category.title}</h1>
            <p className="text-gray-600 dark:text-gray-300">{category.description}</p>
          </div>
        </div>

        <div className="grid gap-6">
          {filteredResources.map((resource, index) => (
            <Card key={index} className={`transition-all duration-300 hover:shadow-lg ${resource.featured ? 'ring-2 ring-indigo-200 dark:ring-indigo-800' : ''}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-semibold">
                        {resource.title}
                      </h3>
                      {resource.featured && (
                        <span className="text-xs bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200 px-2 py-1 rounded-full">
                          Essential
                        </span>
                      )}
                    </div>
                    {resource.author && (
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                        by {resource.author}
                      </p>
                    )}
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {resource.description}
                    </p>
                  </div>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${getTypeColor(resource.type)}`}>
                    {resource.type}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="text-indigo-600 dark:text-indigo-400" />
            Yoga Library
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Essential texts, classical works, and scholarly references
          </p>
        </div>
        <div className="w-full md:w-80">
          <Input
            placeholder="Search books and authors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            leftIcon={<Search size={18} />}
          />
        </div>
      </div>

      <Routes>
        <Route
          index
          element={
            <div className="space-y-8">
              {searchQuery && (
                <div className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Showing results for "{searchQuery}"
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCategories.map((category) => (
                  <Link key={category.id} to={category.path}>
                    <Card className="h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-l-4 border-l-indigo-500">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <h2 className="text-xl font-semibold mb-2 flex items-center gap-2">
                              {category.icon}
                              {category.title}
                            </h2>
                            <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                              {category.description}
                            </p>
                            <div className="flex items-center justify-between">
                              <p className="text-sm text-indigo-600 dark:text-indigo-400 font-medium">
                                {category.resources.length} texts
                              </p>
                              <span className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded-full">
                                {category.resources.filter(r => r.featured).length} essential
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
              
              {searchQuery && filteredCategories.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500 dark:text-gray-400">
                    No texts found matching "{searchQuery}"
                  </p>
                </div>
              )}
            </div>
          }
        />
        {categories.map((category) => (
          <Route
            key={category.id}
            path={category.id}
            element={<CategoryContent category={category} />}
          />
        ))}
      </Routes>
    </div>
  );
};

export default ContentPage;