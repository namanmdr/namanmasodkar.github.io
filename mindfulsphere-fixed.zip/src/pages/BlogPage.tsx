import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { Search, Calendar, Clock, Tag, ArrowRight, BookOpen } from 'lucide-react';
import SEOHead from '../components/SEOHead';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  slug: string;
  publishedAt: string;
  readTime: number;
  tags: string[];
  featured: boolean;
  seoTitle?: string;
  seoDescription?: string;
}

const BlogPage: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [filteredPosts, setFilteredPosts] = useState<BlogPost[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [loading, setLoading] = useState(true);

  // Sample blog posts - in a real app, these would come from a CMS or database
  const samplePosts: BlogPost[] = [
    {
      id: '1',
      title: 'How AI is Revolutionizing Your Yoga Practice',
      excerpt: 'Discover how artificial intelligence is transforming the way we approach yoga, from personalized sequences to real-time pose correction.',
      content: '',
      slug: 'ai-revolutionizing-yoga-practice',
      publishedAt: '2025-07-15',
      readTime: 8,
      tags: ['AI', 'Yoga', 'Technology', 'Wellness'],
      featured: true,
      seoTitle: 'AI Yoga Revolution: How Technology Enhances Your Practice',
      seoDescription: 'Explore how AI is transforming yoga practice with personalized sequences, real-time feedback, and enhanced mindfulness experiences.'
    },
    {
      id: '2',
      title: 'The Science Behind Mindful Journaling',
      excerpt: 'Learn about the psychological benefits of journaling and how it can improve your mental health and emotional well-being.',
      content: '',
      slug: 'science-behind-mindful-journaling',
      publishedAt: '2025-07-10',
      readTime: 6,
      tags: ['Journaling', 'Mental Health', 'Mindfulness', 'Psychology'],
      featured: false,
      seoTitle: 'Mindful Journaling Benefits: Science-Backed Mental Health Benefits',
      seoDescription: 'Discover the scientific benefits of mindful journaling and how it can transform your mental health and emotional well-being.'
    },
    {
      id: '3',
      title: 'Creating Your Perfect Morning Yoga Routine',
      excerpt: 'Start your day with intention and energy by building a morning yoga routine that works for your lifestyle and goals.',
      content: '',
      slug: 'perfect-morning-yoga-routine',
      publishedAt: '2025-07-08',
      readTime: 7,
      tags: ['Morning Routine', 'Yoga', 'Wellness', 'Lifestyle'],
      featured: false,
      seoTitle: 'Morning Yoga Routine: Start Your Day with Intention',
      seoDescription: 'Learn how to create the perfect morning yoga routine that energizes your body and sets a positive tone for your entire day.'
    },
    {
      id: '4',
      title: 'Digital Detox: Finding Balance in a Connected World',
      excerpt: 'Explore strategies for maintaining mindfulness and presence in our increasingly digital world.',
      content: '',
      slug: 'digital-detox-finding-balance',
      publishedAt: '2025-07-05',
      readTime: 9,
      tags: ['Digital Detox', 'Mindfulness', 'Technology', 'Balance'],
      featured: true,
      seoTitle: 'Digital Detox Strategies: Finding Mindfulness in a Connected World',
      seoDescription: 'Learn effective strategies for digital detox and maintaining mindfulness in our hyperconnected world.'
    },
    {
      id: '5',
      title: 'The Art of Self-Reflection: Deepening Your Practice',
      excerpt: 'Master the art of self-reflection to deepen your yoga and mindfulness practice.',
      content: '',
      slug: 'art-of-self-reflection',
      publishedAt: '2025-07-03',
      readTime: 5,
      tags: ['Self-Reflection', 'Mindfulness', 'Personal Growth', 'Practice'],
      featured: false,
      seoTitle: 'Self-Reflection in Yoga: Deepening Your Mindfulness Practice',
      seoDescription: 'Master the art of self-reflection to deepen your yoga and mindfulness practice for greater personal growth.'
    },
    {
      id: '6',
      title: 'Yoga for Stress Relief: Poses That Calm the Mind',
      excerpt: 'Discover specific yoga poses and sequences designed to reduce stress and promote mental clarity.',
      content: '',
      slug: 'yoga-stress-relief-poses',
      publishedAt: '2025-07-01',
      readTime: 6,
      tags: ['Stress Relief', 'Yoga Poses', 'Mental Health', 'Relaxation'],
      featured: false,
      seoTitle: 'Stress Relief Yoga: Poses That Calm Your Mind Naturally',
      seoDescription: 'Discover effective yoga poses and sequences specifically designed to reduce stress and promote mental clarity.'
    }
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setPosts(samplePosts);
      setFilteredPosts(samplePosts);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let filtered = posts;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Filter by tag
    if (selectedTag) {
      filtered = filtered.filter(post =>
        post.tags.some(tag => tag.toLowerCase() === selectedTag.toLowerCase())
      );
    }

    setFilteredPosts(filtered);
  }, [searchTerm, selectedTag, posts]);

  const allTags = Array.from(new Set(posts.flatMap(post => post.tags)));

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto">
        <div className="text-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading blog posts...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <SEOHead
        title="MindfulSphere Blog - Yoga & Mindfulness Insights"
        description="Discover expert insights on yoga, mindfulness, and personal growth. Learn about AI-powered yoga, mindful journaling, and wellness practices."
        keywords={['yoga blog', 'mindfulness articles', 'wellness tips', 'AI yoga', 'mindful journaling', 'personal growth']}
        type="website"
      />
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <BookOpen className="text-primary-600 dark:text-primary-400 mr-3" size={32} />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary-600 via-indigo-500 to-purple-500 bg-clip-text text-transparent leading-loose pb-2">
              MindfulSphere Blog
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Discover insights, tips, and wisdom to deepen your yoga practice and enhance your mindfulness journey.
          </p>
        </div>

        {/* Dedicated Search Section */}
        <div className="mb-8">
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 border-2 border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all duration-200 text-gray-900 dark:text-gray-100 text-lg shadow-md"
              />
            </div>
          </div>
        </div>

        {/* Filter Tags */}
        <div className="mb-8">
          <div className="flex overflow-x-auto scrollbar-none gap-3 px-4 py-2 max-w-full">
            <button
              onClick={() => setSelectedTag('')}
              className={`px-5 py-3 rounded-full text-sm font-medium transition-colors whitespace-nowrap flex-shrink-0 ${
                selectedTag === '' 
                  ? 'bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-200' 
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              All
            </button>
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(selectedTag === tag ? '' : tag)}
                className={`px-5 py-3 rounded-full text-sm font-medium transition-colors whitespace-nowrap flex-shrink-0 ${
                  selectedTag === tag 
                    ? 'bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-200' 
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Posts */}
        {filteredPosts.filter(post => post.featured).length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-gray-100">Featured Articles</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {filteredPosts
                .filter(post => post.featured)
                .map(post => (
                  <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 border-2 border-primary-100 dark:border-primary-900/40">
                    <CardHeader>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="px-2 py-1 bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-200 text-xs font-medium rounded-full">
                          Featured
                        </span>
                        {post.tags.slice(0, 2).map(tag => (
                          <span key={tag} className="px-2 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs font-medium rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                      <CardTitle className="text-xl group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                        {post.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <Calendar size={14} />
                            {formatDate(post.publishedAt)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock size={14} />
                            {post.readTime} min read
                          </div>
                        </div>
                        <Link
                          to={`/blog/${post.slug}`}
                          className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium transition-colors"
                        >
                          Read More
                          <ArrowRight size={16} />
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        )}

        {/* All Posts */}
        <div>
          <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-gray-100">
            {searchTerm || selectedTag ? 'Search Results' : 'All Articles'}
            {filteredPosts.length > 0 && (
              <span className="text-lg font-normal text-gray-500 dark:text-gray-400 ml-2">
                ({filteredPosts.length} articles)
              </span>
            )}
          </h2>

          {filteredPosts.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="text-gray-400 mx-auto mb-4" size={48} />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No articles found</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Try adjusting your search terms or browse all articles.
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPosts.map(post => (
                <Card key={post.id} className="group hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      {post.tags.slice(0, 2).map(tag => (
                        <span key={tag} className="px-2 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs font-medium rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <CardTitle className="text-lg group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors line-clamp-2">
                      {post.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center gap-1">
                          <Calendar size={14} />
                          {formatDate(post.publishedAt)}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock size={14} />
                          {post.readTime} min
                        </div>
                      </div>
                      <Link
                        to={`/blog/${post.slug}`}
                        className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium transition-colors"
                      >
                        Read
                        <ArrowRight size={16} />
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default BlogPage; 