import React from 'react';

const AboutPage = () => (
  <div className="max-w-3xl mx-auto py-12 px-4">
    <h1 className="text-3xl font-bold mb-4">About MindfulSphere</h1>
    <p>
      MindfulSphere is dedicated to helping individuals cultivate mindfulness, well-being, and personal growth through AI-powered yoga and journaling tools. Our mission is to make mindfulness accessible, enjoyable, and effective for everyone, everywhere.
    </p>
    <p className="mt-4">
      Founded in 2025, MindfulSphere is committed to privacy, inclusivity, and continuous improvement. We welcome your feedback and are always working to enhance your experience.
    </p>
  </div>
);

export default AboutPage; 