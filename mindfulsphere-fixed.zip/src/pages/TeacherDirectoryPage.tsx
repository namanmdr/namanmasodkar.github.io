import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { UserCircle } from 'lucide-react';

interface TeacherProfile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  location: string | null;
  teaching_styles: string[];
  years_experience: number | null;
  certifications: string | null;
  teacher_bio: string | null;
  public_contact: string | null;
}

const TeacherDirectoryPage: React.FC = () => {
  const [teachers, setTeachers] = useState<TeacherProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTeachers = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url, location, teaching_styles, years_experience, certifications, teacher_bio, public_contact')
        .eq('account_type', 'teacher')
        .eq('is_teacher_listed', true);
      if (!error && data) {
        setTeachers(data);
      }
      setLoading(false);
    };
    fetchTeachers();
  }, []);

  return (
    <div className="max-w-5xl mx-auto py-12 px-4">
      <h1 className="text-4xl font-bold mb-8 text-center">MindfulSphere Yoga Teacher Directory</h1>
      <p className="text-center text-gray-600 dark:text-gray-300 mb-12">Find a yoga teacher affiliated with MindfulSphere. All teachers listed here have opted in to be publicly visible.</p>
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading teachers...</p>
        </div>
      ) : teachers.length === 0 ? (
        <div className="text-center text-lg text-gray-500 dark:text-gray-400">No teachers found.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {teachers.map((teacher) => (
            <Card key={teacher.id} className="h-full flex flex-col">
              <CardHeader className="flex flex-col items-center">
                {teacher.avatar_url ? (
                  <img src={teacher.avatar_url} alt={teacher.full_name} className="w-20 h-20 rounded-full object-cover mb-2" />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mb-2">
                    <UserCircle size={48} className="text-indigo-600 dark:text-indigo-400" />
                  </div>
                )}
                <CardTitle className="text-xl text-center">{teacher.full_name}</CardTitle>
                {teacher.location && <div className="text-sm text-gray-500 dark:text-gray-400 text-center">{teacher.location}</div>}
              </CardHeader>
              <CardContent className="flex-1 flex flex-col gap-2">
                {teacher.teaching_styles && teacher.teaching_styles.length > 0 && (
                  <div>
                    <span className="font-semibold">Styles:</span> {teacher.teaching_styles.join(', ')}
                  </div>
                )}
                {teacher.years_experience !== null && (
                  <div>
                    <span className="font-semibold">Experience:</span> {teacher.years_experience} year{teacher.years_experience === 1 ? '' : 's'}
                  </div>
                )}
                {teacher.certifications && (
                  <div>
                    <span className="font-semibold">Certifications:</span> {teacher.certifications}
                  </div>
                )}
                {teacher.teacher_bio && (
                  <div className="text-sm text-gray-700 dark:text-gray-300 mt-2">{teacher.teacher_bio}</div>
                )}
                {teacher.public_contact && (
                  <div className="mt-2">
                    <span className="font-semibold">Contact:</span> <span className="break-all">{teacher.public_contact}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default TeacherDirectoryPage; 