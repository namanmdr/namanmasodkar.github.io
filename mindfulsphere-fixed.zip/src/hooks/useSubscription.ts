import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface SubscriptionStatus {
  isSubscribed: boolean;
  monthlyUsage: number;
  loading: boolean;
  error: string | null;
}

export function useSubscription() {
  const { user } = useAuth();
  const [status, setStatus] = useState<SubscriptionStatus>({
    isSubscribed: false,
    monthlyUsage: 0,
    loading: true,
    error: null
  });

  useEffect(() => {
    if (user) {
      checkSubscriptionStatus();
    } else {
      setStatus(prev => ({ ...prev, loading: false }));
    }
  }, [user]);

  const checkSubscriptionStatus = async () => {
    try {
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // No settings found, create default settings
          const { error: insertError } = await supabase
            .from('user_settings')
            .insert({
              user_id: user?.id,
              monthly_usage: 0,
              last_reset: new Date().toISOString()
            });

          if (insertError) throw insertError;

          setStatus({
            isSubscribed: false,
            monthlyUsage: 0,
            loading: false,
            error: null
          });
          return;
        }
        throw error;
      }

      setStatus({
        isSubscribed: data?.subscription_status === 'active',
        monthlyUsage: data?.monthly_usage || 0,
        loading: false,
        error: null
      });
    } catch (error) {
      console.error('Error checking subscription:', error);
      setStatus(prev => ({ 
        ...prev, 
        loading: false,
        error: 'Failed to check subscription status'
      }));
    }
  };

  return status;
}