# MindfulSphere — code audit & fixes

Reviewed against the uploaded source. The app **builds and runs** (production
build exits clean), so nothing here is "it doesn't compile." The issues are
correctness, security, billing integrity, SEO, and performance. Everything in
**§1 is already fixed** in this tree (see `mindfulsphere.patch` for the exact
diff). **§2 needs you** — it depends on your environment, accounts, or a product
decision I shouldn't make for you.

---

## 1. Fixed in this tree

### 1.1 Broken Stripe usage endpoint (live 404)  — `src/lib/stripe.ts`
`reportStripeUsage` called `.../report-usage` (hyphen) but the deployed function
folder is `report_usage` (underscore) — every call 404'd. It also sent
`Authorization: 'Bearer service'`, a literal placeholder, not a real token.

Deeper problem: **the browser should never self-report billing usage.** A client
can't hold the service-role key, and a user could forge any `tokensUsed` value.
Your `ai-proxy` function already reports the *real* OpenAI token count
server-side after each call, so the client path was both broken and a
billing-integrity hole. It's now a documented no-op; server-side reporting is
authoritative. Recommend deleting the two call sites in `JournalEditPage.tsx`
and `YogaPage.tsx`.

### 1.2 Hardcoded Supabase project ref in ~14 places — new `src/lib/functions.ts`
The function URL `https://jfbmongwmakpobzfxsnz.functions.supabase.co/...` was
pasted into `ai.ts` (×6), `yoga.ts` (×2), `YogaPage.tsx` (×4), `stripe.ts`,
`ProfilePage.tsx`, `JournalEditPage.tsx`, and `YogaAIGenerator.tsx`. Change
projects (or spin up a staging env) and all of it silently breaks.

Added `fnUrl(name)` which derives the base from `VITE_SUPABASE_URL` using the
stable `/functions/v1/<name>` path. All call sites now use it.

### 1.3 Billing race condition — `supabase/functions/ai-proxy/index.ts`
The chat paths incremented usage with a read-then-write
(`monthly_usage: settings.monthly_usage + tokens`). Two concurrent requests read
the same starting value and the second overwrites the first, under-counting
usage. The TTS path already used the atomic `increment_monthly_usage` RPC — the
two chat paths now use it too.

### 1.4 Crawlers/social bots see an empty page — code-split + robots/sitemap
- **`src/App.tsx`**: every page was eagerly imported into one **2.19 MB
  (661 KB gzip)** JS chunk that had to download before anything rendered. Pages
  are now `React.lazy` + `<Suspense>`; the initial entry is ~178 KB
  (~59 KB gzip) and heavy libs (jsPDF, html2canvas, force-graph) load only on
  the routes that use them.
- Added **`public/robots.txt`** and **`public/sitemap.xml`** (neither existed).

> Note: this does **not** fix the core SEO limitation — you're still a
> client-rendered SPA, so bots that don't run JS see the empty shell even though
> `react-helmet-async` sets good tags at runtime. See §2.1.

---

## 2. Needs you (can't/shouldn't be done blindly from here)

### 2.1 Server-render or pre-render the marketing pages (biggest SEO win)
`react-helmet-async` only helps clients that execute JS. Google mostly does now;
Slack/WhatsApp/X/LinkedIn link-preview bots mostly don't, so shares render bare.
Options, cheapest first:
- Pre-render static routes at build time (`vite-plugin-prerender` /
  `react-snap`) for `/`, `/about`, `/pricing`, `/blog`, `/blog/:slug`,
  `/teachers`.
- Or move the public/marketing surface to Astro or Next and keep the app SPA.

### 2.2 `og-image.jpg` is referenced but doesn't exist
`SEOHead.tsx` points OpenGraph/Twitter at `https://mindfulsphere.com/og-image.jpg`,
which isn't in `public/`. Every social share currently has a broken preview
image. Also note the canonical domain: SEOHead uses `mindfulsphere.com` while the
live site is `mindful-sphere.com` — pick one and make it consistent (canonical
tags, sitemap, OG URLs).

### 2.3 Analytics fire before consent — `index.html`
Meta Pixel and GA both run on page load with no consent gate. For an app storing
**journal entries** (sensitive personal reflection), that's a GDPR/DPDP exposure
and off-brand. Gate them behind explicit consent. Minimal drop-in — replace the
inline pixel/GA with loaders that only run after a stored consent flag:

```html
<script>
  window.msConsent = localStorage.getItem('ms-analytics-consent') === 'granted';
  window.loadAnalytics = function () {
    // --- GA ---
    var g = document.createElement('script');
    g.async = true;
    g.src = 'https://www.googletagmanager.com/gtag/js?id=G-4YXCK3R237';
    document.head.appendChild(g);
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date()); gtag('config', 'G-4YXCK3R237');
    // --- Meta Pixel ---
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
    (window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init','1067262175073701'); fbq('track','PageView');
  };
  if (window.msConsent) window.loadAnalytics();
</script>
```
Then show a small banner; on Accept: `localStorage.setItem('ms-analytics-consent','granted'); loadAnalytics();`

### 2.4 Tighten the CSP (defense-in-depth) — `netlify.toml` / `_headers`
`script-src` allows `'unsafe-eval'` and `'unsafe-inline'`. If a dependency
forced `unsafe-eval`, scope it; otherwise drop it. Move inline scripts to files
or nonces so you can remove `'unsafe-inline'`. Also `_headers` and `netlify.toml`
define overlapping CSPs — keep one source of truth to avoid drift.

### 2.5 Homepage chunk is still heavy (~180 KB gzip)
Code-splitting isolated it, but `HomePage` is the largest route chunk. Worth a
look — likely eagerly bundling screenshots or a heavy viz. Lazy-load
below-the-fold imagery and any graph component.

### 2.6 Free-tier grace window is loose — `ai-proxy`
The 60-second `withinGracePeriod` lets a non-subscribed user past the
`free_yoga_used` gate for a second call. Probably intended as a retry allowance;
just confirm it's deliberate, since it effectively grants two free generations.

---

## How to apply / verify
```bash
npm install
npm run build        # already verified: exits 0
# redeploy the Edge Function after pulling the ai-proxy change:
supabase functions deploy ai-proxy
```
`mindfulsphere.patch` contains the full unified diff if you'd rather review and
apply hunk by hunk.
