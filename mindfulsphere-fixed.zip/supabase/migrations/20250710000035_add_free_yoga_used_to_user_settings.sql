-- Migration: Add free_yoga_used column to user_settings for free yoga sequence tracking
ALTER TABLE user_settings
ADD COLUMN IF NOT EXISTS free_yoga_used BOOLEAN DEFAULT FALSE; 