-- Migration: Add journal_reflections table
create table if not exists journal_reflections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users not null,
  type text not null check (type in ('week', 'month')),
  period_key text not null,
  range text not null,
  title text not null,
  summary text not null,
  tags text[] not null default '{}',
  quote text,
  created_at timestamp with time zone default now(),
  unique (user_id, type, period_key)
);
create index if not exists idx_journal_reflections_user_period on journal_reflections(user_id, type, period_key); 