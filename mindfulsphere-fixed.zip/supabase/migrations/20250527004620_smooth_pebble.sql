/*
  # Fix profile update functionality

  1. Changes
    - Remove duplicate columns from previous migration
    - Add NOT NULL constraint to email column
    - Add default values for JSON columns
*/

-- First, drop duplicate columns if they exist
DO $$ 
BEGIN
  -- Check if columns exist before trying to drop them
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'gender'
    AND position(',' in (
      SELECT count(*)::text 
      FROM information_schema.columns 
      WHERE table_name = 'profiles' 
      AND column_name = 'gender'
    )) > 0
  ) THEN
    ALTER TABLE profiles 
    DROP COLUMN gender,
    DROP COLUMN birth_date,
    DROP COLUMN location,
    DROP COLUMN experience_level,
    DROP COLUMN preferred_practice_time,
    DROP COLUMN goals,
    DROP COLUMN bio,
    DROP COLUMN website,
    DROP COLUMN social_links,
    DROP COLUMN preferences;
  END IF;
END $$;

-- Ensure email is NOT NULL and has a default value
ALTER TABLE profiles 
ALTER COLUMN email SET NOT NULL,
ALTER COLUMN social_links SET DEFAULT '{"github": "", "twitter": "", "linkedin": ""}'::jsonb,
ALTER COLUMN preferences SET DEFAULT '{
  "email_notifications": true,
  "practice_reminders": true,
  "journal_reminders": true,
  "theme": "system",
  "language": "en"
}'::jsonb;