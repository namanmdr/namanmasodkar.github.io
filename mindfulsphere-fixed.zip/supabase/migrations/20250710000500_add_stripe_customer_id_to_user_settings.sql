-- Migration: Add stripe_customer_id column to user_settings for Stripe integration
ALTER TABLE user_settings
ADD COLUMN IF NOT EXISTS stripe_customer_id TEXT; 