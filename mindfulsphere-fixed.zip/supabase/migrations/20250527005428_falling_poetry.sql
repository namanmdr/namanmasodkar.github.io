/*
  # Fix profile fields and update functionality

  1. Changes
    - Remove any duplicate columns
    - Add missing fields to profiles table
    - Set proper defaults and constraints
*/

-- First, ensure we don't have duplicate columns
DO $$ 
BEGIN
  -- Drop duplicate columns if they exist
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'gender'
    AND position(',' in (
      SELECT count(*)::text 
      FROM information_schema.columns 
      WHERE table_name = 'profiles' 
      AND column_name = 'gender'
    )) > 0
  ) THEN
    ALTER TABLE profiles 
    DROP COLUMN IF EXISTS gender,
    DROP COLUMN IF EXISTS birth_date,
    DROP COLUMN IF EXISTS location,
    DROP COLUMN IF EXISTS experience_level,
    DROP COLUMN IF EXISTS preferred_practice_time,
    DROP COLUMN IF EXISTS goals,
    DROP COLUMN IF EXISTS bio,
    DROP COLUMN IF EXISTS website,
    DROP COLUMN IF EXISTS social_links,
    DROP COLUMN IF EXISTS preferences;
  END IF;
END $$;

-- Add missing columns with proper constraints
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS gender TEXT,
ADD COLUMN IF NOT EXISTS birth_date DATE,
ADD COLUMN IF NOT EXISTS location TEXT,
ADD COLUMN IF NOT EXISTS experience_level TEXT CHECK (experience_level IN ('beginner', 'intermediate', 'advanced')),
ADD COLUMN IF NOT EXISTS preferred_practice_time TEXT CHECK (preferred_practice_time IN ('morning', 'afternoon', 'evening', 'night')),
ADD COLUMN IF NOT EXISTS goals TEXT[],
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS website TEXT,
ADD COLUMN IF NOT EXISTS social_links JSONB DEFAULT '{"github": "", "twitter": "", "linkedin": ""}'::jsonb,
ADD COLUMN IF NOT EXISTS preferences JSONB DEFAULT '{
  "email_notifications": true,
  "practice_reminders": true,
  "journal_reminders": true,
  "theme": "system",
  "language": "en"
}'::jsonb;

-- Ensure email is NOT NULL
ALTER TABLE profiles 
ALTER COLUMN email SET NOT NULL;