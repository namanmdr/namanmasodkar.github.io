-- Migration to add user_poses table for custom user-created poses/blocks
CREATE TABLE IF NOT EXISTS public.user_poses (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
    name text NOT NULL,
    sanskrit_name text NOT NULL,
    duration text NOT NULL,
    duration_in_seconds integer NOT NULL,
    benefits text NOT NULL,
    instructions jsonb NOT NULL,
    intent_relation text,
    audio_url text,
    image text,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_poses_user_id ON public.user_poses(user_id); 