/*
  # Add additional profile fields

  1. Changes
    - Add new optional fields to profiles table for enhanced user information
    - Add check constraints for experience_level and preferred_practice_time
    - Add default JSONB structures for social_links and preferences

  2. Security
    - No changes to RLS policies needed
    - Existing row-level security remains in effect
*/

DO $$ 
BEGIN
  -- Add columns if they don't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'birth_date') THEN
    ALTER TABLE profiles ADD COLUMN birth_date DATE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'location') THEN
    ALTER TABLE profiles ADD COLUMN location TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'experience_level') THEN
    ALTER TABLE profiles ADD COLUMN experience_level TEXT;
    ALTER TABLE profiles ADD CONSTRAINT experience_level_check CHECK (experience_level IN ('beginner', 'intermediate', 'advanced'));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'preferred_practice_time') THEN
    ALTER TABLE profiles ADD COLUMN preferred_practice_time TEXT;
    ALTER TABLE profiles ADD CONSTRAINT preferred_practice_time_check CHECK (preferred_practice_time IN ('morning', 'afternoon', 'evening', 'night'));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'goals') THEN
    ALTER TABLE profiles ADD COLUMN goals TEXT[];
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'bio') THEN
    ALTER TABLE profiles ADD COLUMN bio TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'website') THEN
    ALTER TABLE profiles ADD COLUMN website TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'social_links') THEN
    ALTER TABLE profiles ADD COLUMN social_links JSONB DEFAULT '{}'::jsonb;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'preferences') THEN
    ALTER TABLE profiles ADD COLUMN preferences JSONB DEFAULT '{
      "email_notifications": true,
      "practice_reminders": true,
      "journal_reminders": true,
      "theme": "system",
      "language": "en"
    }'::jsonb;
  END IF;
END $$;