-- Migration: Fix yoga_sessions table field name inconsistency
-- Change 'focus' column to 'intent' to match application code

-- First, add the new 'intent' column
ALTER TABLE yoga_sessions 
ADD COLUMN IF NOT EXISTS intent TEXT;

-- Copy data from 'focus' to 'intent' if focus column exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'yoga_sessions' AND column_name = 'focus'
  ) THEN
    UPDATE yoga_sessions 
    SET intent = focus 
    WHERE intent IS NULL AND focus IS NOT NULL;
  END IF;
END $$;

-- Drop the old 'focus' column if it exists
ALTER TABLE yoga_sessions 
DROP COLUMN IF EXISTS focus;

-- Update database types to reflect the change
-- Note: This will be reflected in the generated database.types.ts file 