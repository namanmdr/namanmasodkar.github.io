/*
  # Add subscription fields to user_settings table

  1. Changes
    - Add subscription-related columns to user_settings table:
      - subscription_id (text)
      - subscription_status (text)
      - current_period_end (timestamptz)
*/

ALTER TABLE user_settings
ADD COLUMN IF NOT EXISTS subscription_id TEXT,
ADD COLUMN IF NOT EXISTS subscription_status TEXT,
ADD COLUMN IF NOT EXISTS current_period_end TIMESTAMPTZ;