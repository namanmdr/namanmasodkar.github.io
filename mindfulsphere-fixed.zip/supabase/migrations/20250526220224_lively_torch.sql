/*
  # Add founding member status to user settings

  1. Changes
    - Add founding_member column to user_settings table
    - Add founding_member_date column to track when they became a founding member
*/

ALTER TABLE user_settings
ADD COLUMN founding_member BOOLEAN DEFAULT TRUE,
ADD COLUMN founding_member_date TIMESTAMPTZ DEFAULT now();

-- Set existing users as founding members
UPDATE user_settings
SET founding_member = TRUE,
    founding_member_date = now()
WHERE founding_member IS NULL;