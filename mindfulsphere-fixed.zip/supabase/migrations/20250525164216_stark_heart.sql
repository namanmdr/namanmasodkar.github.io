/*
  # Create initial schema for MindfulJourney

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key) - References auth.users.id
      - `created_at` (timestamptz)
      - `email` (text, unique)
      - `full_name` (text)
      - `avatar_url` (text)
    - `journal_entries`
      - `id` (uuid, primary key)
      - `created_at` (timestamptz)
      - `title` (text)
      - `content` (text)
      - `user_id` (uuid, foreign key)
      - `mood` (text)
      - `tags` (text[])
    - `yoga_sessions`
      - `id` (uuid, primary key)
      - `created_at` (timestamptz)
      - `title` (text)
      - `duration` (integer)
      - `level` (text)
      - `focus` (text)
      - `user_id` (uuid, foreign key)
      - `sequence` (jsonb)
      - `completed` (boolean)
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT
);

-- Create journal_entries table
CREATE TABLE IF NOT EXISTS journal_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT now(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mood TEXT,
  tags TEXT[]
);

-- Create yoga_sessions table
CREATE TABLE IF NOT EXISTS yoga_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT now(),
  title TEXT NOT NULL,
  duration INTEGER NOT NULL,
  level TEXT NOT NULL,
  focus TEXT NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sequence JSONB NOT NULL,
  completed BOOLEAN DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE yoga_sessions ENABLE ROW LEVEL SECURITY;

-- Create security policies
-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Journal entries policies
CREATE POLICY "Users can view their own journal entries"
  ON journal_entries
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own journal entries"
  ON journal_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own journal entries"
  ON journal_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own journal entries"
  ON journal_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Yoga sessions policies
CREATE POLICY "Users can view their own yoga sessions"
  ON yoga_sessions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own yoga sessions"
  ON yoga_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own yoga sessions"
  ON yoga_sessions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own yoga sessions"
  ON yoga_sessions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);