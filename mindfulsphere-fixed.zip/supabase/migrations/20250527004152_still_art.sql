/*
ALTER TABLE profiles
-- ADD COLUMN gender TEXT,
-- ADD COLUMN birth_date DATE,
-- ADD COLUMN location TEXT,
-- ADD COLUMN experience_level TEXT CHECK (experience_level IN ('beginner', 'intermediate', 'advanced')),
-- ADD COLUMN preferred_practice_time TEXT CHECK (preferred_practice_time IN ('morning', 'afternoon', 'evening', 'night')),
-- ADD COLUMN goals TEXT[],
-- ADD COLUMN bio TEXT,
-- ADD COLUMN website TEXT,
-- ADD COLUMN social_links JSONB DEFAULT '{}'::jsonb,
-- ADD COLUMN preferences JSONB DEFAULT '{
--   "email_notifications": true,
--   "practice_reminders": true,
--   "journal_reminders": true,
--   "theme": "system",
--   "language": "en"
-- }'::jsonb;
*/