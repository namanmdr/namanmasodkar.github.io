/*
  # Add API settings and usage tracking

  1. New Tables
    - `user_settings`
      - `user_id` (uuid, primary key)
      - `api_key` (text, encrypted)
      - `api_provider` (text)
      - `monthly_usage` (integer)
      - `last_reset` (timestamptz)
  
  2. Security
    - Enable RLS
    - Add policies for users to manage their own settings
*/

CREATE TABLE IF NOT EXISTS user_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  api_key TEXT,
  api_provider TEXT CHECK (api_provider IN ('openai', 'arliai')),
  monthly_usage INTEGER DEFAULT 0,
  last_reset TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own settings"
  ON user_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own settings"
  ON user_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own settings"
  ON user_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);