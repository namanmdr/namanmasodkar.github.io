/*
  # Add additional profile fields

  1. Changes
    - Add new columns to profiles table:
      - gender (text)
      - birth_date (date)
      - location (text)
      - experience_level (text)
      - preferred_practice_time (text)
      - goals (text[])
      - bio (text)
      - website (text)
      - social_links (jsonb)
      - preferences (jsonb)
*/
/*
-- ALTER TABLE profiles
--   ADD COLUMN gender TEXT,
--   ADD COLUMN birth_date DATE,
--   ADD COLUMN location TEXT,
--   ADD COLUMN experience_level TEXT CHECK (experience_level IN ('beginner', 'intermediate', 'advanced')),
--   ADD COLUMN preferred_practice_time TEXT CHECK (preferred_practice_time IN ('morning', 'afternoon', 'evening', 'night')),
--   ADD COLUMN goals TEXT[],
--   ADD COLUMN bio TEXT,
--   ADD COLUMN website TEXT,
--   ADD COLUMN social_links JSONB DEFAULT '{}'::jsonb,
--   ADD COLUMN preferences JSONB DEFAULT '{
--     "email_notifications": true,
--     "practice_reminders": true,
--     "journal_reminders": true,
--     "theme": "system",
--     "language": "en"
--   }'::jsonb;
*/