/*
  # Practice Cycles Integration

  1. New Tables
    - `practice_cycles`
      - `id` (uuid, primary key)
      - `created_at` (timestamptz)
      - `user_id` (uuid, foreign key)
      - `pre_journal_id` (uuid, foreign key)
      - `yoga_session_id` (uuid, foreign key)
      - `post_journal_id` (uuid, foreign key)
      - `completed` (boolean)

  2. Changes
    - Add foreign key relationships
    - Add indexes for efficient querying
    - Add function for graph data export

  3. Security
    - Enable RLS on practice_cycles table
    - Add policies for authenticated users
*/

-- Create practice_cycles table
CREATE TABLE IF NOT EXISTS practice_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  pre_journal_id uuid REFERENCES journal_entries(id) ON DELETE SET NULL,
  yoga_session_id uuid REFERENCES yoga_sessions(id) ON DELETE SET NULL,
  post_journal_id uuid REFERENCES journal_entries(id) ON DELETE SET NULL,
  completed boolean DEFAULT false
);

-- Create indexes for efficient querying
CREATE INDEX IF NOT EXISTS practice_cycles_user_id_idx ON practice_cycles(user_id);
CREATE INDEX IF NOT EXISTS practice_cycles_pre_journal_id_idx ON practice_cycles(pre_journal_id);
CREATE INDEX IF NOT EXISTS practice_cycles_yoga_session_id_idx ON practice_cycles(yoga_session_id);
CREATE INDEX IF NOT EXISTS practice_cycles_post_journal_id_idx ON practice_cycles(post_journal_id);

-- Enable RLS
ALTER TABLE practice_cycles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
-- CREATE POLICY "Users can view their own practice cycles"
--   ON practice_cycles
--   FOR SELECT
--   TO authenticated
--   USING (auth.uid() = user_id);

-- CREATE POLICY "Users can create their own practice cycles"
--   ON practice_cycles
--   FOR INSERT
--   TO authenticated
--   WITH CHECK (auth.uid() = user_id);

-- CREATE POLICY "Users can update their own practice cycles"
--   ON practice_cycles
--   FOR UPDATE
--   TO authenticated
--   USING (auth.uid() = user_id)
--   WITH CHECK (auth.uid() = user_id);

-- CREATE POLICY "Users can delete their own practice cycles"
--   ON practice_cycles
--   FOR DELETE
--   TO authenticated
--   USING (auth.uid() = user_id);

-- Add function for graph data export
DROP FUNCTION IF EXISTS get_practice_cycle_graph(uuid);

CREATE OR REPLACE FUNCTION get_practice_cycle_graph(user_id_param uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN (
    SELECT jsonb_build_object(
      'nodes', (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', COALESCE(id::text, 'null'),
            'type', CASE 
              WHEN source_table = 'journal_entries' THEN 'journal'
              WHEN source_table = 'yoga_sessions' THEN 'yoga'
            END,
            'title', title,
            'created_at', created_at
          )
        )
        FROM (
          SELECT 'journal_entries' as source_table, id, title, created_at
          FROM journal_entries
          WHERE user_id = user_id_param
          UNION ALL
          SELECT 'yoga_sessions' as source_table, id, title, created_at
          FROM yoga_sessions
          WHERE user_id = user_id_param
        ) combined
      ),
      'edges', (
        SELECT jsonb_agg(
          jsonb_build_object(
            'source', COALESCE(pre_journal_id::text, 'null'),
            'target', COALESCE(yoga_session_id::text, 'null'),
            'type', 'pre_practice'
          ) ||
          jsonb_build_object(
            'source', COALESCE(yoga_session_id::text, 'null'),
            'target', COALESCE(post_journal_id::text, 'null'),
            'type', 'post_practice'
          )
        )
        FROM practice_cycles
        WHERE user_id = user_id_param
      )
    )
  );
END;
$$;