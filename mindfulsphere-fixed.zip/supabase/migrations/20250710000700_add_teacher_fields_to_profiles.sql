-- Add teacher-related fields to profiles table
ALTER TABLE profiles
  ADD COLUMN account_type text NOT NULL DEFAULT 'student',
  ADD COLUMN is_teacher_listed boolean NOT NULL DEFAULT false,
  ADD COLUMN teacher_bio text,
  ADD COLUMN teaching_styles text[],
  ADD COLUMN years_experience integer,
  ADD COLUMN certifications text,
  ADD COLUMN studio_location text,
  ADD COLUMN public_contact text; 