-- Adds a function to increment monthly_usage for a user
CREATE OR REPLACE FUNCTION increment_monthly_usage(user_id uuid, tokens integer)
RETURNS void AS $$
BEGIN
  UPDATE user_settings
  SET monthly_usage = COALESCE(monthly_usage, 0) + tokens
  WHERE user_id = increment_monthly_usage.user_id;
END;
$$ LANGUAGE plpgsql; 