-- Add table for persistent AI analyses on journal entries
CREATE TABLE journal_entry_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_entry_id uuid REFERENCES journal_entries(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  prompt text,
  result text NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_journal_entry_analyses_journal_entry_id ON journal_entry_analyses(journal_entry_id);
CREATE INDEX idx_journal_entry_analyses_user_id ON journal_entry_analyses(user_id); 