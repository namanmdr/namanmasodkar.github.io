-- Migration: Remove founding_member columns from user_settings
ALTER TABLE user_settings DROP COLUMN IF EXISTS founding_member;
ALTER TABLE user_settings DROP COLUMN IF EXISTS founding_member_date; 

-- Always return an array for 'edges' in get_practice_cycle_graph
DROP FUNCTION IF EXISTS get_practice_cycle_graph(uuid);

CREATE OR REPLACE FUNCTION get_practice_cycle_graph(user_id_param uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN (
    SELECT jsonb_build_object(
      'nodes', (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', id,
            'type', CASE 
              WHEN source_table = 'journal_entries' THEN 'journal'
              WHEN source_table = 'yoga_sessions' THEN 'yoga'
            END,
            'title', title,
            'created_at', created_at
          )
        )
        FROM (
          SELECT 'journal_entries' as source_table, id, title, created_at
          FROM journal_entries
          WHERE user_id = user_id_param
          UNION ALL
          SELECT 'yoga_sessions' as source_table, id, title, created_at
          FROM yoga_sessions
          WHERE user_id = user_id_param
        ) combined
      ),
      'edges', COALESCE((
        SELECT jsonb_agg(edge)
        FROM (
          -- Pre-practice edges
          SELECT jsonb_build_object(
            'source', pre_journal_id,
            'target', yoga_session_id,
            'type', 'pre_practice'
          ) AS edge
          FROM practice_cycles
          WHERE user_id = user_id_param
            AND pre_journal_id IS NOT NULL
            AND yoga_session_id IS NOT NULL

          UNION ALL

          -- Post-practice edges
          SELECT jsonb_build_object(
            'source', yoga_session_id,
            'target', post_journal_id,
            'type', 'post_practice'
          ) AS edge
          FROM practice_cycles
          WHERE user_id = user_id_param
            AND yoga_session_id IS NOT NULL
            AND post_journal_id IS NOT NULL

          UNION ALL

          -- Shared journal edges
          SELECT jsonb_build_object(
            'source', pc1.post_journal_id,
            'target', pc2.pre_journal_id,
            'type', 'shared_journal'
          ) AS edge
          FROM practice_cycles pc1
          JOIN practice_cycles pc2
            ON pc1.post_journal_id IS NOT NULL
           AND pc2.pre_journal_id IS NOT NULL
           AND pc1.post_journal_id = pc2.pre_journal_id
           AND pc1.user_id = user_id_param
           AND pc2.user_id = user_id_param
        ) all_edges
        WHERE (edge->>'source') IS NOT NULL AND (edge->>'target') IS NOT NULL
      ), '[]'::jsonb)
    )
  );
END;
$$; 

-- One-time data fix: Backfill post_journal_id in practice_cycles
-- For each journal entry that is a reflection (title starts with 'Reflection:'),
-- if there is a practice_cycle for the same user where post_journal_id is NULL and the yoga_session_id is before the journal,
-- set post_journal_id to the journal's id if it matches the most recent cycle before the journal.

UPDATE practice_cycles pc
SET post_journal_id = je.id
FROM journal_entries je
WHERE
  je.title ILIKE 'Reflection:%'
  AND pc.user_id = je.user_id
  AND pc.post_journal_id IS NULL
  AND pc.yoga_session_id IS NOT NULL
  AND pc.created_at < je.created_at
  AND NOT EXISTS (
    SELECT 1 FROM practice_cycles pc2
    WHERE pc2.user_id = pc.user_id
      AND pc2.yoga_session_id IS NOT NULL
      AND pc2.created_at > pc.created_at
      AND pc2.created_at < je.created_at
  );
-- This links the most recent cycle before each reflection journal as its post_journal_id. 