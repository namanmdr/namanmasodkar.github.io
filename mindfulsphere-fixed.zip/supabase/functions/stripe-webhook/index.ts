import Stripe from 'npm:stripe@14.18.0';
import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseKey);

const endpointSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET') || '';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  // Log invocation for debugging
  console.log('stripe-webhook invoked', { method: req.method });
  // Handle OPTIONS preflight requests for CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  try {
    const signature = req.headers.get('stripe-signature');
    if (!signature) {
      throw new Error('No signature found');
    }

    const body = await req.text();
    // Use the async version for Stripe event construction
    const event = await stripe.webhooks.constructEventAsync(body, signature, endpointSecret);

    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object;
        
        // Try to get userId from subscription metadata first
        let userId = subscription.metadata.userId;
        
        // If not found in subscription metadata, try to get it from the customer
        if (!userId && subscription.customer) {
          try {
            const customer = await stripe.customers.retrieve(subscription.customer as string);
            // Look for userId in customer metadata or try to find it from the checkout session
            userId = customer.metadata.userId;
          } catch (error) {
            console.error('Error retrieving customer:', error);
          }
        }
        
        // If still no userId, try to find it from the checkout session
        if (!userId) {
          try {
            // Get the checkout session from the subscription
            const sessions = await stripe.checkout.sessions.list({
              subscription: subscription.id,
              limit: 1,
            });
            
            if (sessions.data.length > 0) {
              userId = sessions.data[0].metadata.userId;
            }
          } catch (error) {
            console.error('Error retrieving checkout session:', error);
          }
        }

        if (!userId) {
          console.error('No userId found for subscription:', subscription.id);
          return new Response(JSON.stringify({ error: 'No userId found' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          });
        }

        // Log the full event for debugging
        console.log('Stripe event:', JSON.stringify(event, null, 2));
        // Defensive check for current_period_end (from subscription.items.data[0])
        let currentPeriodEnd = null;
        if (
          subscription &&
          subscription.items &&
          Array.isArray(subscription.items.data) &&
          subscription.items.data.length > 0 &&
          typeof subscription.items.data[0].current_period_end === 'number'
        ) {
          currentPeriodEnd = new Date(subscription.items.data[0].current_period_end * 1000).toISOString();
        } else {
          console.log('No valid current_period_end found in items:', subscription?.items?.data?.[0]?.current_period_end);
        }
        // Update user's subscription status
        const { error } = await supabase
          .from('user_settings')
          .upsert({
            user_id: userId,
            subscription_id: subscription.id,
            subscription_status: subscription.status,
            current_period_end: currentPeriodEnd,
            monthly_usage: 0, // Reset usage when subscription is created/updated
            last_reset: new Date().toISOString(),
            stripe_customer_id: subscription.customer as string,
          });

        if (error) throw error;

        // Set included quantity for metered price item (2 units x 50,000 tokens = 100,000 tokens)
        const includedQuantity = 2; // 2 units x 50,000 tokens = 100,000 tokens
        for (const item of subscription.items.data) {
          if (item.price.usage_type === 'metered') {
            await stripe.subscriptionItems.update(item.id, { quantity: includedQuantity });
          }
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const userId = subscription.metadata.userId;

        // Update user's subscription status to canceled
        const { error } = await supabase
          .from('user_settings')
          .update({
            subscription_status: 'canceled',
            current_period_end: null,
          })
          .eq('user_id', userId);

        if (error) throw error;
        break;
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      }
    );
  }
});