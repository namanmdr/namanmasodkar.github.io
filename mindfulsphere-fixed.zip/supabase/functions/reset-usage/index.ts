import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseKey);

Deno.serve(async (_req) => {
  // Reset monthly_usage for all users
  const { error } = await supabase
    .from('user_settings')
    .update({ monthly_usage: 0 })
    .neq('user_id', null); // Only update rows with a user_id

  if (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }

  return new Response(
    JSON.stringify({ message: 'Monthly usage reset for all users.' }),
    { status: 200, headers: { 'Content-Type': 'application/json' } }
  );
}); 