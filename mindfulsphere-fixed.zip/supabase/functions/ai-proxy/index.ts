import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
const openaiKey = Deno.env.get('OPENAI_KEY') || '';
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  try {
    // 1. Get JWT from Authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Missing Authorization header' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
    const jwt = authHeader.replace('Bearer ', '');

    // 2. Create Supabase client with anon key and JWT
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${jwt}` } }
    });

    // 3. Get the user from the JWT
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    console.log('ai-proxy: user.id from JWT:', user?.id);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // 4. Parse the request body
    const body = await req.json();
    console.log('=== INCOMING REQUEST ===');
    console.log('Request body keys:', Object.keys(body));
    console.log('Has tts:', !!body.tts);
    console.log('Has messages:', !!body.messages);
    
    const { messages, model = 'gpt-3.5-turbo', stream = false, tts, ...rest } = body;
    
    // Handle TTS requests - extract parameters and send only TTS format to OpenAI
    if (tts) {
      console.log('=== TTS REQUEST RECEIVED ===');
      console.log('Received TTS request:', { tts });
      
      const { text, voice = 'nova', model: ttsModel = 'tts-1', response_format = 'mp3', speed = 1.0 } = tts;
      
      if (!text) {
        console.log('TTS ERROR: Missing text');
        return new Response(JSON.stringify({ error: 'Missing text for TTS' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      // === PROFITABLE TTS USAGE METERING ===
      // 1 char = 4 tokens (realistic, matches OpenAI TTS cost)
      const charCount = text.length;
      const tokensUsed = charCount * 4;
      try {
        // Update usage in Supabase
        const { error: usageError, data: usageResult } = await supabase.rpc('increment_monthly_usage', { p_user_id: user.id, tokens: tokensUsed }); // NOTE: p_user_id matches SQL function
        if (usageError) {
          console.error('[TTS USAGE ERROR] Failed to increment monthly_usage:', usageError);
        } else {
          console.log('[TTS USAGE] increment_monthly_usage result:', usageResult);
        }
        // Report usage to Stripe
        const reportRes = await fetch('https://jfbmongwmakpobzfxsnz.functions.supabase.co/report_usage', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${serviceRoleKey}`
          },
          body: JSON.stringify({
            userId: user.id,
            tokensUsed: tokensUsed
          })
        });
        console.log('[REPORT USAGE] Status:', reportRes.status);
        if (!reportRes.ok) {
          const errText = await reportRes.text();
          console.error('[REPORT USAGE] Error:', errText);
        }
      } catch (usageError) {
        console.error('TTS usage metering error:', usageError);
      }
      // === END USAGE METERING ===

      // Create the correct OpenAI TTS request body (ONLY TTS parameters, no wrapper)
      const openaiTTSBody = {
        model: ttsModel,
        input: text,
        voice: voice,
        response_format: response_format,
        speed: speed
      };
      
      console.log('Sending to OpenAI TTS:', JSON.stringify(openaiTTSBody, null, 2));

      // Call OpenAI TTS API with ONLY the TTS parameters
      const ttsResponse = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify(openaiTTSBody)
      });

      console.log('OpenAI TTS response status:', ttsResponse.status);

      if (!ttsResponse.ok) {
        const error = await ttsResponse.text();
        console.error('OpenAI TTS error:', error);
        return new Response(JSON.stringify({ error: `TTS generation failed: ${error}` }), {
          status: ttsResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      // Return the audio data directly
      const audioData = await ttsResponse.arrayBuffer();
      console.log('TTS audio data size:', audioData.byteLength);
      console.log('=== TTS REQUEST COMPLETED ===');
      return new Response(audioData, {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'audio/mpeg',
          'Content-Length': audioData.byteLength.toString()
        }
      });
    }

    // Handle regular chat completion requests
    console.log('=== CHAT COMPLETION REQUEST ===');
    if (!messages) {
      return new Response(JSON.stringify({ error: 'Missing messages' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // 5. Check subscription and usage for this user
    const { data: settings, error } = await supabase
      .from('user_settings')
      .select('subscription_status, monthly_usage, free_yoga_used, last_free_yoga_ts')
      .eq('user_id', user.id)
      .single();
    console.log('ai-proxy: user_settings query result:', settings, 'error:', error);

    if (error || !settings) {
      return new Response(JSON.stringify({ error: 'User settings not found.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const isSubscribed = settings.subscription_status === 'active';
    const freeYogaUsed = !!settings.free_yoga_used;
    const lastFreeYogaTs = settings.last_free_yoga_ts ? new Date(settings.last_free_yoga_ts) : null;
    const now = new Date();
    const withinGracePeriod = lastFreeYogaTs && (now.getTime() - lastFreeYogaTs.getTime() < 60 * 1000); // 1 minute

    if (!isSubscribed && freeYogaUsed && !withinGracePeriod) {
      return new Response(JSON.stringify({ error: 'You must be subscribed to use AI features.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const monthlyLimit = 100000; // Example: 100k tokens/month
    const overLimit = isSubscribed && (settings.monthly_usage || 0) >= monthlyLimit;
    // You can use `overLimit` to show a warning in the UI, but DO NOT block the request.

    // 6. Forward to OpenAI
    if (stream) {
      // --- STREAMING MODE ---
      // Always add stream_options: { include_usage: true }
      const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model,
          messages,
          stream: true,
          stream_options: { include_usage: true },
          ...rest
        })
      });
      const { readable, writable } = new TransformStream();
      const writer = writable.getWriter();
      const reader = openaiRes.body?.getReader();
      let usage = null;
      let buffer = '';
      (async () => {
        if (!reader) {
          await writer.close();
          return;
        }
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = new TextDecoder().decode(value);
          buffer += chunk;
          await writer.write(value);
        }
        await writer.close();
        // Parse the last usage event from the buffer
        // OpenAI streams data as 'data: ...' lines
        const lines = buffer.split('\n');
        for (let i = lines.length - 1; i >= 0; i--) {
          const line = lines[i].trim();
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.usage && typeof data.usage.total_tokens === 'number') {
                usage = data.usage;
                break;
              }
            } catch (e) { /* ignore */ }
          }
        }
        if (usage && typeof usage.total_tokens === 'number') {
          await supabase.rpc('increment_monthly_usage', { p_user_id: user.id, tokens: usage.total_tokens });
          // Report usage to Stripe metered billing
          const reportRes = await fetch('https://jfbmongwmakpobzfxsnz.functions.supabase.co/report_usage', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${serviceRoleKey}`
            },
            body: JSON.stringify({
              userId: user.id,
              tokensUsed: usage.total_tokens
            })
          });
          console.log('[REPORT USAGE] Status:', reportRes.status);
          if (!reportRes.ok) {
            const errText = await reportRes.text();
            console.error('[REPORT USAGE] Error:', errText);
          }
          // If not subscribed, mark free_yoga_used as true and set last_free_yoga_ts after first use
          if (!isSubscribed && !freeYogaUsed) {
            await supabase.from('user_settings').update({ free_yoga_used: true, last_free_yoga_ts: new Date().toISOString() }).eq('user_id', user.id);
          } else if (!isSubscribed && freeYogaUsed && withinGracePeriod) {
            await supabase.from('user_settings').update({ last_free_yoga_ts: null }).eq('user_id', user.id);
          }
        }
      })();
      return new Response(readable, {
        status: openaiRes.status,
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/event-stream'
        }
      });
    } else {
      // --- NON-STREAMING MODE ---
      const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model,
          messages,
          ...rest
        })
      });
      const openaiData = await openaiRes.json();
      // Increment usage if OpenAI call succeeded and usage info is present
      if (openaiRes.ok && openaiData.usage && typeof openaiData.usage.total_tokens === 'number') {
        await supabase.rpc('increment_monthly_usage', { p_user_id: user.id, tokens: openaiData.usage.total_tokens });
        // Report usage to Stripe metered billing
        const reportRes = await fetch('https://jfbmongwmakpobzfxsnz.functions.supabase.co/report_usage', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${serviceRoleKey}`
          },
          body: JSON.stringify({
            userId: user.id,
            tokensUsed: openaiData.usage.total_tokens
          })
        });
        console.log('[REPORT USAGE] Status:', reportRes.status);
        if (!reportRes.ok) {
          const errText = await reportRes.text();
          console.error('[REPORT USAGE] Error:', errText);
        }
        // If not subscribed, mark free_yoga_used as true and set last_free_yoga_ts after first use
        if (!isSubscribed && !freeYogaUsed) {
          await supabase.from('user_settings').update({ free_yoga_used: true, last_free_yoga_ts: new Date().toISOString() }).eq('user_id', user.id);
        } else if (!isSubscribed && freeYogaUsed && withinGracePeriod) {
          await supabase.from('user_settings').update({ last_free_yoga_ts: null }).eq('user_id', user.id);
        }
      }
      return new Response(JSON.stringify(openaiData), {
        status: openaiRes.status,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
}); 