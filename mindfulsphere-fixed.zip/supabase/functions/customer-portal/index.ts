import { createClient } from 'npm:@supabase/supabase-js@2.39.7';
import Stripe from 'npm:stripe@14.18.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseKey);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Customer portal function called');
    
    // Get the authorization header
    const authHeader = req.headers.get('Authorization');
    console.log('Auth header present:', !!authHeader);
    if (!authHeader) {
      return new Response('Unauthorized', { status: 401, headers: corsHeaders });
    }

    // Create Supabase client with anon key and JWT
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_ANON_KEY') || '',
      {
        global: { headers: { Authorization: authHeader } }
      }
    );

    // Get the user from the JWT
    const { data: { user }, error: userError } = await supabaseAnon.auth.getUser();
    console.log('User auth result:', { user: !!user, error: !!userError });
    if (userError || !user) {
      return new Response('Unauthorized', { status: 401, headers: corsHeaders });
    }

    // Get user's subscription details
    const { data, error } = await supabase
      .from('user_settings')
      .select('subscription_id')
      .eq('user_id', user.id)
      .single();

    console.log('Subscription lookup result:', { data: !!data, error: !!error, subscription_id: data?.subscription_id });

    if (error || !data?.subscription_id) {
      return new Response('No Stripe subscription found', { status: 400, headers: corsHeaders });
    }

    // Get the subscription to find the customer ID
    console.log('Retrieving subscription:', data.subscription_id);
    const subscription = await stripe.subscriptions.retrieve(data.subscription_id);
    const customerId = subscription.customer as string;
    console.log('Customer ID:', customerId);

    // Create a portal session
    const portalSession = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: Deno.env.get('PORTAL_RETURN_URL') || 'https://mindfulsphere.netlify.app/profile'
    });

    return new Response(JSON.stringify({ url: portalSession.url }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Customer portal error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}); 