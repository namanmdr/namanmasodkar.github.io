// Top-level boot log
console.log('[report_usage] Top-level: starting import and env setup');

import { createClient } from 'npm:@supabase/supabase-js@2.39.7';
console.log('[report_usage] Top-level: imported supabase-js');

let supabaseUrl, supabaseKey, stripeSecretKey, supabase;
try {
  supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY') || '';
  supabase = createClient(supabaseUrl, supabaseKey);
  console.log('[report_usage] Top-level: env loaded', { hasSupabaseUrl: !!supabaseUrl, hasSupabaseKey: !!supabaseKey, hasStripeKey: !!stripeSecretKey });
} catch (e) {
  console.log('[report_usage] Top-level: env or client error', e);
  throw e;
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  console.log('[report_usage] Handler: request received', { method: req.method, url: req.url });
  try {
    if (req.method === 'OPTIONS') {
      console.log('[report_usage] Handler: OPTIONS preflight');
      return new Response(null, { headers: corsHeaders });
    }

    // --- AUTHENTICATION START ---
    const authHeader = req.headers.get('authorization');
    console.log('[report_usage] Handler: auth header', authHeader);
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log('[report_usage] Handler: missing or invalid authorization header');
      return new Response(
        JSON.stringify({ error: 'Missing or invalid authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    const jwt = authHeader.replace('Bearer ', '').trim();
    let userIdFromToken = null;
    if (jwt === supabaseKey) {
      console.log('[report_usage] Handler: service role key used');
    } else {
      try {
        const { data: { user }, error: userError } = await supabase.auth.getUser(jwt);
        if (userError || !user) {
          console.log('[report_usage] Handler: invalid or expired token', userError);
          return new Response(
            JSON.stringify({ error: 'Invalid or expired token' }),
            { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        userIdFromToken = user.id;
        console.log('[report_usage] Handler: user JWT validated', userIdFromToken);
      } catch (e) {
        console.log('[report_usage] Handler: error in getUser', e);
        return new Response(
          JSON.stringify({ error: 'Token validation error' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }
    // --- AUTHENTICATION END ---

    let userId, tokensUsed;
    try {
      const body = await req.json();
      userId = body.userId;
      tokensUsed = body.tokensUsed;
      console.log('[report_usage] Handler: parsed body', body);
    } catch (e) {
      console.log('[report_usage] Handler: failed to parse JSON body', e);
      return new Response(
        JSON.stringify({ error: 'Invalid JSON body' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (!userId || typeof tokensUsed !== 'number') {
      console.log('[report_usage] Handler: missing userId or tokensUsed', { userId, tokensUsed });
      return new Response(
        JSON.stringify({ error: 'Missing userId or tokensUsed' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (userIdFromToken && userId !== userIdFromToken) {
      console.log('[report_usage] Handler: userId does not match token', { userId, userIdFromToken });
      return new Response(
        JSON.stringify({ error: 'userId does not match token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Look up user's Stripe subscription and metered price item
    let settings, error;
    try {
      ({ data: settings, error } = await supabase
        .from('user_settings')
        .select('stripe_customer_id, subscription_id')
        .eq('user_id', userId)
        .single());
      console.log('[report_usage] Handler: user_settings', settings, 'error:', error);
    } catch (e) {
      console.log('[report_usage] Handler: error querying user_settings', e);
      return new Response(
        JSON.stringify({ error: 'Database error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (error || !settings || !settings.stripe_customer_id || !settings.subscription_id) {
      console.log('[report_usage] Handler: user Stripe subscription not found');
      return new Response(
        JSON.stringify({ error: 'User Stripe subscription not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the subscription from Stripe REST API
    let subRes, subscription;
    try {
      subRes = await fetch(`https://api.stripe.com/v1/subscriptions/${settings.subscription_id}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${stripeSecretKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });
      console.log('[report_usage] Handler: Stripe subscription fetch status', subRes.status);
      if (!subRes.ok) {
        const err = await subRes.text();
        console.log('[report_usage] Handler: Stripe subscription fetch failed', err);
        return new Response(
          JSON.stringify({ error: `Stripe subscription fetch failed: ${err}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      subscription = await subRes.json();
    } catch (e) {
      console.log('[report_usage] Handler: error fetching Stripe subscription', e);
      return new Response(
        JSON.stringify({ error: 'Stripe API error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (!subscription || !subscription.items || !subscription.items.data) {
      console.log('[report_usage] Handler: Stripe subscription items not found', subscription);
      return new Response(
        JSON.stringify({ error: 'Stripe subscription items not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Find the metered item (usage_type === 'metered')
    const meteredItem = subscription.items.data.find((item) => item.price.usage_type === 'metered');
    if (!meteredItem) {
      console.log('[report_usage] Handler: no metered price found in subscription', subscription.items.data);
      return new Response(
        JSON.stringify({ error: 'No metered price found in subscription' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Report usage to Stripe via REST API
    let usageRecordRes;
    try {
      usageRecordRes = await fetch(`https://api.stripe.com/v1/subscription_items/${meteredItem.id}/usage_records`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${stripeSecretKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          quantity: tokensUsed.toString(),
          timestamp: Math.floor(Date.now() / 1000).toString(),
          action: 'increment'
        })
      });
      console.log('[report_usage] Handler: Stripe usage record status', usageRecordRes.status);
      if (!usageRecordRes.ok) {
        const err = await usageRecordRes.text();
        console.log('[report_usage] Handler: Stripe usage record failed', err);
        return new Response(
          JSON.stringify({ error: `Stripe usage record failed: ${err}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    } catch (e) {
      console.log('[report_usage] Handler: error reporting usage to Stripe', e);
      return new Response(
        JSON.stringify({ error: 'Stripe usage record error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Also increment monthly_usage in user_settings
    try {
      const rpcRes = await supabase.rpc('increment_monthly_usage', { p_user_id: userId, tokens: tokensUsed });
      console.log('[report_usage] Handler: increment_monthly_usage RPC result', rpcRes);
    } catch (e) {
      console.log('[report_usage] Handler: error incrementing monthly_usage', e);
      return new Response(
        JSON.stringify({ error: 'Database usage increment error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('[report_usage] Handler: success');
    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.log('[report_usage] Handler: top-level error', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}); 