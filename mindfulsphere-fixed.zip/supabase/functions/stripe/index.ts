import { createClient } from 'npm:@supabase/supabase-js@2.39.7';
import Stripe from 'npm:stripe@14.18.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseKey);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// $4.99/month base subscription price ID
const BASE_SUBSCRIPTION_PRICE_ID = 'price_1RlJ7OJjMH6y0evJnHHvzNfR';
// $0.75 per 50K tokens metered price ID (for reference, not used in checkout session creation)
const METERED_PRICE_ID = 'price_1RiuKbJjMH6y0evJEAdfQ7Ym';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { priceId, userId } = await req.json();

    // Get user's email from Supabase
    const { data: profile } = await supabase
      .from('profiles')
      .select('email')
      .eq('id', userId)
      .single();

    if (!profile?.email) {
      throw new Error('User not found');
    }

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: BASE_SUBSCRIPTION_PRICE_ID, // €4.99/month base fee
          quantity: 1,
        },
        {
          price: METERED_PRICE_ID, // €0.75 per 50k tokens (metered)
          quantity: 1, // Always 1 for metered
        },
      ],
      mode: 'subscription',
      success_url: `${req.headers.get('origin')}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get('origin')}/pricing`,
      customer_email: profile.email,
      metadata: {
        userId,
      },
      subscription_data: {
        metadata: {
          userId, // Also store userId in subscription metadata
        },
        // Set included quantity for metered price (2 x 50k = 100k tokens included)
        items: [
          {
            price: METERED_PRICE_ID,
            quantity: 2, // 2 units = 100k tokens included
          },
        ],
      },
    });

    return new Response(
      JSON.stringify({ sessionId: session.id }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});