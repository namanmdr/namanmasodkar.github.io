# MindfulSphere Project Context

## Overview
MindfulSphere is a mindfulness web app that combines AI-powered yoga sequence generation with a robust journaling system. It features user authentication, profile management, subscription gating, and a personalized dashboard.

## Tech Stack
- React (with hooks/context)
- Vite
- TypeScript
- Tailwind CSS
- Supabase (auth, DB, API)
- Stripe (payments)
- Lucide React (icons)
- React Router, React Markdown

## Implemented Features
1. **AI-Generated Yoga Sequences**
   - Generate, save, and revisit yoga flows based on intent, duration, and level
   - Timer and pose navigation for guided practice
   - Sequence history, editing, exporting (Markdown), and sharing
   - Subscription gating for AI-powered features

2. **Journaling System**
   - Full CRUD for journal entries (title, content, mood, tags)
   - Rich text/Markdown support
   - Search and filter by text, mood, or tags
   - Pre/post-practice reflection prompts

3. **User Dashboard**
   - Practice stats: yoga session count, journal entry count, current streak, last activity
   - Usage bar for AI token/quota
   - Dashboard cards and practice graph

4. **Profile & Settings**
   - Editable profile: name, gender, birth date, location, experience, practice time, goals, bio, website, social links
   - Preferences: email notifications, reminders, theme (light/dark/system), language
   - Password change and sign-out
   - Profile auto-creation if missing

5. **Authentication & Subscription**
   - Email/password auth (Supabase)
   - Subscription status and usage tracked (with hooks)
   - Free and premium tiers (premium unlocks AI yoga generation)

## Database Schema (Supabase)

### profiles
- id (uuid, PK, references auth.users.id)
- email (text, unique)
- full_name (text)
- avatar_url (text)
- gender (text)
- birth_date (date)
- location (text)
- experience_level (text)
- preferred_practice_time (text)
- goals (text[])
- bio (text)
- website (text)
- social_links (jsonb: github, twitter, linkedin)
- preferences (jsonb: email_notifications, reminders, theme, language)

### journal_entries
- id (uuid, PK)
- created_at (timestamptz)
- title (text)
- content (text)
- user_id (uuid, FK)
- mood (text)
- tags (text[])

### yoga_sessions
- id (uuid, PK)
- created_at (timestamptz)
- title (text)
- duration (integer)
- level (text)
- intent (text)
- user_id (uuid, FK)
- sequence (jsonb)
- completed (boolean)

### user_settings
- user_id (uuid, PK)
- api_key (text)
- api_provider (text)
- monthly_usage (integer)
- last_reset (timestamptz)
- subscription_id (text)
- subscription_status (text)
- current_period_end (timestamptz)

## Authentication Flow
1. User registers with email/password
2. User logs in
3. Profile and settings auto-created if missing
4. All user data is securely fetched/updated via Supabase

## Subscription System
- Free tier: limited features, user provides API key
- Premium tier: unlocks AI yoga generation, usage tracked, Stripe integration
- Usage bar and gating in UI and API

## API Integration
- Yoga sequence generation via OpenAI/Arli AI (user API key or premium)
- API key management in user settings
- Usage tracking and limits

## Project Structure
- src/components/: UI elements (Card, Button, Modal, etc.)
- src/pages/: Main pages (Home, Yoga, Journal, Profile, etc.)
- src/contexts/: Auth and Theme context providers
- src/hooks/: Custom hooks (e.g., subscription logic)
- src/lib/: Yoga sequence logic, Stripe, Supabase, exporting, types

## Deployment
- Netlify (frontend)
- Supabase (backend)

## Security
- Row Level Security (RLS) enabled on all tables
- User-specific policies for data access
- Secure API key storage
- CSP headers configured

## Known Limitations
- Email confirmation disabled by default
- No social auth
- Premium users limited to 100 AI sequences/month